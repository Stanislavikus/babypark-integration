#!/usr/bin/env bash
set -Eeuo pipefail
ROOT=/tmp/babypark-pr136-v14-oci.3SOkfxeg
IMAGE=alpine/git@sha256:16ad8e788e1d3b0c30f18da8dde5c0ace3b187445a62d8af893b003ca1e70592
HEAD=262f7a8999d797f4ceceb531004986cfd6667d73
TREE=ffb8953002feaeb5f417a09a832c86f24051afa2
BASE=0dfb9b0a1cfe23d455fd436ae9abeac626d0d729
MANIFEST=adda61453c1e14c16b1a90d072051ab3e4e29f1e110bd2c1f539aad90de8d3d6
test -n "$BASE"
echo "$MANIFEST  $ROOT/frozen-required-verification-manifest.txt" | sha256sum --check --status
cd "$ROOT"
sha256sum --check bundle.sha256 --status
for check in v03-diff-check v04-name-status v04-stat v04-full-patch; do
  echo "CHECK_START $check"
  work="$ROOT/fresh-$check"
  out="$ROOT/result-$check"
  mkdir "$out"
  git clone -q "$ROOT/pinned-source.bundle" "$work"
  git -C "$work" checkout -q --detach "$HEAD"
  test "$(git -C "$work" rev-parse HEAD)" = "$HEAD"
  test "$(git -C "$work" rev-parse HEAD^{tree})" = "$TREE"
  git -C "$work" cat-file -e "${BASE}^{commit}"
  test -z "$(git -C "$work" status --porcelain=v1 --untracked-files=all)"
  printf 'image=%s\nbundle_sha256=%s\nmanifest_sha256=%s\n' "$IMAGE" "$(cut -d' ' -f1 "$ROOT/bundle.sha256")" "$MANIFEST" > "$out/inputs.txt"
  cp "$ROOT/image-identity.txt" "$out/image-identity.txt"
  set +e
  docker run --rm --pull=never --network none --read-only --tmpfs /tmp:rw,noexec,nosuid,size=16m --cap-drop ALL --security-opt no-new-privileges \
    -v "$work:/repo:ro" -v "$out:/out:rw" \
    -w /repo -e CAMPAIGN_BASE_OID="$BASE" -e EXPECTED_HEAD="$HEAD" -e EXPECTED_TREE="$TREE" -e CHECK_ID="$check" -e GIT_OPTIONAL_LOCKS=0 \
    --entrypoint /bin/sh "$IMAGE" -eu -c '
    git -c safe.directory=/repo --version > /out/git-version.txt
    command -v git > /out/git-path.txt
    sha256sum "$(command -v git)" > /out/git-binary.sha256
    test -n "${CAMPAIGN_BASE_OID:-}"
    test "$(git -c safe.directory=/repo rev-parse HEAD)" = "$EXPECTED_HEAD"
    test "$(git -c safe.directory=/repo rev-parse HEAD^{tree})" = "$EXPECTED_TREE"
    git -c safe.directory=/repo cat-file -e "${CAMPAIGN_BASE_OID}^{commit}"
    git -c safe.directory=/repo status --porcelain=v1 --untracked-files=all > /out/porcelain-before.txt
    test ! -s /out/porcelain-before.txt
    git -c safe.directory=/repo rev-parse HEAD > /out/head-before.txt
    git -c safe.directory=/repo rev-parse HEAD^{tree} > /out/tree-before.txt
    case "$CHECK_ID" in
      v03-diff-check) printf "%s\n" "git diff --check \"${CAMPAIGN_BASE_OID}..HEAD\"" > /out/command.txt ;;
      v04-name-status) printf "%s\n" "git diff --name-status \"${CAMPAIGN_BASE_OID}..HEAD\"" > /out/command.txt ;;
      v04-stat) printf "%s\n" "git diff --stat \"${CAMPAIGN_BASE_OID}..HEAD\"" > /out/command.txt ;;
      v04-full-patch) printf "%s\n" "git diff \"${CAMPAIGN_BASE_OID}..HEAD\"" > /out/command.txt ;;
      *) exit 98 ;;
    esac
    status=0
    case "$CHECK_ID" in
      v03-diff-check) git -c safe.directory=/repo diff --check "${CAMPAIGN_BASE_OID}..HEAD" > /out/stdout.txt 2> /out/stderr.txt || status=$? ;;
      v04-name-status) git -c safe.directory=/repo diff --name-status "${CAMPAIGN_BASE_OID}..HEAD" > /out/stdout.txt 2> /out/stderr.txt || status=$? ;;
      v04-stat) git -c safe.directory=/repo diff --stat "${CAMPAIGN_BASE_OID}..HEAD" > /out/stdout.txt 2> /out/stderr.txt || status=$? ;;
      v04-full-patch) git -c safe.directory=/repo diff "${CAMPAIGN_BASE_OID}..HEAD" > /out/stdout.txt 2> /out/stderr.txt || status=$? ;;
    esac
    printf "%s\n" "$status" > /out/exit_code.txt
    git -c safe.directory=/repo status --porcelain=v1 --untracked-files=all > /out/porcelain-after.txt
    git -c safe.directory=/repo rev-parse HEAD > /out/head-after.txt
    git -c safe.directory=/repo rev-parse HEAD^{tree} > /out/tree-after.txt
    sha256sum /out/stdout.txt /out/stderr.txt > /out/stream-digests.txt
    test "$status" -eq 0
    test ! -s /out/porcelain-after.txt
    test "$(cat /out/head-after.txt)" = "$EXPECTED_HEAD"
    test "$(cat /out/tree-after.txt)" = "$EXPECTED_TREE"
    ' > "$out/docker-stdout.txt" 2> "$out/docker-stderr.txt"
  result=$?
  set -e
  echo "$result" > "$out/docker-exit-code.txt"
  test "$(git -C "$work" rev-parse HEAD)" = "$HEAD"
  test "$(git -C "$work" rev-parse HEAD^{tree})" = "$TREE"
  test -z "$(git -C "$work" status --porcelain=v1 --untracked-files=all)"
  (cd "$out"; find . -maxdepth 1 -type f ! -name 'artifact-digests.txt' -printf '%f\n' | LC_ALL=C sort | xargs -r sha256sum) > "$out/artifact-digests.txt"
  echo "RESULT $check docker_exit=$result source_sha256=$(sha256sum "$out/stdout.txt" 2>/dev/null | cut -d' ' -f1)"
  if [ "$result" -ne 0 ]; then
    echo "HALT_CHECK $check"
    cat "$out/docker-stderr.txt"
    exit 1
  fi
  sha256sum --check bundle.sha256 --status
done
echo ALL_FOUR_OCI_GIT_COMMANDS_PASS
