# BabyPark V4.2.1 OEM/Grok source handoff (2026-11-17)
This is a REHEARSAL code snapshot for independent Grok development/review, NOT deployed production and NOT an approved release. 
Source: /opt/bp-v421-v36-full-category-decision-20261115/car_seat_correction_20261117/engine_root/
OEM research: /opt/bp-v421-v36-full-category-decision-20261115/oem_reference_training_20261117/
Read oem_research/PROPOSED_FEATURE_CONTRACT.json and RULE_DISCOVERY_REPORT.md, then code/work/accessories/src/accessory_v4.py, particularly manufacturer_fitment_match.
This archive contains Python sources, tests, existing manufacturer evidence rules, taxonomy/variant profiles and OEM reference evidence/holdouts.
IMPORTANT: Full 28,769-row frozen catalog, 8,129-source manifests, native Drupal clone, and production data are intentionally NOT included in this portable source archive. Full catalog replay requires those large inputs on rehearsal. Some tests/readers use hardcoded absolute rehearsal paths and therefore need local fixture setup or path parameterization; do not claim all 35 tests will run standalone.
No .env, secrets, credentials, production snapshot, database dumps, or shopper records are intentionally included.
Do not change production. Do not publish without Stage1/current product gates. Preserve stroller results and V3.6 Similar.
Machine-generated file hashes are in FILE_SHA256.txt inside the ZIP. The ZIP SHA-256 is also printed by the transfer process.
