#!/usr/bin/env python3
"""V4.1 isolated multilingual real-catalog and negative-boundary regressions."""
import json, gzip, sys, unittest
from pathlib import Path
from unittest.mock import patch

ROOT=Path("/opt/bp-v421-v36-full-category-decision-20261115/car_seat_correction_20261117/engine_root/work/accessories")
sys.path.insert(0,str(ROOT/"src"))
import accessory_v4 as v4
import accessory_auto_v39 as av
from ordered_model_v41 import match_exact_model as match

class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rows=v4.read_rows(ROOT/"input/current_catalog_records.jsonl.gz")
        cls.policy=v4.taxonomy_policy(json.loads((ROOT/"input/taxonomy_terms_v4.json").read_text()))

    def test_ordered_positive_and_negative_models(self):
        cases=[
            ("Cybex дождевик для Gazelle S","Gazelle S",True),
            ("Cybex дождевик для Gazelle S TPE","Gazelle S",False),
            ("Cybex дождевик для Gazelle S TPE","Gazelle S TPE",True),
            ("Cybex дождевик для eGazelle S","Gazelle S",False),
            ("Cybex дождевик Balios S Lux","Balios S",False),
            ("Cybex дождевик Balios S Lux","Balios S Lux",True),
            ("Cybex дождевик Mios Style","Mios",False),
            ("Cybex дождевик Mios","Mios",True),
            ("Maxi-Cosi летний чехол Pebble 360","Pebble 360",True),
            ("Maxi-Cosi летний чехол Pebble 360 Pro","Pebble 360",False),
            ("Maxi-Cosi летний чехол Pebble 360 Pro2","Pebble 360 Pro",False),
            ("Maxi-Cosi летний чехол Pebble 360/360 Pro","Pebble 360 Pro",True),
            ("Maxi-Cosi летний чехол Pebble 360/PRO(2)","Pebble 360",False),
            ("Cybex чехол Sirona Zi i-Size","Sirona Zi i-Size",True),
            ("Cybex чехол Sirona Z i-Size","Sirona Zi i-Size",False),
            ("Cybex чехол Sirona Zi i-Size","Sirona Z i-Size",False),
            ("Britax-Romer чехол BABY-SAFE3 i-Size","BABY-SAFE 3 i-Size",True),
            ("Britax-Romer чехол BABY-SAFE 5Z i-Size","BABY-SAFE3 i-Size",False),
            ("ABC Design чехол Air-X","Air X",True),
            ("ABC Design чехол AirX","Air X",False),
            ("Joolz Aer2","Aer 2",True),
            ("Joolz Aer-20%","Aer2",False),
            ("Joolz Aer2/Aer3/Aer","Aer3",True),
            ("Joolz Aer+/2","Aer2",True),
            ("Joolz Aer S/Z","Aer Z",True),
            ("Joolz Aer S/Z","Aer",False),
        ]
        for title,model,expected in cases:
            with self.subTest(title=title,model=model):
                result,_=match(title,model)
                self.assertEqual(result=="candidate",expected)

    def test_real_specific_model_candidates(self):
        for sid,tid,model in [
            (120772,123678,"Gazelle S"),
            (121629,123679,"Gazelle S"),
            (127931,141846,"Pebble 360"),
            (127932,141847,"Pebble 360"),
        ]:
            with self.subTest(sid=sid,tid=tid):
                decision=av.reason_for(self.rows[sid],self.rows[tid],model)
                self.assertTrue(decision.startswith("accepted_"),decision)

    def test_real_universal_false_positive_rejections(self):
        for nid in (138665,142852,139152,139153,142819):
            with self.subTest(nid=nid):
                self.assertIsNone(v4.broad_scope(self.rows[nid],"stroller"))
        for nid in (123997,124001,56289,143079):
            with self.subTest(legit=nid):
                self.assertIsNotNone(v4.broad_scope(self.rows[nid],"stroller"))

    def test_protection_against_wrong_generation(self):
        self.assertNotEqual(match("Cybex дождевик Gazelle S TPE","Gazelle S")[0],"candidate")
        self.assertNotEqual(match("Cybex Mios Style","Mios")[0],"candidate")

    def test_twin_source_does_not_get_standard_umbrella(self):
        src={"nid":8101,"tnid":8101,"lang":"uk","type":"kol",
             "title":"Babypark twin stroller","cats":"128:Прогулянкові коляски",
             "brand_tid":99,"brand":"Babypark","body":"","published":1,
             "field_status":1,"price":100,"translation_ambiguous":False,
             "function_signature":{"child_capacity":"double"}}
        target={"nid":8102,"tnid":8102,"lang":"uk","type":"kol",
                "title":"Universal cup holder for most strollers",
                "cats":"134:Аксесуари","brand_tid":4,"brand":"Maker",
                "body":"","published":1,"field_status":1,"price":100,
                "translation_ambiguous":False}
        self.assertIsNotNone(v4.broad_scope(target,"stroller"))
        original={"8101":{"language":"uk","similar":[],"accessories":[]}}
        with patch.object(v4.v39,"rank_source",return_value=([],{})):
            manifest,_,_=v4.build_catalog({8101:src,8102:target},original,{},self.policy)
            self.assertEqual(manifest["8101"]["accessories"],[])
            # A stale function_signature is ignored: the title still says twin.
            src["function_signature"]["child_capacity"]="single_unspecified"
            manifest,_,_=v4.build_catalog({8101:src,8102:target},original,{},self.policy)
            self.assertEqual(manifest["8101"]["accessories"],[])
            src["title"]="Babypark stroller for one child"
            manifest,_,_=v4.build_catalog({8101:src,8102:target},original,{},self.policy)
            self.assertEqual(manifest["8101"]["accessories"],[8102])

    def test_existing_exact_role_does_not_repeat_as_universal(self):
        src={"nid":8201,"tnid":8201,"lang":"uk","type":"kol",
             "title":"Joolz stroller Aer2","cats":"128:Прогулянкові коляски",
             "brand_tid":7,"brand":"Joolz","body":"","published":1,
             "field_status":1,"price":100,"translation_ambiguous":False}
        a={"nid":8202,"tnid":8202,"lang":"uk","type":"kol",
           "title":"Joolz підсклянник Aer2","cats":"134:Аксесуари",
           "brand_tid":7,"brand":"Joolz","body":"","published":1,
           "field_status":1,"price":100,"translation_ambiguous":False}
        b={"nid":8203,"tnid":8203,"lang":"uk","type":"kol",
           "title":"Universal cup holder for most strollers",
           "cats":"134:Аксесуари","brand_tid":8,"brand":"Universal",
           "body":"","published":1,"field_status":1,"price":100,
           "translation_ambiguous":False}
        original={"8201":{"language":"uk","similar":[],"accessories":[]}}
        with patch.object(v4.v39,"rank_source",return_value=([8202],{})),\
             patch.object(v4.v39,"reason_for",return_value="accepted_model_title"),\
             patch.object(v4.v39,"group_model",return_value="Aer2"):
            result,evidence,_=v4.build_catalog({8201:src,8202:a,8203:b},original,{},self.policy)
        self.assertEqual(result["8201"]["accessories"],[8202])
        self.assertEqual(evidence["8201"]["B_universal"],[])

if __name__=="__main__":
    unittest.main(verbosity=2)
