#!/usr/bin/env python3
"""V4.2 delta tests: scoped cross-type target, OEM proof, variants and update behavior."""
import copy, gzip, json, sys, unittest
from pathlib import Path
from unittest.mock import patch

ROOT=Path("/opt/bp-v421-v36-full-category-decision-20261115/car_seat_correction_20261117/engine_root/work/accessories")
sys.path.insert(0,str(ROOT/"src"))
import accessory_v4 as v42

class V42Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rows=v42.read_rows(ROOT/"input/current_catalog_records.jsonl.gz")
        cls.help_rows=json.loads((ROOT/"input/help_public_rows_v42.json").read_text())["rows"]
        cls.rows.update({int(x["nid"]):x for x in cls.help_rows})
        cls.original=json.loads((ROOT/"input/current_v36_similarity_only_manifest.json").read_text())["sources"]
        cls.index=json.loads((ROOT/"input/v36_worker_state.json").read_text())["index"]
        cls.policy=v42.taxonomy_policy(json.loads((ROOT/"input/taxonomy_terms_v4.json").read_text()))
        cls.rules=json.loads((ROOT/"input/manufacturer_fitment_evidence_v42.json").read_text())["rules"]
        cls.profiles=v42.validate_variant_profiles(json.loads((ROOT/"input/variant_option_profiles_v42.json").read_text())["profiles"])
        cls.output=json.loads((ROOT/"output/v4_candidate_manifest.json").read_text())["sources"]
        cls.evidence=json.loads((ROOT/"output/v4_candidate_evidence.json").read_text())

    def test_scoped_help_and_role_are_functional_not_drupal_type(self):
        for target in self.help_rows:
            self.assertEqual(v42.target_head(target,self.policy),"car_seat")
            self.assertEqual(v42.target_role(target,"car_seat"),"vehicle_seat_protector")
            scope=v42.broad_scope(target,"car_seat")
            self.assertEqual(scope["scope"],"category_wide")
            self.assertTrue(scope["requires_isofix"])
            self.assertNotIn("field_accessories",target)
            self.assertNotIn("field_similar",target)
        fake_stroller_help={"nid":998001,"tnid":998001,"type":"help","lang":"uk",
                            "title":"Universal stroller bag","cats":"134:Аксесуари",
                            "published":1,"field_status":1,"price":100,"brand_tid":1,
                            "body":"Universal bag for most strollers"}
        self.assertIsNone(v42.target_head(fake_stroller_help,self.policy))
        fake_neck={"nid":998002,"tnid":998002,"type":"help","lang":"uk",
                   "title":"Safety 1st підголовник","cats":"140:Аксесуари",
                   "published":1,"field_status":1,"price":100,"brand_tid":764,
                   "body":"Head support for car rides and bath use"}
        self.assertIsNone(v42.broad_scope(fake_neck,"car_seat"))
        self.assertIsNone(v42.target_head({"type":"product_kit","cats":"20:Аксессуары"},self.policy))

    def test_three_manufacturer_rules_capture_bilingual_pairs_and_oid_gates(self):
        pairs=((144884,144886),(144885,144887),
               (145237,145239),(145238,145240),
               (145262,145264),(145263,145265))
        for source_id,target_id in pairs:
            with self.subTest(source=source_id,target=target_id):
                source=self.rows[source_id];target=self.rows[target_id]
                proof=v42.manufacturer_fitment_match(source,target,self.policy,self.rules,self.profiles)
                self.assertIsNotNone(proof)
                self.assertIn("manufacturer",proof["manufacturer_evidence"]["issuer"].lower())
                self.assertIn(target_id,self.evidence[str(source_id)]["A_model"])
                self.assertEqual(self.evidence[str(source_id)]["targets"][str(target_id)]["reason"],
                                 "accepted_manufacturer_verified_fitment")
        self.assertEqual(self.evidence["144884"]["targets"]["144886"]["variant_gate"]["source"]["class"],"color")
        self.assertEqual(self.evidence["145238"]["targets"]["145240"]["variant_gate"]["target"]["class"],"color")
        self.assertEqual(self.evidence["145263"]["targets"]["145265"]["variant_gate"]["policy"],"identical")
        for rule in self.rules:
            self.assertFalse(any(k.endswith("_nid") or k in ("source","target","nid")
                                 for k in rule))
        wrong=copy.deepcopy(self.rows[144885]);wrong["function_signature"]["travel_config"]="3"
        self.assertIsNone(v42.manufacturer_fitment_match(wrong,self.rows[144887],self.policy,self.rules,self.profiles))
        wrong=copy.deepcopy(self.rows[145238]);wrong["title"]="ABC Design автокрісло Lily i-Size Pro"
        self.assertIsNone(v42.manufacturer_fitment_match(wrong,self.rows[145240],self.policy,self.rules,self.profiles))
        wrong=copy.deepcopy(self.rows[145263]);wrong["function_signature"]["child_capacity"]="single"
        self.assertIsNone(v42.manufacturer_fitment_match(wrong,self.rows[145265],self.policy,self.rules,self.profiles))
        wrong_target=copy.deepcopy(self.rows[145240]);wrong_target["title"]="ABC Design платформа Root Next"
        self.assertIsNone(v42.manufacturer_fitment_match(self.rows[145238],wrong_target,self.policy,self.rules,self.profiles))
        unknown=copy.deepcopy(self.rows[145263]);unknown["option_digest"]="unknown-profile"
        self.assertIsNone(v42.manufacturer_fitment_match(unknown,self.rows[145265],self.policy,self.rules,self.profiles))

    def test_help_target_only_reaches_positive_isofix_sources_and_is_bilingual(self):
        for lang,target_id in (("ru",122632),("uk",122633)):
            candidates=[self.rows[int(sid)] for sid in self.original
                        if self.rows[int(sid)].get("lang")==lang
                        and v42.source_head(self.rows[int(sid)],self.policy)=="car_seat"
                        and v42.eligible_source(self.rows[int(sid)])
                        and v42.source_supports_isofix(self.rows[int(sid)])]
            self.assertTrue(candidates,lang)
            source=candidates[0]
            manifest,evidence,_=v42.build_catalog(
                {source["nid"]:source,target_id:self.rows[target_id]},
                {str(source["nid"]):{"language":lang,"similar":[]}},
                self.index,self.policy,self.rules,self.profiles)
            self.assertIn(target_id,manifest[str(source["nid"])]["accessories"])
            target_evidence=evidence[str(source["nid"])]["targets"][str(target_id)]
            self.assertEqual(target_evidence["role"],"vehicle_seat_protector")
            self.assertEqual(target_evidence["label_key"],"may_fit")
            no_iso=[self.rows[int(sid)] for sid in self.original
                    if self.rows[int(sid)].get("lang")==lang
                    and v42.source_head(self.rows[int(sid)],self.policy)=="car_seat"
                    and v42.eligible_source(self.rows[int(sid)])
                    and not v42.source_supports_isofix(self.rows[int(sid)])]
            if no_iso:
                source_no_iso=no_iso[0]
                out,_,_=v42.build_catalog(
                    {source_no_iso["nid"]:source_no_iso,target_id:self.rows[target_id]},
                    {str(source_no_iso["nid"]):{"language":lang,"similar":[]}},
                    self.index,self.policy,self.rules,self.profiles)
                self.assertNotIn(target_id,out[str(source_no_iso["nid"])]["accessories"])

    def test_new_accessory_appears_without_manual_links_and_drops_when_ineligible(self):
        lang="uk";target=copy.deepcopy(self.rows[122633])
        target.update(nid=998101,tnid=998101,vid=998101,title="Coo Coo new universal car seat protector")
        source=next(self.rows[int(sid)] for sid in self.original
                    if self.rows[int(sid)].get("lang")==lang
                    and v42.source_head(self.rows[int(sid)],self.policy)=="car_seat"
                    and v42.eligible_source(self.rows[int(sid)])
                    and v42.source_supports_isofix(self.rows[int(sid)]))
        self.assertNotIn("field_accessories",target)
        self.assertNotIn("field_similar",target)
        rows={source["nid"]:source,target["nid"]:target}
        base={str(source["nid"]):{"language":lang,"similar":[]}}
        out,_,_=v42.build_catalog(rows,base,self.index,self.policy,self.rules,self.profiles)
        self.assertIn(target["nid"],out[str(source["nid"])]["accessories"])
        for field,value in (("published",0),("field_status",0),("price",0)):
            changed=copy.deepcopy(target);changed[field]=value
            out,_,_=v42.build_catalog({source["nid"]:source,changed["nid"]:changed},
                base,self.index,self.policy,self.rules,self.profiles)
            self.assertNotIn(target["nid"],out[str(source["nid"])]["accessories"],field)

    def test_similar_and_known_bad_universal_targets_are_untouched(self):
        for sid,record in self.original.items():
            self.assertEqual(self.output[sid]["similar"],record["similar"])
            self.assertFalse(set(record["similar"]) & set(self.output[sid]["accessories"]))
        bad={138665,142852,139152,139153,142819}
        for item in self.evidence.values():
            self.assertFalse(bad & set(item.get("B_universal",[])))

if __name__=="__main__":
    unittest.main(verbosity=2)
