import csv, gzip, json, sys, unittest
from collections import Counter
from pathlib import Path

BASE=Path("/opt/bp-v421-v36-full-category-decision-20261115")
CAM=BASE/"car_seat_correction_20261117"
ENG=CAM/"engine_root"/"work"/"accessories"
sys.path.insert(0,str(ENG/"src"))
import accessory_v4 as v4

def load(path): return json.loads(Path(path).read_text(encoding="utf-8"))
def read_csv(path):
    with Path(path).open(encoding="utf-8-sig",newline="") as f:return list(csv.DictReader(f))
def snapshot(folder):
    p=BASE/folder/"output"
    return (load(p/"t2_v421_manifest.json")["sources"],load(p/"t2_v421_evidence.json")["sources"])

class CarSeatCorrectionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rows=v4.read_rows(CAM/"input"/"fresh_current_catalog_records.jsonl.gz")
        cls.details=read_csv(BASE/"FINAL_T0_T1_T2_DETAILS.csv")
        cls.orig=snapshot("t2_rebuild_20261116_livev34_corrected")
        cls.fix1=snapshot("car_seat_fix_20261116")
        cls.corr=snapshot("car_seat_correction_20261117")
        cls.summary=load(CAM/"analysis_summary.json")
        cls.source_meta={}
        cls.seat_ids=set(); cls.stroller_ids=set(); cls.old_eligible=set()
        for row in cls.details:
            sid=int(row["source_nid"])
            cls.source_meta.setdefault(sid,row)
            if row["category"]=="Автокресла":
                cls.seat_ids.add(sid)
                if row["source_v421_engine_eligible"]=="1":cls.old_eligible.add(sid)
            elif row["category"]=="Коляски":cls.stroller_ids.add(sid)

    def test_full_8129_source_set_and_similar_are_identical(self):
        self.assertEqual(len(self.orig[0]),8129)
        self.assertEqual(len(self.fix1[0]),8129)
        self.assertEqual(len(self.corr[0]),8129)
        for sid in self.orig[0]:
            self.assertEqual(self.orig[0][sid]["similar"],self.fix1[0][sid]["similar"],sid)
            self.assertEqual(self.orig[0][sid]["similar"],self.corr[0][sid]["similar"],sid)
        self.assertEqual(self.summary["similar_differences"]["corrected"],0)

    def test_all_1832_stroller_edges_are_exactly_unchanged(self):
        def pairs(snap):
            man=snap[0]
            return {(sid,int(t)) for sid in self.stroller_ids for t in man[str(sid)]["accessories"]}
        original=pairs(self.orig); fix1=pairs(self.fix1); corrected=pairs(self.corr)
        self.assertEqual(len(original),1832)
        self.assertEqual(original,fix1)
        self.assertEqual(original,corrected)

    def test_full_eligible_car_seat_classification_and_primary_denominator(self):
        counts=Counter(v4.car_seat_source_class(self.rows[s]) for s in self.old_eligible)
        self.assertEqual(counts,Counter({
            "primary_car_seat":318,"isofix_base":8,"booster_restraint":4,
            "primary_seat_set":2,"accessory":2
        }))
        self.assertEqual(len(self.old_eligible),334)
        self.assertEqual(len([s for s in self.old_eligible if v4.source_head(self.rows[s],v4.taxonomy_policy(load(ENG/"input"/"taxonomy_terms_v4.json")) )=="car_seat"]),324)
        for nid in (56002,57917,79391,80167,84953,84956,84957,84958):
            self.assertEqual(v4.car_seat_source_class(self.rows[nid]),"isofix_base")
        for nid in (144915,144916):
            self.assertEqual(v4.car_seat_source_class(self.rows[nid]),"accessory")

    def test_seat_liner_requires_explicit_compatible_age_weight_group(self):
        self.assertTrue(v4.seat_liner_age_group_compatible(self.rows[137406],self.rows[142212]))
        self.assertTrue(v4.seat_liner_age_group_compatible(self.rows[137549],self.rows[82597]))
        self.assertFalse(v4.seat_liner_age_group_compatible(self.rows[139525],self.rows[82597]))
        unknown=dict(self.rows[82597]);unknown["title"]="Britax-Romer insert";unknown["body"]=""
        self.assertFalse(v4.seat_liner_age_group_compatible(self.rows[137549],unknown))

    def test_bugs_is_diagnostic_C_and_never_car_seat_A_or_B(self):
        corr_ev=self.corr[1]
        self.assertEqual(self.summary["seat_state"]["fix1"]["B_edges_all_old_eligible"],334)
        self.assertEqual(self.summary["seat_state"]["corrected"]["B_edges_all_old_eligible"],0)
        for sid,e in corr_ev.items():
            if e.get("head")=="car_seat":
                self.assertNotIn(79424,e.get("A_model",[])+e.get("B_universal",[]),sid)
                self.assertNotIn(79439,e.get("A_model",[])+e.get("B_universal",[]),sid)
                self.assertEqual(e.get("B_universal",[]),[],sid)
        c=read_csv(CAM/"C_VEHICLE_GENERAL.csv")
        self.assertTrue(any(r["sku"]=="6900000016817" and r["language"]=="ru" for r in c))
        self.assertTrue(all(r["compatibility_class"]=="C_vehicle_general" for r in c))

    def test_pearl_slide_pro_exact_A_survives_and_new_translation_pair_passes_stage1(self):
        ev=self.corr[1]
        self.assertIn(144397,ev["144180"]["A_model"])
        self.assertIn(144398,ev["144181"]["A_model"])
        rec=read_csv(CAM/"NEW_A_B_RECOMMENDATIONS.csv")
        self.assertEqual(len(rec),2)
        self.assertTrue(all(r["stage1_all_gates_pass"]=="yes" for r in rec))
        self.assertTrue(all(r["stage1_option_digest_matches_current"]=="yes" for r in rec))
        self.assertTrue(all(r["stage1_oid_rows_match_current"]=="yes" for r in rec))
        self.assertTrue(all(r["target_oid_weight_price_rows"] for r in rec))
        self.assertTrue(all('"cta": "buy"' in r["stage1_native_states"] for r in rec))
        self.assertEqual({r["target_sku"] for r in rec},{"8562570110"})
        self.assertEqual({r["target_language"] for r in rec},{"ru","uk"})

    def test_manual_candidates_are_review_only_and_all_1978_are_classified(self):
        review=read_csv(CAM/"MANUAL_CANDIDATE_REVIEW.csv")
        self.assertEqual(len(review),1978)
        self.assertTrue(all(r["manual_fallback_used"]=="no" for r in review))
        self.assertEqual(sum(r["compatibility_decision"]=="compatibility_confirmed" for r in review),8)
        self.assertEqual(sum(r["should_offer_if_gate_passes"]=="yes" for r in review),8)

if __name__=="__main__":unittest.main(verbosity=2)
