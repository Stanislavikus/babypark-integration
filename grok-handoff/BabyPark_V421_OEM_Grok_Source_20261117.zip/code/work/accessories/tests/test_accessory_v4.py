import sys, unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0,"/opt/bp-v421-v36-full-category-decision-20261115/car_seat_correction_20261117/engine_root/work/accessories/src")
import accessory_v4 as v4

class AccessoryV4Test(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import json
        p=Path("/opt/bp-v421-v36-full-category-decision-20261115/car_seat_correction_20261117/engine_root/work/accessories/input/taxonomy_terms_v4.json")
        cls.policy=v4.taxonomy_policy(json.loads(p.read_text()))

    def row(self,nid,title,cats,brand=7,status=1,body="",lang="uk"):
        return {"nid":nid,"tnid":nid,"lang":lang,"type":"kol","title":title,
                "body":body,"cats":cats,"brand_tid":brand,"brand":"Brand",
                "published":1,"field_status":status,"price":100,
                "translation_ambiguous":False}

    def test_taxonomy_inherits_accessory_branch_and_excludes_components(self):
        self.assertIn(134,self.policy["stroller_accessories"])
        self.assertIn(1604,self.policy["stroller_accessories"])
        self.assertNotIn(131,self.policy["stroller_sources"])
        self.assertNotIn(1596,self.policy["stroller_sources"])

    def test_universal_requires_role_and_matching_scope(self):
        good=self.row(1002,"Universal cup holder for most strollers","134:Аксесуари",brand=99)
        self.assertEqual(v4.broad_scope(good,"stroller")["role"],"cup_holder")
        no_scope=self.row(1003,"Universal cup holder","134:Аксесуари",brand=99)
        self.assertIsNone(v4.broad_scope(no_scope,"stroller"))
        body_only=self.row(1008,"Bugaboo organizer","134:Аксесуари",brand=99,
                           body="The organizer attachment to the stroller is universal.")
        self.assertIsNone(v4.broad_scope(body_only,"stroller"))
        wrong_role=self.row(1009,"Lionelo bag Little Cube","134:Аксесуари",brand=88,
                            body="Universal hooks for all stroller models.")
        self.assertIsNone(v4.broad_scope(wrong_role,"stroller"))

    def test_universal_mechanical_is_suppressed(self):
        adapter=self.row(1004,"Universal adapter for all strollers","134:Аксесуари",brand=99)
        self.assertIsNone(v4.broad_scope(adapter,"stroller"))

    def test_brand_bound_and_narrow_claims_do_not_cross_categories(self):
        mima=self.row(1005,"Mima bag","134:Аксесуари",brand=99,
                      body="Подходит для всех колясок Mima.")
        mima["brand"]="Mima"
        scope=v4.broad_scope(mima,"stroller")
        self.assertEqual(scope["scope"],"brand_wide")
        self.assertEqual(scope["brand_tid"],99)
        narrow=self.row(1006,"Universal bag for most walking strollers",
                        "134:Аксесуари",brand=99)
        self.assertIsNone(v4.broad_scope(narrow,"stroller"))

    def test_car_interior_protector_is_not_for_child_car_seats(self):
        cover={"nid":1007,"type":"kreslo","title":"Britax-Romer чехол-накидка Car Seat Saver",
               "body":"Можно использовать для защиты салона автомобилей любой марки.",
               "cats":"140:Аксесуари","brand_tid":9,"brand":"Britax-Romer",
               "published":1,"field_status":1,"price":100}
        self.assertIsNone(v4.broad_scope(cover,"car_seat"))

    def test_bilingual_car_seat_scope_spellings(self):
        self.assertIsNotNone(v4.SCOPE["car_seat"].search("чехол для автокресла"))
        self.assertIsNotNone(v4.SCOPE["car_seat"].search("чохол для автокрісла"))
        self.assertIsNotNone(v4.SCOPE["car_seat"].search("cover for car seat"))

    def test_functional_car_seat_cover_cross_taxonomy_exact_model_A(self):
        source=self.rows_for_real()[144180]
        target=self.rows_for_real()[144397]
        self.assertEqual(v4.taxonomy_target_heads(target,self.policy),{"stroller"})
        self.assertEqual(v4.target_head(target,self.policy),"car_seat")
        base={"144180":{"language":"ru","similar":[],"accessories":[]}}
        with patch.object(v4.v39,"rank_source",return_value=([144397],{})), \
             patch.object(v4.v39,"reason_for",return_value="accepted_model_title"), \
             patch.object(v4.v39,"group_model",return_value="Pearl Slide Pro"):
            out,ev,_=v4.build_catalog({144180:source,144397:target},base,{},self.policy)
        self.assertEqual(out["144180"]["accessories"],[144397])
        self.assertEqual(ev["144180"]["targets"]["144397"]["functional_head"],"car_seat")
        self.assertEqual(ev["144180"]["targets"]["144397"]["taxonomy_heads"],["stroller"])

    def test_cross_taxonomy_adapter_still_requires_explicit_manufacturer_fitment(self):
        rows=self.rows_for_real()
        import gzip,json
        index=json.load(gzip.open("/opt/bp-v421-v36-full-category-decision-20261115/car_seat_correction_20261117/input/fresh_v32_index.json.gz","rt",encoding="utf-8"))
        source=rows[144180]
        adapter=dict(rows[144397])
        adapter.update(nid=999799,tnid=999799,
                       title="Maxi-Cosi adapter for car seat Pearl Slide Pro",
                       body="Connects the Pearl Slide Pro car seat to a stroller.")
        self.assertEqual(v4.target_head(adapter,self.policy),"car_seat")
        model=v4.v39.group_model(source,index)
        self.assertEqual(v4.v39.reason_for(source,adapter,model),"blocked_mechanical_fitment")
        out,_,_=v4.build_catalog({144180:source,999799:adapter},
            {"144180":{"language":"ru","similar":[],"accessories":[]}},
            index,self.policy)
        self.assertNotIn(999799,out["144180"]["accessories"])

    def rows_for_real(self):
        import gzip,json
        from pathlib import Path
        path=Path("/opt/bp-v421-v36-full-category-decision-20261115/car_seat_correction_20261117/engine_root/work/accessories/input/current_catalog_records.jsonl.gz")
        want={144180,144397,79424,79439,133390,133391,120298,142550}
        rows={}
        with gzip.open(path,"rt",encoding="utf-8") as f:
            for line in f:
                row=json.loads(line)
                if int(row["nid"]) in want:rows[int(row["nid"])]=row
        self.assertEqual(set(rows),want)
        return rows

    def test_vehicle_general_car_seat_organizers_are_not_B(self):
        rows=self.rows_for_real()
        for tid in (79424,79439,133390,133391):
            target=rows[tid]
            self.assertEqual(v4.target_role(target,"car_seat"),"bag",tid)
            self.assertIsNone(v4.broad_scope(target,"car_seat"),tid)
        no_mount=dict(rows[79424]);no_mount["body"]="Подходит для использования в любой машине."
        self.assertIsNone(v4.broad_scope(no_mount,"car_seat"))
        no_any=dict(rows[79424]);no_any["body"]="Крепится на подголовник автомобиля."
        self.assertIsNone(v4.broad_scope(no_any,"car_seat"))
        restraint=dict(rows[79424]);restraint["body"] += " Используется ремень безопасности и ISOFIX."
        self.assertIsNone(v4.broad_scope(restraint,"car_seat"))
        self.assertIsNone(v4.broad_scope(rows[144397],"car_seat"))

    def test_missing_child_capacity_does_not_enable_vehicle_general_B_and_stroller_guard_remains(self):
        rows=self.rows_for_real()
        source=dict(rows[144180]);source["function_signature"]={"child_capacity":None}
        with patch.object(v4.v39,"rank_source",return_value=([],{})):
            out,ev,_=v4.build_catalog({144180:source,79424:rows[79424]},
                {"144180":{"language":"ru","similar":[],"accessories":[]}}, {}, self.policy)
        self.assertEqual(out["144180"]["accessories"],[])
        self.assertEqual(ev.get("144180",{}).get("B_universal",[]),[])
        stroller=dict(rows[120298]);
        with patch.object(v4.v39,"rank_source",return_value=([],{})), \
             patch.object(v4,"stroller_capacity",return_value=None):
            out,_,_=v4.build_catalog({120298:stroller,142550:rows[142550]},
                {"120298":{"language":"uk","similar":[],"accessories":[]}}, {}, self.policy)
        self.assertNotIn(142550,out["120298"]["accessories"])

    def test_new_universal_item_disappears_when_unavailable(self):
        good=self.row(1002,"Universal cup holder for most strollers","134:Аксесуари",brand=99)
        self.assertTrue(v4.broad_scope(good,"stroller"))
        good["field_status"]=0
        self.assertFalse(v4.eligible_source(good))
        self.assertFalse(v4.eligible_source({"published":1,"field_status":0,"price":100}))

    def test_group_a_precedes_b_and_similar_is_unchanged(self):
        source=self.row(1000,"Joolz stroller Aer2","128:Прогулянкові коляски",brand=7)
        a=self.row(1001,"Joolz rain cover Aer2","134:Аксесуари",brand=7)
        b=self.row(1002,"Universal cup holder for most strollers","134:Аксесуари",brand=99)
        original={"1000":{"language":"uk","similar":[999],"accessories":[]}}
        with patch.object(v4.v39,"rank_source",return_value=([1001],{})), \
             patch.object(v4.v39,"reason_for",return_value="accepted_model_title"), \
             patch.object(v4.v39,"group_model",return_value="Aer2"):
            result,ev,m=v4.build_catalog({1000:source,1001:a,1002:b},original,{},self.policy)
        self.assertEqual(result["1000"]["similar"],[999])
        self.assertEqual(result["1000"]["accessories"],[1001,1002])
        self.assertEqual(ev["1000"]["A_model"],[1001])
        self.assertEqual(ev["1000"]["B_universal"],[1002])

    def test_new_bilingual_catalog_rows_without_manual_relations(self):
        ua=self.row(2000,"Joolz stroller Day5","128:Прогулянкові коляски",brand=7,lang="uk")
        ru=self.row(2001,"Joolz прогулочная коляска Day5","1591:Прогулочные коляски",brand=7,lang="ru")
        ua["tnid"]=ru["tnid"]=2000
        target_ua=self.row(3000,"Universal cup holder for most strollers","134:Аксесуари",brand=99,lang="uk")
        target_ru=self.row(3001,"Universal cup holder for most strollers","1604:Аксессуары",brand=99,lang="ru")
        target_ua["tnid"]=target_ru["tnid"]=3000
        rows={2000:ua,2001:ru,3000:target_ua,3001:target_ru}
        original={"2000":{"language":"uk","similar":[],"accessories":[]},
                  "2001":{"language":"ru","similar":[],"accessories":[]}}
        self.assertNotIn("field_accessories",target_ua)
        self.assertNotIn("field_accessories",target_ru)
        result,_,_=v4.build_catalog(rows,original,{"source_models":{}},self.policy)
        self.assertEqual(result["2000"]["accessories"],[3000])
        self.assertEqual(result["2001"]["accessories"],[3001])
        target_ua["field_status"]=0
        result,_,_=v4.build_catalog(rows,original,{"source_models":{}},self.policy)
        self.assertEqual(result["2000"]["accessories"],[])
        del rows[3001]
        result,_,_=v4.build_catalog(rows,original,{"source_models":{}},self.policy)
        self.assertEqual(result["2001"]["accessories"],[])

if __name__=="__main__":unittest.main(verbosity=2)