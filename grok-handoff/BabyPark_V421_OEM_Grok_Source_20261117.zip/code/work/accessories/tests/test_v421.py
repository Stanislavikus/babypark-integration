#!/usr/bin/env python3
"""V4.2.1 rehearsal regressions; public snapshot, no manual fields."""
import copy, gzip, json, sys, unittest
from pathlib import Path

ROOT=Path("/opt/bp-v421-v36-full-category-decision-20261115/car_seat_correction_20261117/engine_root/work/accessories")
sys.path.insert(0,str(ROOT/"src"))
import accessory_v4 as v

class V421Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rows=v.read_rows(ROOT/"input/current_catalog_records.jsonl.gz")
        cls.original=json.loads((ROOT/"input/current_v36_similarity_only_manifest.json").read_text())["sources"]
        cls.index=json.loads((ROOT/"input/v36_worker_state.json").read_text())["index"]
        cls.policy=v.taxonomy_policy(json.loads((ROOT/"input/taxonomy_terms_v4.json").read_text()))
        cls.rules=json.loads((ROOT/"input/manufacturer_fitment_evidence_v42.json").read_text())["rules"]
        cls.profiles=v.validate_variant_profiles(json.loads((ROOT/"input/variant_option_profiles_v42.json").read_text())["profiles"])
        cls.manifest=json.loads((ROOT/"output/v4_candidate_manifest.json").read_text())["sources"]
        cls.evidence=json.loads((ROOT/"output/v4_candidate_evidence.json").read_text())
        cls.help_rows=json.loads((ROOT/"input/help_public_rows_v42.json").read_text())["rows"]

    def test_full_manifest_localization_availability_and_similarity_are_invariants(self):
        self.assertEqual(len(self.manifest),8471)
        self.assertEqual(set(self.manifest),set(self.original))
        for sid,old in self.original.items():
            out=self.manifest[sid]
            self.assertEqual(out["similar"],old["similar"],sid)
            self.assertEqual(len(out["accessories"]),len(set(out["accessories"])),sid)
            self.assertFalse(set(out["similar"]) & set(out["accessories"]),sid)
            source=self.rows[int(sid)]
            self.assertEqual(out["language"],source["lang"],sid)
            for tid in out["accessories"]:
                target=self.rows[tid]
                self.assertEqual(target["lang"],source["lang"],(sid,tid))
                self.assertEqual(int(target.get("published") or 0),1,(sid,tid))
                self.assertEqual(int(target.get("field_status") or 0),1,(sid,tid))
                self.assertGreater(float(target.get("price") or 0),0,(sid,tid))
                self.assertNotIn(target.get("type"),("product_kit","help"),(sid,tid))
                self.assertNotIn("field_accessories",target,(sid,tid))
                self.assertNotIn("field_similar",target,(sid,tid))
            ev=self.evidence.get(sid,{})
            a=ev.get("A_model",[]); b=ev.get("B_universal",[])
            self.assertEqual(out["accessories"][:len(a)],a,sid)
            self.assertEqual(out["accessories"][len(a):],b,sid)

    def test_help_and_vehicle_seat_mats_fail_closed(self):
        help_ids={int(r["nid"]) for r in self.help_rows}
        self.assertEqual(v.read_rows(ROOT/"input/current_catalog_records.jsonl.gz").keys() & help_ids,set())
        self.assertTrue(all(int(tid) not in help_ids for row in self.manifest.values() for tid in row["accessories"]))
        self.assertEqual(v.target_head({"type":"help","cats":"134:Аксесуари"},self.policy),None)
        probes=[
            "ISOFIX отсутствует","Без ISOFIX","ISOFIX не предусмотрен",
            "ISO FIX не установлен","У этой модели нет системы ISOFIX",
            "ISOFIX устанавливается только на другой модели",
            "Можно ли установить ISOFIX?","ISOFIX под вопросом","Can this use ISOFIX?",
        ]
        for text in probes:
            self.assertFalse(v.source_supports_isofix({"title":text,"body":""}),text)
        self.assertTrue(v.source_supports_isofix({"title":"Кресло оснащено системой ISOFIX","body":""}))
        self.assertTrue(all("vehicle_seat_protector" not in x.get("B_universal",[]) for x in self.evidence.values()))

    def test_six_bilingual_manufacturer_verified_links_and_variant_gates(self):
        pairs=((144884,144886),(144885,144887),(145237,145239),
               (145238,145240),(145262,145264),(145263,145265))
        for sid,tid in pairs:
            with self.subTest(source=sid,target=tid):
                self.assertIn(tid,self.evidence[str(sid)]["A_model"])
                proof=v.manufacturer_fitment_match(self.rows[sid],self.rows[tid],self.policy,self.rules,self.profiles)
                self.assertIsNotNone(proof)
                self.assertEqual(self.evidence[str(sid)]["targets"][str(tid)]["reason"],
                                 "accepted_manufacturer_verified_fitment")
        wrong=copy.deepcopy(self.rows[145238]);wrong["title"]="ABC Design Lily i-Size Pro"
        self.assertIsNone(v.manufacturer_fitment_match(wrong,self.rows[145240],self.policy,self.rules,self.profiles))
        unknown=copy.deepcopy(self.rows[145263]);unknown["option_digest"]="unknown-profile"
        self.assertIsNone(v.manufacturer_fitment_match(unknown,self.rows[145265],self.policy,self.rules,self.profiles))

    def test_capacity_is_model_and_passenger_based_not_double_hardware(self):
        self.assertEqual(v.stroller_capacity(self.rows[132733]),"single")
        self.assertEqual(v.stroller_capacity(self.rows[133063]),"single")
        self.assertEqual(v.stroller_capacity(self.rows[145262]),"double")
        self.assertEqual(v.stroller_capacity(self.rows[145263]),"double")
        self.assertNotIn(142550,self.manifest["145263"]["accessories"])
        for text in ("double suspension","double wheels","двойная амортизация","двойные колёса"):
            self.assertNotEqual(v.stroller_capacity({"title":"Lionelo Elia "+text,"brand":"Other"}),"double",text)
        self.assertEqual(v.stroller_capacity({"title":"Коляска для двойни","brand":"Other"}),"double")
        self.assertEqual(v.stroller_capacity({"title":"Коляска для одного ребёнка","brand":"Other"}),"single")

    def test_existing_export_cross_type_accessories_are_bilingual_and_role_correct(self):
        expected=((142549,"ru","cup_holder"),(142550,"uk","cup_holder"),
                  (143117,"ru","handle_muff"))
        for tid,lang,role in expected:
            target=self.rows[tid]
            self.assertEqual(target["type"],"mebel")
            self.assertEqual(v.target_head(target,self.policy),"stroller")
            self.assertEqual(v.target_role(target,"stroller"),role)
            sources=[int(sid) for sid,ev in self.evidence.items() if tid in ev.get("B_universal",[])]
            self.assertTrue(sources,(tid,lang))
            self.assertTrue(all(self.rows[s]["lang"]==lang for s in sources),(tid,lang))
        ua_muff=self.rows[143149]
        self.assertEqual(v.target_role(ua_muff,"stroller"),"handle_muff")
        self.assertIsNotNone(v.broad_scope(ua_muff,"stroller"))
        sid=120298
        isolated,_,_=v.build_catalog({sid:self.rows[sid],143149:ua_muff},
            {str(sid):self.original[str(sid)]},self.index,self.policy,self.rules,self.profiles)
        self.assertIn(143149,isolated[str(sid)]["accessories"])
        for tid in (138219,138220):
            self.assertFalse(any(tid in ev.get("B_universal",[]) for ev in self.evidence.values()))
        metrics=json.loads((ROOT/"output/v4_metrics.json").read_text())
        self.assertEqual(metrics["help_rows_imported"],0)
        self.assertGreater(metrics["cross_type_B_edges"],0)

    def test_new_cross_type_accessory_without_relations_and_availability_change(self):
        tid=142550
        sid=next(int(s) for s,e in self.evidence.items() if tid in e.get("B_universal",[]))
        source=self.rows[sid]
        target=copy.deepcopy(self.rows[tid])
        target.update(nid=998101,tnid=998101,vid=998101)
        self.assertNotIn("field_accessories",target);self.assertNotIn("field_similar",target)
        base={str(sid):self.original[str(sid)]}
        out,_,_=v.build_catalog({sid:source,998101:target},base,self.index,self.policy,self.rules,self.profiles)
        self.assertIn(998101,out[str(sid)]["accessories"])
        changed=copy.deepcopy(target);changed["price"]=899
        out,_,_=v.build_catalog({sid:source,998101:changed},base,self.index,self.policy,self.rules,self.profiles)
        self.assertIn(998101,out[str(sid)]["accessories"])
        changed=copy.deepcopy(target);changed["price"]=0
        out,_,_=v.build_catalog({sid:source,998101:changed},base,self.index,self.policy,self.rules,self.profiles)
        self.assertNotIn(998101,out[str(sid)]["accessories"])
        changed=copy.deepcopy(target);changed["field_status"]=0
        out,_,_=v.build_catalog({sid:source,998101:changed},base,self.index,self.policy,self.rules,self.profiles)
        self.assertNotIn(998101,out[str(sid)]["accessories"])
        changed=copy.deepcopy(target);changed["published"]=0
        out,_,_=v.build_catalog({sid:source,998101:changed},base,self.index,self.policy,self.rules,self.profiles)
        self.assertNotIn(998101,out[str(sid)]["accessories"])

    def test_new_source_gets_automatic_accessory_without_manual_relations(self):
        source=copy.deepcopy(self.rows[120298])
        source.update(nid=998201,tnid=998201,vid=998201)
        self.assertNotIn("field_accessories",source);self.assertNotIn("field_similar",source)
        record={"language":"uk","similar":[]}
        targets={n:self.rows[n] for n in (142550,143149,131715,124001)}
        rows={998201:source,**targets}
        out,ev,_=v.build_catalog(rows,{"998201":record},self.index,self.policy,self.rules,self.profiles)
        self.assertTrue(out["998201"]["accessories"])
        self.assertEqual(ev["998201"]["A_model"],[])
        self.assertTrue(ev["998201"]["B_universal"])

    def test_preferred_brands_only_reorder_same_function_role(self):
        source={"brand_tid":3}
        rows={
            1:{"brand_tid":99,"title":"универсальный подстаканник"},
            2:{"brand_tid":67,"title":"Maxi-Cosi подстаканник"},
            3:{"brand_tid":65,"title":"Joolz подстаканник"},
            4:{"brand_tid":65,"title":"Joolz дождевик"},
        }
        ordered=v.commercial_accessory_order([1,2,3,4],source,rows,{},"stroller")
        self.assertEqual(ordered[:3],[3,2,1])
        self.assertEqual(ordered[3:],[4])

    def test_known_bad_universal_examples_and_all_original_similar_lists(self):
        bad={138665,142852,139152,139153,142819}
        for evidence in self.evidence.values():
            self.assertFalse(bad & set(evidence.get("B_universal",[])))
        for sid,record in self.original.items():
            self.assertEqual(self.manifest[sid]["similar"],record["similar"])
            self.assertFalse(set(record["similar"]) & set(self.manifest[sid]["accessories"]))

if __name__=="__main__":
    unittest.main(verbosity=2)
