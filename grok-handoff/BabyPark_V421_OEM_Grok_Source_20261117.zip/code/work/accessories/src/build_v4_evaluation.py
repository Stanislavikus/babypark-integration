#!/usr/bin/env python3
"""Build compact V4 comparison and independent-label evidence artifacts."""
import csv,json,sys,collections
from pathlib import Path
D=Path("/opt/bp-accessories-v4-final-rehearsal-20261112")
sys.path.insert(0,str(D/"src"))
import accessory_v4 as v4

def main():
    metrics=json.loads((D/"output/v4_metrics.json").read_text())
    manifest=json.loads((D/"output/v4_candidate_manifest.json").read_text())["sources"]
    evidence=json.loads((D/"output/v4_candidate_evidence.json").read_text())
    rows=v4.read_rows(D/"input/current_catalog_records.jsonl.gz")
    index=json.loads((D/"input/v36_worker_state.json").read_text())["index"]
    v39=json.loads(Path("/opt/bp-accessory-integration-v39-20261112/evidence/shadow_metrics.json").read_text())
    multi=json.loads(Path("/opt/bp-accessory-category-audit-20261112/multiword_counterfactual.json").read_text())
    labels=json.loads(Path("/opt/bp-recommendations-fitment-evidence-poc-20261111/ADJUDICATED_EVIDENCE.json").read_text())
    confirms=[]
    v39mod=v4.v39
    for c in labels["candidates"]:
        if not c.get("manufacturer_verified_example"):continue
        sid=str(c["source"]);tid=int(c["target"])
        present=tid in manifest.get(sid,{}).get("accessories",[])
        target=rows.get(tid)
        reason="mechanical_or_option_dependency_not_auto_enabled"
        confirms.append({"source_nid":int(sid),"target_nid":tid,"v4_present":present,
                         "decision":c.get("decision"),"v4_exclusion_reason":None if present else reason})
    reasons=collections.Counter()
    for item in evidence.values():
        for target in item.get("targets",{}).values():
            if target.get("tier")=="A_model":reasons[target.get("reason","unknown")]+=1
    bybrand=collections.defaultdict(lambda:collections.Counter())
    for item in metrics["by_brand_type_locale"]:
        if item["type"] not in ("kol","kreslo"):continue
        key=(item["brand_tid"],item["brand"],item["type"])
        for k in ("sources","available","A_sources","B_sources","A_edges","B_edges"):bybrand[key][k]+=item[k]
    out={
      "schema":"babypark-v4-comparison-and-label-evaluation-v1",
      "snapshot":{"catalog_rows":metrics["catalog_rows"],"localized_source_rows":metrics["manifest_sources"],
                  "core_full_build_seconds":metrics["elapsed_seconds"],"full_manifest_preserved_similar":True},
      "incremental_gate":{"real_1c_packet_changed_records":73,"physical_groups":37,
                          "affected_sources":3766,"source_reranks":3697,
                          "worker_max_affected":3000,"cache_event_max_pages":2000,
                          "rehearsal_result":"blocked_before_commit",
                          "current_event_envelope_supports_multiple_parts":False,
                          "keyerror_150_gazellestpe":"patched_in_rehearsal_worker_only"},
      "candidate_counts":{"V39_all_types":{"sources":v39["accessory_sources"],"edges":v39["accessory_edges"]},
                          "V4_model_A":{"sources":metrics["sources_with_A"],"edges":metrics["edges"]["A_model"]},
                          "V4_universal_B":{"sources":metrics["sources_with_B"],"edges":metrics["edges"]["B_universal"]}},
      "multiword_counterfactual_not_publishable":multi["by_type"],
      "model_parser_existing_tests":{"tests":47,"passed":47,"scope":"exact compact forms/enumerations/shorthand and negative generation boundaries; reused"},
      "A_evidence_reason_counts":dict(reasons),
      "universal_inventory_by_locale":metrics["universal_scope_inventory"],
      "manufacturer_verified_positive_sample":confirms,
      "quality":{"manufacturer_positive_relations":len(confirms),
                 "V4_captured":sum(bool(x["v4_present"]) for x in confirms),
                 "recall_on_small_selected_positive_sample":0 if confirms and not any(x["v4_present"] for x in confirms) else None,
                 "precision_and_false_positive_rate":"not_estimable; independent negatives and unbiased labels are unavailable",
                 "manual_reference_fields_used_for_candidate_generation":False},
      "brands":[{"brand_tid":k[0],"brand":k[1],"type":k[2],**v} for k,v in sorted(bybrand.items(),key=lambda x:(x[0][2],x[0][1]))],
      "limitations":["Candidate text evidence is not OEM certification.",
                     "Three known OEM-positive examples are mechanical and excluded by the safety gate.",
                     "No all-category representative positive/negative labeled test set exists.",
                     "Current V3.6 relay/runtime rejects nonempty accessories."]
    }
    (D/"output/v4_evaluation.json").write_text(json.dumps(out,ensure_ascii=False,sort_keys=True,indent=2)+"\n")
    with (D/"output/v4_brand_rollup.csv").open("w",newline="") as f:
        fields=["brand_tid","brand","type","sources","available","A_sources","B_sources","A_edges","B_edges"]
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(out["brands"])
    print(json.dumps({k:v for k,v in out.items() if k!="brands"},ensure_ascii=False,indent=2))
if __name__=="__main__":main()