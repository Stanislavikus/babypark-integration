#!/usr/bin/env python3
"""Strict exact-family model-mention parser for existing BabyPark V3 pipeline.

Candidate discovery only. Not a certificate of accessory fitment. Does not
touch Drupal/manual Node Reference fields or production.
"""
from __future__ import annotations
import re
from typing import Dict, List, Tuple
import sys
sys.path.insert(0, "/opt/bp-accessories-v421-integration-rehearsal-20261112/upstream/v32/engine")
from canonical_models import normal

# For an unambiguous single-token Latin model such as Aer2, Day5, Mios,
# Pebble360. Multiword/generation-rich models stay with the existing parser.
FAMILY = re.compile(r"^(?P<family>[a-z]{3,24})\s*(?P<version>[1-9]\d?|\+)?$", re.I)
ALNUM = r"a-zа-яёіїєґ0-9"

def source_identity(model: str):
    value=normal(model).casefold()
    match=FAMILY.fullmatch(value)
    if not match:
        return None
    family=match.group("family")
    version=match.group("version") or ""
    return family,version

def alternatives_in_title(title: str, family: str) -> Dict[str, str]:
    """Return explicitly mentioned model generations, not fuzzy substrings.

    Aer2/Aer3/Aer and Aer2-Aer3-Aer yield 3 distinct references.
    Aer+/2 yields Aer+ and inferred Aer2; never infer Aer3.
    Aer-20% is a discount, not an Aer20 model.
    """
    text=normal(title).casefold()
    family=re.escape(family.casefold())
    rx=re.compile(
        rf"(?<![{ALNUM}]){family}(?:"
        rf"(?P<plus>\+)|"
        rf"(?:[ \t]*[-]?[ \t]*(?P<number>[1-9]\d?))"
        rf")?(?![{ALNUM}])",
        re.I)
    found={}
    for match in rx.finditer(text):
        end=match.end()
        # "Aer-20%" / "Aer 20 %" is a sale marker, not generation 20.
        if match.group("number") is not None and re.match(r"\s*%",text[end:]):
            continue
        # Aer+2 / Aer++ are not recognized generations.
        if match.group("plus") and end<len(text) and text[end] in "+0123456789":
            continue
        # "Noble Pro", "Aer2 Pro", "Mios Lux" are different versioned
        # identities. Token mention alone may not imply base-model fitment.
        tail=text[end:]
        if re.match(r"^\s+(?:pro|plus|lux|style|gen(?:eration)?\s*\d+|i[- ]?size)\b",tail):
            continue
        if re.match(r"^\s*[/+]\s*(?:pro|plus|lux|style)\b",tail):
            continue
        version=("+" if match.group("plus") else match.group("number") or "")
        found[version]="explicit"
    short=re.compile(
        rf"(?<![{ALNUM}]){family}(?:"
        rf"\+|[ \t]*[-]?[ \t]*[1-9]\d?"
        rf")[ \t]*/[ \t]*(?P<version>[1-9]\d?)(?![{ALNUM}])",
        re.I)
    for match in short.finditer(text):
        after=text[match.end():]
        if re.match(r"\s*%", after):
            continue
        found.setdefault(match.group("version"),"explicit_shorthand")
    return found

def match_exact_model(title: str, source_model: str) -> Tuple[str,str]:
    identity=source_identity(source_model)
    if identity is None:
        return "review_complex_model", "original_parser_required"
    family,variant=identity
    options=alternatives_in_title(title,family)
    if variant not in options:
        return "absent",",".join(sorted(options)) if options else "no_exact_generation"
    return "candidate",options[variant]
