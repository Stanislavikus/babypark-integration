#!/usr/bin/env python3
"""Independent structural/quality gate for the V4.2 candidate."""
import collections, json, sys
from pathlib import Path
ROOT=Path("/opt/bp-accessories-v421-integration-rehearsal-20261112/work/accessories")
sys.path.insert(0,str(ROOT/"src"))
import accessory_v4 as v42

def main():
    rows=v42.read_rows(ROOT/"input/current_catalog_records.jsonl.gz")
    core_count=len(rows)
    help_doc=json.loads((ROOT/"input/help_public_rows_v42.json").read_text())
    for row in help_doc["rows"]:
        if int(row["nid"]) in rows:raise ValueError("supplemental NID duplicates core catalog")
        rows[int(row["nid"])]=row
    base=json.loads((ROOT/"input/current_v36_similarity_only_manifest.json").read_text())["sources"]
    candidate_doc=json.loads((ROOT/"output/v4_candidate_manifest.json").read_text())
    out=candidate_doc["sources"]
    evidence=json.loads((ROOT/"output/v4_candidate_evidence.json").read_text())
    metrics=json.loads((ROOT/"output/v4_metrics.json").read_text())
    index=json.loads((ROOT/"input/v36_worker_state.json").read_text())["index"]
    policy=v42.taxonomy_policy(json.loads((ROOT/"input/taxonomy_terms_v4.json").read_text()))
    rules=json.loads((ROOT/"input/manufacturer_fitment_evidence_v42.json").read_text())["rules"]
    profiles=v42.validate_variant_profiles(json.loads((ROOT/"input/variant_option_profiles_v42.json").read_text())["profiles"])
    errors=[];counts=collections.Counter();target_unique=collections.defaultdict(set)
    by_group=collections.defaultdict(lambda:collections.Counter());by_brand=collections.defaultdict(lambda:collections.Counter())
    for sid,record in base.items():
        source=rows.get(int(sid));got=out.get(sid)
        if source is None or got is None:errors.append("missing_source:"+sid);continue
        if got.get("similar")!=record.get("similar"):errors.append("similar_changed:"+sid)
        if source.get("lang")!=record.get("language"):errors.append("source_language:"+sid)
        ids=got.get("accessories",[])
        if len(ids)>20 or len(ids)!=len(set(ids)):errors.append("duplicate_or_limit:"+sid)
        if set(ids)&set(got.get("similar",[])):errors.append("similar_overlap:"+sid)
        ev=evidence.get(sid,{"A_model":[],"B_universal":[],"targets":{}})
        a=list(ev.get("A_model",[]));b=list(ev.get("B_universal",[]))
        if ids!=a+b:errors.append("tier_order:"+sid)
        if len(b)>3:errors.append("B_limit:"+sid)
        if len({ev.get("targets",{}).get(str(t),{}).get("role") for t in b})!=len(b):
            errors.append("duplicate_B_role:"+sid)
        head=v42.source_head(source,policy)
        if ids and (not head or not v42.eligible_source(source)):errors.append("ineligible_source:"+sid)
        a_roles=set()
        for tid in a:
            target=rows.get(int(tid))
            if target is None:errors.append("missing_A_target:%s:%s"%(sid,tid));continue
            why=ev["targets"][str(tid)]
            if why.get("reason")=="accepted_manufacturer_verified_fitment":
                proof=v42.manufacturer_fitment_match(source,target,policy,rules,profiles)
                if not proof or proof.get("evidence_key")!=why.get("evidence_key"):
                    errors.append("invalid_manufacturer_A:%s:%s"%(sid,tid))
                role=proof.get("role") if proof else None
                counts["manufacturer_verified_A_edges"]+=1
            else:
                model=v42.v39.group_model(source,index)
                status=v42.v39.reason_for(source,target,model)
                if not status.startswith("accepted_") or status!=why.get("reason"):
                    errors.append("invalid_text_A:%s:%s"%(sid,tid))
                role=v42.target_role(target,head)
                counts["text_A_edges"]+=1
            if role:a_roles.add(role)
            if target.get("type")=="product_kit":errors.append("kit_target_A:%s:%s"%(sid,tid))
            target_unique["A"].add(int(tid));counts["A_edges"]+=1
        b_roles=set()
        for tid in b:
            target=rows.get(int(tid))
            if target is None:errors.append("missing_B_target:%s:%s"%(sid,tid));continue
            scope=v42.broad_scope(target,head)
            saved=ev.get("targets",{}).get(str(tid),{})
            if not scope or scope.get("role")!=saved.get("role"):
                errors.append("invalid_B_scope:%s:%s"%(sid,tid));continue
            if scope.get("requires_isofix") and not v42.source_supports_isofix(source):
                errors.append("missing_source_installation_scope:%s:%s"%(sid,tid))
            if target.get("type")=="help":
                if not scope.get("requires_isofix") or not v42._option_profile(target,profiles,None)["ok"]:
                    errors.append("unverified_help_target:%s:%s"%(sid,tid))
                counts["cross_type_B_edges"]+=1
            elif target.get("type")!=source.get("type"):
                errors.append("unapproved_cross_type:%s:%s"%(sid,tid))
            if int(target.get("published") or 0)!=1 or int(target.get("field_status") or 0)!=1 or float(target.get("price") or 0)<=0:
                errors.append("unavailable_B:%s:%s"%(sid,tid))
            if target.get("lang")!=source.get("lang") or target.get("tnid")==source.get("tnid"):
                errors.append("language_or_translation_mismatch:%s:%s"%(sid,tid))
            if target.get("type")=="product_kit":errors.append("kit_target_B:%s:%s"%(sid,tid))
            b_roles.add(scope["role"]);target_unique["B"].add(int(tid));counts["B_edges"]+=1
        if a_roles & b_roles:errors.append("functional_role_repeated_A_B:"+sid)
        group=(head or "excluded",source.get("type"),source.get("lang"))
        by_group[group]["source_pages"]+=1
        if v42.eligible_source(source):by_group[group]["available_pages"]+=1
        if a:by_group[group]["A_pages"]+=1
        if b:by_group[group]["B_pages"]+=1
        by_group[group]["A_edges"]+=len(a);by_group[group]["B_edges"]+=len(b)
        brand=(source.get("brand_tid"),source.get("brand") or "unknown",source.get("type"),source.get("lang"))
        by_brand[brand]["source_pages"]+=1
        if v42.eligible_source(source):by_brand[brand]["available_pages"]+=1
        if a:by_brand[brand]["A_pages"]+=1
        if b:by_brand[brand]["B_pages"]+=1
        by_brand[brand]["A_edges"]+=len(a);by_brand[brand]["B_edges"]+=len(b)
    known_bad={138665,142852,139152,139153,142819}
    if any(known_bad & set(ev.get("B_universal",[])) for ev in evidence.values()):
        errors.append("known_false_universal_returned")
    expected_pairs=((144884,144886),(144885,144887),
                    (145237,145239),(145238,145240),
                    (145262,145264),(145263,145265))
    proof_pairs=[]
    for sid,tid in expected_pairs:
        if str(sid) not in base:errors.append("proof_source_outside_v36_roster:"+str(sid));continue
        if tid not in evidence.get(str(sid),{}).get("A_model",[]):
            errors.append("manufacturer_positive_missing:%s:%s"%(sid,tid))
        else:proof_pairs.append([sid,tid])
    cross_targets=sorted(target_unique["B"] & {int(r["nid"]) for r in help_doc["rows"]})
    out_doc={"schema":"bp-v42-independent-quality-validation-v1",
      "passed":not errors,"errors":errors,"counts":dict(counts),
      "catalog":{"core_localized_rows":core_count,"supplemental_help_rows":len(help_doc["rows"]),
                 "calculation_rows":len(rows),"localized_source_rows":len(base)},
      "similar_lists_identical":not any(e.startswith("similar_changed:") for e in errors),
      "manual_reference_fields_used":False,
      "manufacturer_verified_localized_pairs":proof_pairs,
      "manufacturer_verified_unique_physical_examples":3,
      "help_cross_type_unique_localized_targets":cross_targets,
      "unique_target_nids_by_tier":{k:len(v) for k,v in target_unique.items()},
      "target_unique_nids_by_tier":{k:sorted(v) for k,v in target_unique.items()},
      "by_source_head_type_locale":[{"head":k[0],"type":k[1],"lang":k[2],**v} for k,v in sorted(by_group.items())],
      "by_brand_type_locale":[{"brand_tid":k[0],"brand":k[1],"type":k[2],"lang":k[3],**v} for k,v in sorted(by_brand.items(),key=lambda x:(str(x[0][2]),str(x[0][3]),str(x[0][1])))],
      "metrics":metrics,
      "quality_limits":{"precision_recall":"not estimable: no representative independent labels",
                        "known_negative_universal_targets_checked":5,
                        "known_positive_manufacturer_localizations_expected":6}}
    path=ROOT/"output/v42_validation.json"
    if path.exists():raise FileExistsError(path)
    path.write_text(json.dumps(out_doc,ensure_ascii=False,sort_keys=True,indent=2)+"\n")
    print(json.dumps({k:v for k,v in out_doc.items() if k not in ("by_brand_type_locale","target_unique_nids_by_tier","metrics")},ensure_ascii=False,indent=2))
    if errors:raise SystemExit(1)
if __name__=="__main__":main()
