#!/usr/bin/env python3
"""BabyPark automatic-only accessory candidates for V3.6 incremental worker.

Same existing 1C read-only catalog, shared physical bilingual model index,
V3 accessory nouns and option-dependency safeguards.  Never uses manual
field_accessories.  Candidate only; Stage1 revalidates selected variants.
"""
from __future__ import annotations
import collections
import re
import sys

from ordered_model_v41 import match_exact_model
import v32_pipeline as pipe
import v3_rules
from canonical_models import normal

POSITIVE=v3_rules.FITMENT_START
NEGATIVE=v3_rules.NEGATIVE
SEPARATOR=re.compile(r"(?<=[.!?;])\s+|[\r\n]+")
TEXT_HARDWARE=re.compile(r"(?i)(?:адаптер\w*|adapter\w*|isofix|баз[аыу]\b|люльк\w*|carrycot|"
                          r"шас[ссі]\w*|шасс\w*|реверсивн\w*|reverse\w*|"
                          r"бампер\w*|bumper|seat\s*base|креплен\w*|кріплен\w*)")

def explicit_accessory(row):
    """Require exact native accessory category AND concrete accessory role."""
    if not row or row.get("type")=="product_kit" or row.get("translation_ambiguous"):
        return False
    if int(row.get("published") or 0)!=1 or int(row.get("field_status") or 0)!=1 or float(row.get("price") or 0)<=0:
        return False
    cats=row.get("cats","").casefold()
    if not ("аксессуар" in cats or "аксесуар" in cats):
        return False
    return bool(v3_rules.accessory_class(row.get("title",""),row.get("body",""),pipe.categories(row)))

def group_model(source,index):
    if source.get("type") not in pipe.ACCESSORY_SOURCE_TYPES:
        return None
    if source.get("type")=="product_kit" or pipe.accessory_class(source.get("title",""),"",pipe.categories(source)):
        return None
    info=index.get("source_models",{}).get(str(source.get("tnid")))
    if not info or info.get("index_status")!="indexed" or info.get("brand_tid")!=source.get("brand_tid"):
        return None
    if set(info.get("locales",{}))!={"uk","ru"} or set(info.get("models",{}))!={"uk","ru"}:
        return None
    lang=source["lang"]
    if info["locales"].get(lang,{}).get("nid")!=source["nid"]:
        return None
    return info["models"][lang]

def reason_for(source,target,model):
    if not model or not explicit_accessory(target):return "blocked_role_or_model"
    if (source["nid"]==target["nid"] or source["tnid"]==target["tnid"] or
        source["lang"]!=target["lang"] or source["brand_tid"]!=target["brand_tid"] or
        source["type"]!=target["type"]):
        return "blocked_identity"
    # Mechanical parts and physical install compatibility require an explicit
    # manufacturer fitment matrix, not just an extracted title or sentence.
    title=normal(target.get("title",""))
    if TEXT_HARDWARE.search(title):
        return "blocked_mechanical_fitment"
    kind=v3_rules.accessory_class(title,target.get("body",""),pipe.categories(target))
    dep=v3_rules.unresolved_candidate_requirements(
        source["type"],title,target.get("body",""),source.get("title",""),"",kind)
    if dep:return dep
    # If the source name explicitly refers to a differently versioned model,
    # the very strict family/variant matcher must return ABSENT, not partial.
    hit,source_txt=match_exact_model(title,model)
    if hit=="candidate":
        return "accepted_model_title"
    if hit=="version_review" and not re.search(
            r"(?i)/\s*(?:pro|plus|lux|style)\s*\(\s*\d+\s*\)",title):
        return "blocked_versioned_accessory_title"
    # If the accessory title names an explicitly different generation,
    # a generic line in its description about this family must NOT override
    # the more specific title (e.g. Mios Style vs plain Mios, Aer3 vs Aer2).
    older,detail=pipe.cm.exact_mention(title,model)
    if older=="version_review":
        # Some explicit manufacturer compatibility descriptions override
        # ambiguous slash shorthand such as Pebble 360/PRO(2) in the
        # accessory title. This exception still requires a POSITIVE exact
        # model enumeration in the same sentence below.
        if not re.search(r"(?i)/\s*(?:pro|plus|lux|style)\s*\(\s*\d+\s*\)",title):
            return "blocked_versioned_accessory_title"
    for sentence in SEPARATOR.split(normal(target.get("body",""))):
        if not 0<len(sentence)<=850 or NEGATIVE.search(sentence) or not POSITIVE.search(sentence):
            continue
        hit,detail=match_exact_model(sentence,model)
        if hit=="candidate":
            return "accepted_model_positive_body"
    return "absent_explicit_model"

def build_pool(rows):
    pools=collections.defaultdict(list)
    for row in rows.values():
        if explicit_accessory(row):
            pools[(row["brand_tid"],row["lang"],row["type"])].append(row)
    for group in pools.values():group.sort(key=lambda r:r["nid"])
    return pools

def rank_source(source,index,pool):
    model=group_model(source,index)
    if not model:return [],{"reason":"no_confirmed_identity","model":None}
    matches=[]
    for target in pool.get((source["brand_tid"],source["lang"],source["type"]),()):
        why=reason_for(source,target,model)
        if why.startswith("accepted_"):
            score=0 if why=="accepted_model_title" else 1
            matches.append((score,target["nid"],why))
    matches.sort()
    result=[nid for score,nid,reason in matches[:20]]
    if len(result)!=len(set(result)):raise ValueError("duplicate accessory candidates")
    return result,{"model":model,"available_candidates":len(matches),
                   "selected":len(result),"policy":"explicit_text_non_mechanical_no_manual"}

def affected_by_accessory(row,index):
    """On new/changed 1C accessory row: dynamic reverse model event lookup."""
    if not explicit_accessory(row):return set()
    hits=set()
    brand=row["brand_tid"];lang=row["lang"]
    for info in index.get("source_models",{}).values():
        if (info.get("index_status")!="indexed" or info.get("brand_tid")!=brand or
            lang not in info.get("locales",{})):
            continue
        snid=info["locales"][lang]["nid"]
        # Only exact model matches; a shared brand by itself never qualifies.
        source={"nid":snid,"tnid":info["tnid"],"lang":lang,"type":info["type"],
                "brand_tid":brand,"title":info["models"][lang],
                "cats":"","published":1}
        model=info["models"][lang]
        if (source["type"]==row["type"] and reason_for(source,row,model).startswith("accepted_")):
            hits.add(snid)
    return hits
