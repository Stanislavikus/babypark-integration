#!/usr/bin/env python3
"""Independent structural validation for the final V4 rehearsal output."""
import json,sys,collections
from pathlib import Path
D=Path("/opt/bp-accessories-v41-targeted-rehearsal-20261112")
sys.path.insert(0,str(D/"src"))
import accessory_v4 as v4

def main():
    rows=v4.read_rows(D/"input/current_catalog_records.jsonl.gz")
    base=json.loads((D/"input/current_v36_similarity_only_manifest.json").read_text())["sources"]
    out=json.loads((D/"output/v4_candidate_manifest.json").read_text())["sources"]
    evidence=json.loads((D/"output/v4_candidate_evidence.json").read_text())
    policy=v4.taxonomy_policy(json.loads((D/"input/taxonomy_terms_v4.json").read_text()))
    errors=[];counts=collections.Counter();by=collections.defaultdict(collections.Counter)
    if len(rows)!=28011:errors.append("catalog_count")
    if len(base)!=8471 or len(out)!=len(base):errors.append("manifest_source_count")
    for sid,record in base.items():
        got=out.get(sid);source=rows.get(int(sid))
        if not got or not source:errors.append("missing_source:"+sid);continue
        if got["similar"]!=record["similar"]:errors.append("similar_changed:"+sid)
        if source["lang"]!=record["language"]:errors.append("source_language:"+sid)
        ids=got["accessories"]
        if len(ids)>20 or len(ids)!=len(set(ids)):errors.append("list_bound_or_duplicate:"+sid)
        if set(ids)&set(got["similar"]):errors.append("similar_accessory_overlap:"+sid)
        ev=evidence.get(sid,{"A_model":[],"B_universal":[],"targets":{}})
        a=list(ev["A_model"]);b=list(ev["B_universal"])
        if ids!=a+b:errors.append("tier_order_or_evidence_mismatch:"+sid)
        if len(b)>3:errors.append("universal_cap:"+sid)
        if len({ev["targets"][str(i)].get("role") for i in b})!=len(b):errors.append("duplicate_B_role:"+sid)
        head=v4.source_head(source,policy)
        if ids and (not head or not v4.eligible_source(source)):errors.append("ineligible_source:"+sid)
        for tid in ids:
            target=rows.get(int(tid))
            if not target:errors.append("missing_target:%s:%s"%(sid,tid));continue
            counts["edges"]+=1
            if int(target.get("published") or 0)!=1 or int(target.get("field_status") or 0)!=1 or float(target.get("price") or 0)<=0:
                errors.append("unavailable_target:%s:%s"%(sid,tid))
            if target["lang"]!=source["lang"]:errors.append("cross_language:%s:%s"%(sid,tid))
            if target["type"]!=source["type"]:errors.append("cross_type:%s:%s"%(sid,tid))
            if int(target["tnid"])==int(source["tnid"]):errors.append("same_physical_product:%s:%s"%(sid,tid))
            if v4.target_head(target,policy)!=head:errors.append("wrong_target_category:%s:%s"%(sid,tid))
            meta=ev["targets"].get(str(tid),{})
            if meta.get("tier")=="A_model":
                if not str(meta.get("reason","")).startswith("accepted_"):errors.append("A_evidence:"+sid)
                counts["A_edges"]+=1
            elif meta.get("tier")=="B_universal":
                scope=v4.broad_scope(target,head) if head else None
                if not scope:errors.append("B_scope:"+sid+":"+str(tid))
                elif scope.get("brand_tid") and scope["brand_tid"]!=int(source.get("brand_tid") or 0):
                    errors.append("B_brand_scope:"+sid+":"+str(tid))
                counts["B_edges"]+=1
            else:errors.append("missing_tier:"+sid+":"+str(tid))
        if ids:
            counts["sources_with_any"]+=1
            by[(head,source["lang"])]["sources"]+=1
            by[(head,source["lang"])]["A_edges"]+=len(a)
            by[(head,source["lang"])]["B_edges"]+=len(b)
        if v4.eligible_source(source):
            by[(head,source["lang"])]["available"]+=1
            if a:by[(head,source["lang"])]["available_with_A"]+=1
            if b:by[(head,source["lang"])]["available_with_B"]+=1
    manual_keys={"field_similar","field_accessories"}
    if any(manual_keys & set(r) for r in rows.values()):errors.append("manual_field_present_in_input")
    report={"schema":"babypark-v4-independent-validation-v1","catalog_rows":len(rows),
            "source_manifest_rows":len(base),"validated_source_rows":len(out),
            "similar_lists_identical":not any(x.startswith("similar_changed:") for x in errors),
            "manual_reference_fields_in_input":False,"edges":dict(counts),
            "by_category_locale":[{"head":k[0],"lang":k[1],**v} for k,v in sorted(by.items(),key=lambda x:str(x[0]))],
            "errors":errors,"pass":not errors}
    path=D/"output/v4_validation.json"
    if path.exists():path.unlink()
    path.write_text(json.dumps(report,ensure_ascii=False,sort_keys=True,indent=2)+"\n")
    print(json.dumps(report,ensure_ascii=False,indent=2))
    if errors:raise SystemExit(1)
if __name__=="__main__":main()