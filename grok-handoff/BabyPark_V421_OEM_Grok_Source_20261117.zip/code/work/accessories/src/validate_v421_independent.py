#!/usr/bin/env python3
"""Independent manifest validator; does not import the recommendation builder."""
import gzip,json,re,sys
from collections import Counter
from pathlib import Path

ROOT=Path("/opt/bp-accessories-v421-integration-rehearsal-20261112/work/accessories")
def load_json(path): return json.loads(Path(path).read_text(encoding="utf-8"))
def norm(s): return re.sub(r"\s+"," ",re.sub(r"<[^>]*>"," ",str(s or ""))).strip().casefold()
def cats(row):
    return {p.split(":",1)[0] for p in str(row.get("cats") or "").split("|") if ":" in p}
def role(row):
    t=norm(row.get("title"))
    if re.search(r"(?:муфт\w*|muff).{0,40}(?:ручк\w*|handle)|(?:ручк\w*|handle).{0,40}(?:муфт\w*|muff)",t): return "handle_muff"
    if re.search(r"(?:чехол|чохол)\s+(?:для|на)\s+(?:ног|ніг)|foot[ -]?muff",t): return "footmuff"
    rules=[
      ("cup_holder",r"подстаканник|підсклянник|cup\s*holder"),
      ("rain_cover",r"дождевик|дощовик|rain\s*cover"),
      ("mosquito_net",r"москитн|москітн|mosquito\s*net"),
      ("seat_liner",r"вкладыш|вкладиш|liner|вкладка"),
      ("bag",r"сумк|\bbag\b|органайзер|organizer"),
      ("adapter",r"адаптер|adapter"),
      ("bassinet",r"люльк|bassinet"),
      ("footmuff",r"конверт|муфт|footmuff"),
      ("textile_cover",r"чехол|чохол|textile|текстил|cover"),
      ("stroller_board",r"подножк.*втор|підніжк.*друг|kidboard|wheeled board"),
      ("hook",r"крюч|гачок|hook"),
    ]
    return next((label for label,pat in rules if re.search(pat,t)),None)

def main():
    inp=ROOT/"input"; out=ROOT/"output"
    rows={int(json.loads(line)["nid"]):json.loads(line) for line in gzip.open(inp/"current_catalog_records.jsonl.gz","rt",encoding="utf-8")}
    orig=load_json(inp/"current_v36_similarity_only_manifest.json")["sources"]
    man=load_json(out/"v4_candidate_manifest.json")["sources"]
    ev=load_json(out/"v4_candidate_evidence.json")
    help_rows=load_json(inp/"help_public_rows_v42.json")["rows"]
    help_ids={int(x["nid"]) for x in help_rows}
    errs=[]; counts=Counter(); cross_types=Counter(); target_unique=set(); per_lang=Counter(); roles_by_tier=Counter()
    if len(rows)!=28011: errs.append("catalog_row_count")
    if len(orig)!=8471 or set(man)!=set(orig): errs.append("manifest_source_scope")
    for sid,old in orig.items():
        entry=man.get(sid)
        if not entry: continue
        source=rows.get(int(sid))
        if not source: errs.append("missing_source:"+sid); continue
        if entry.get("similar")!=old.get("similar"): errs.append("similar_changed:"+sid)
        aids=ev.get(sid,{}).get("A_model",[])
        bids=ev.get(sid,{}).get("B_universal",[])
        if entry.get("accessories",[])!=aids+bids: errs.append("tier_order_or_evidence_mismatch:"+sid)
        all_ids=entry.get("accessories",[])
        if len(all_ids)!=len(set(all_ids)): errs.append("duplicate_target:"+sid)
        if set(all_ids)&set(old.get("similar",[])): errs.append("similar_overlap:"+sid)
        aroles=set()
        for tid in aids:
            target=rows.get(int(tid))
            if not target: errs.append(f"missing_A_target:{sid}:{tid}"); continue
            target_unique.add(int(tid)); counts["A_edges"]+=1
            if target.get("lang")!=source.get("lang"): errs.append(f"cross_language_A:{sid}:{tid}")
            if int(target.get("published") or 0)!=1 or int(target.get("field_status") or 0)!=1 or float(target.get("price") or 0)<=0: errs.append(f"ineligible_A:{sid}:{tid}")
            r=role(target)
            if r: aroles.add(r)
        broles=set()
        detail=ev.get(sid,{}).get("targets",{})
        for tid in bids:
            target=rows.get(int(tid))
            if not target: errs.append(f"missing_B_target:{sid}:{tid}"); continue
            target_unique.add(int(tid)); counts["B_edges"]+=1
            per_lang[source.get("lang","?")]+=1
            if target.get("lang")!=source.get("lang"): errs.append(f"cross_language_B:{sid}:{tid}")
            if int(target.get("published") or 0)!=1 or int(target.get("field_status") or 0)!=1 or float(target.get("price") or 0)<=0: errs.append(f"ineligible_B:{sid}:{tid}")
            if target.get("type") in ("help","product_kit"): errs.append(f"forbidden_type_B:{sid}:{tid}")
            if int(tid) in help_ids: errs.append(f"help_import_B:{sid}:{tid}")
            if not (cats(target)&{"20","134","140","1536","1604"}): errs.append(f"outside_accessory_taxonomy:{sid}:{tid}")
            tx=target.get("type","?")
            cross_types[tx]+=int(tx!=source.get("type"))
            info=detail.get(str(tid),{})
            sentence=norm(info.get("evidence"))
            body=norm(target.get("body")); title=norm(target.get("title"))
            if not sentence or sentence not in (body+" "+title): errs.append(f"B_evidence_not_in_target:{sid}:{tid}")
            if not re.search(r"\b(?:all|most|universal\w*|універсальн\w*|универсальн\w*|вс\w*|ус\w*|люб\w*\s+тип\w*|більшост\w*|большинств\w*)\b",sentence):
                errs.append(f"B_scope_not_quantified:{sid}:{tid}")
            rr=role(target)
            if not rr or rr!=info.get("role"): errs.append(f"B_role_mismatch:{sid}:{tid}")
            if rr: broles.add(rr); roles_by_tier["B:"+rr]+=1
            if rr=="vehicle_seat_protector": errs.append(f"seat_mat_B:{sid}:{tid}")
        if len(broles)!=len(bids): errs.append("B_role_duplicate_or_unknown:"+sid)
        if aroles&broles: errs.append("A_B_role_overlap:"+sid)
    metrics=load_json(out/"v4_metrics.json")
    if metrics.get("manual_fields_read") is not False or metrics.get("manual_fallback") is not False: errs.append("manual_relation_usage_flag")
    if metrics.get("help_rows_imported")!=0: errs.append("help_rows_imported")
    if metrics.get("catalog_rows")!=28011 or metrics.get("manifest_sources")!=8471: errs.append("metric_dimensions")
    result={"schema":"babypark-v421-independent-validation-v1","status":"PASS" if not errs else "FAIL",
      "source_rows":len(rows),"sources_checked":len(orig),"unique_targets":len(target_unique),
      "A_edges":counts["A_edges"],"B_edges":counts["B_edges"],
      "cross_type_B_edges_by_target_type":dict(cross_types),"B_edges_by_source_language":dict(per_lang),
      "manual_fields_read":False,"help_rows_imported":0,"similar_lists_preserved":True,
      "error_count":len(errs),"errors":errs[:300]}
    path=out/"v421_independent_validation.json"; path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return bool(errs)
if __name__=="__main__": sys.exit(main())
