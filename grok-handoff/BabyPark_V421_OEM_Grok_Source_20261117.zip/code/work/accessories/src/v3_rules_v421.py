#!/usr/bin/env python3
"""Small deterministic BabyPark V3 product-role and recommendation gates."""
import html
import re
import unicodedata

def generation_suffix_after_tokens(vals, pos):
    """Return a known adjacent generation/configuration suffix after a model token span."""
    if pos >= len(vals):
        return ""
    if vals[pos] in {"lux", "pro", "pro2", "plus", "2", "3", "4", "/", "/5", "geo5", "i-size", "isize"}:
        return vals[pos]
    if vals[pos] == "i" and pos + 1 < len(vals) and vals[pos + 1] in {"size", "size2"}:
        return "i-size"
    return ""

def norm(text):
    text = unicodedata.normalize("NFKC", html.unescape(text or ""))
    for a, b in zip("⁰¹²³⁴⁵⁶⁷⁸⁹", "0123456789"):
        text = text.replace(a, b)
    return re.sub(r"\s+", " ", text.lower()).strip()

def fulltext(row):
    return norm(" ".join(str(row.get(k) or "") for k in ("title", "body", "body_html")))

HEADS = {
    "toy": [
        ("roly_poly", r"неваляш\w*|tumbler|roly[- ]?poly"),
        ("ball", r"мяч\w*|м['’]яч\w*|\bball\b"),
        ("fidget", r"попит|pop\s?it|fidget"),
        ("pretend_food", r"пицц\w*|pizza|игров\w* кухн|набор\w* продукт|набір\w* продукт|play food|pretend food|\bkitchen set\b"),
        ("science_kit", r"эксперимент\w*|досліджен\w*|набор\w* для исследований|набір\w* для досліджень|\bscience kit\b"),
        ("construction_manipulative", r"блок\w* с винт\w*|блок\w* з гвинт\w*|манипулятив\w*|маніпулятив\w*|screw block|винтов\w*"),
        ("math_learning_kit", r"математ\w* знак|math(?:ematics)?\s+(?:sign|set)|набор\w* для обучения|набір\w* для навчання"),
        ("water_toy", r"игруш\w* для игр\w* в вод|іграш\w* для гр\w* у вод|игруш\w* для купан|іграш\w* для купан|water toy|bath toy"),
        ("doll", r"кукл\w*|\bdoll\b"),
        ("rattle", r"погремуш\w*|брязкал\w*|\brattle\b"),
        ("puzzle", r"пазл\w*|головолом\w*|\bpuzzle\b"),
        ("blocks", r"конструктор\w*|кубик\w*|\bblocks?\b|building\s+set"),
        ("book", r"книг\w*|книжк\w*|\bbook\b"),
        ("play_mat", r"коврик\w*|килимок\w*|play\s+mat"),
        ("toy_vehicle", r"машинк\w*|автомобил\w* игрушк|\btoy\s+car\b"),
    ],
    "wear": [
        ("suit_set", r"костюм\w*|комплект\w* одежд|набор\w* одежд|набір\w* одяг"),
        ("reglan", r"реглан\w*|\bsweatshirt\b"),
        ("bodysuit", r"боди\w*|боді\w*|\bbodysuit\b"),
        ("bib_overalls", r"напівкомбінезон\w*|полукомбинезон\w*|\boveralls\b"),
        ("sleepsuit", r"комбинезон\s*[-—]?\s*человечек|комбінезон\s*[-—]?\s*чоловічок|человечек|чоловічок|\bслип\w*|\bbabygrow\b|\bsleepsuit\b|закрыт\w* дизайн ног|закрит\w* дизайн ніжок"),
        ("romper", r"комбинезон\w*|комбінезон\w*|\bromper\b"),
        ("dress", r"плать\w*|сукн\w*|\bdress\b"),
        ("shirt", r"футболк\w*|\bshirt\b|\bt-?shirt\b"),
        ("pants", r"штан\w*|брюк\w*|\bpants?\b|\btrousers\b"),
        ("shorts", r"шорт\w*|\bshorts\b"),
        ("jacket", r"куртк\w*|кофт\w*|свитер\w*|светр\w*|\bjacket\b|\bsweater\b"),
        ("pajamas", r"пижам\w*|піжам\w*|\bpajamas?\b"),
        ("socks", r"носк\w*|шкарпет\w*|\bsocks?\b"),
        ("hat", r"шапк\w*|шапочк\w*|\bhat\b"),
    ],
    "mebel": [
        ("rocking_center", r"качел\w*|качалк\w*|гойдал\w*|заколисуюч\w* центр|укачивающ\w* центр|\bswing\b|\bbouncer\b|\brocker\b|шезлонг\w*"),
        ("bed_guard", r"барьер\w* для кроват|барьер\w* для кроватк|бар'єр\w* для ліжк|бар'єрк\w*|\bbed guard\b"),
        ("crib_mechanism", r"маятник\w* механизм|механизм\w* маятник|маятников\w* механизм|маятник\w* механізм|механізм\w* маятник|pendulum mechanism"),
        ("high_chair", r"стульчик\w* для кормлен|стул\w* для кормлен|кресло\w* для кормлен|стільчик\w* для годуван|стілець\w* для годуван|крісло\w* для годуван|feeding\s+chair|high\s*chair"),
        ("chair", r"стульчик\w*|стул\w*|стільчик\w*|стілец\w*|стільц\w*|\bchair\b"),
        ("desk", r"парт\w*|стол\w*|стіл(?!ьчик|ець)\w*|\bdesk\b|\btable\b"),
        ("crib", r"кроват\w*|ліжечк\w*|ліжк\w*|\bbed\b|\bcrib\b|\bcot\b"),
        ("mattress", r"матрас\w*|матрац\w*|\bmattress\b"),
        ("dresser", r"комод\w*|\bdresser\b"),
        ("wardrobe", r"шкаф\w*|\bwardrobe\b"),
        ("changing_table", r"пеленальн\w*|сповивал\w*|changing\s+table"),
        ("bath", r"ванн\w*|\bbath\b"),
    ],
    "transport": [
        ("tricycle", r"трехколесн\w*(?:\s+\w+){0,2}\s+велосипед|триколесн\w*|триколісн\w*|велосипед\w* триколес|\btricycle\b|\btrike\b"),
        ("bicycle", r"велосипед\w*|\bbicycle\b|\bbike\b"),
        ("scooter", r"самокат\w*|\bscooter\b"),
        ("ride_on", r"каталк\w*|толокар\w*|\bride[- ]?on\b"),
        ("walker", r"ходунк\w*|ходун\w*|\bwalker\b"),
    ],
    "kol": [
        ("stroller_part", r"база коляск|шасси\b|шасі\b|адаптер\s+для\s+коляск|колес\w* для коляск"),
        ("stroller", r"коляск\w*|\bstroller\b|\bbuggy\b|модульн\w* систем\w*"),
    ],
    "kreslo": [
        ("car_seat_base", r"база для автокресл|base\s+for\s+(?:a\s+)?car\s+seat"),
        ("car_seat", r"автокресл\w*|автокрісл\w*|\bcar\s+seat\b|\bchild\s+seat\b"),
    ],
}
BUNDLE_RE = re.compile(r"комплект|набор|набір|\bset\b|\bkit\b", re.I)
DOUBLE_RE = re.compile(r"двойн|двійн|близнец|twin|double|duo|для\s+двух\s+дет|для\s+двох\s+діт", re.I)
MULTI_CHILD_STROLLER_RE = re.compile(r"(?:для\s+(?:двойн\w*|двійн\w*|близнец\w*|двух\s+дет\w*|двох\s+діт\w*)|(?:двойн\w*|двійн\w*)\s+(?:коляск\w*|візк\w*)|\b(?:twin|double)\s+(?:stroller|buggy|pram|pushchair)\b|\bfor\s+(?:two|2)\s+(?:children|kids)\b|\b(?:two|2)[ -]seater\b)", re.I)
SINGLE_CHILD_STROLLER_RE = re.compile(r"(?:\b(?:single|one)[ -]?(?:child|seat|seater)\s+(?:stroller|buggy|pram|pushchair)\b|\bfor\s+(?:one|1)\s+(?:child|kid)\b|(?:одноместн\w*|одномісн\w*).{0,50}(?:коляск\w*|візк\w*)|(?:коляск\w*|візк\w*).{0,50}(?:одноместн\w*|одномісн\w*)|для\s+однієї\s+дитини|для\s+одного\s+реб[её]нк\w*)", re.I)
TRAVEL_RE = re.compile(r"(?:2|3)\s*(?:в|in)\s*1|2в1|3в1|модульн\w* систем|universal\s+system", re.I)
WALKING_RE = re.compile(r"прогулочн\w*|прогулянков\w*|\bwalking\b", re.I)
GENDER = {
    "female": re.compile(r"для\s+девоч|для\s+дівчат|girl|female", re.I),
    "male": re.compile(r"для\s+мальчик|для\s+хлопц|boy|male", re.I),
}

def _head(text, typ):
    for label, pattern in HEADS.get(typ, []):
        if re.search(pattern, text, re.I):
            return label
    return None

def _kit_heads(text):
    vals = []
    checks = [
        ("stroller", r"коляск\w*|\bstroller\b"),
        ("car_seat", r"автокресл\w*|автокрісл\w*|\bcar\s+seat\b"),
        ("crib", r"кроват\w*|ліжечк\w*|ліжк\w*|\bbed\b|\bcrib\b"),
        ("desk", r"парт\w*|стол\w*|стіл(?!ьчик)\w*|\bdesk\b|\btable\b"),
        ("chair", r"стул\w*|стільчик\w*|стілец\w*|стільц\w*|стульчик\w*|\bchair\b"),
        ("high_chair", r"стульчик\w* для кормлен|стільчик\w* для годуван"),
    ]
    for label, pattern in checks:
        if re.search(pattern, text, re.I):
            vals.append(label)
    return sorted(set(vals))

def functional_signature(row):
    typ = row.get("type", "")
    title = norm(row.get("title", ""))
    body = norm(row.get("body", "") or row.get("body_html", ""))
    early = body[:500]
    head = _head(title, typ) or _head(early, typ)
    sig = {"type": typ, "head": head, "role": "single", "child_capacity": None,
           "stroller_mode": None, "travel_config": None, "bundle_components": [],
           "furniture_purpose": None, "gender": None, "weight_range": None, "wheel_size_inches": None}
    if typ == "product_kit":
        component_text = str(row.get("kit_component_titles", ""))
        kit_text = title + " " + norm(component_text) + " " + early
        sig["role"] = "bundle"
        sig["bundle_components"] = _kit_heads(kit_text)
        sig["head"] = "kit:" + "+".join(sig["bundle_components"]) if sig["bundle_components"] else None
        sig["child_capacity"] = "double" if DOUBLE_RE.search(kit_text) else "single_unspecified"
        if TRAVEL_RE.search(kit_text):
            sig["stroller_mode"] = "travel_system"
            m = re.search(r"([23])\s*(?:в|in)\s*1|([23])в1", kit_text, re.I)
            if m: sig["travel_config"] = next(g for g in m.groups() if g)
        elif WALKING_RE.search(kit_text):
            sig["stroller_mode"] = "walking"
    elif typ == "mebel":
        category_ids = {x.split(":", 1)[0] for x in str(row.get("cats", "")).split("|") if ":" in x}
        if head == "chair" and category_ids & {"21", "147"}:
            head = "high_chair"
            sig["head"] = head
        classes = _kit_heads(title)
        is_bundle = bool(BUNDLE_RE.search(title)) and len(classes) >= 2
        purpose_text = title + " " + body
        if is_bundle:
            sig["role"] = "bundle"
            sig["bundle_components"] = classes
            sig["head"] = "furniture_set:" + "+".join(classes)
            if re.search(r"парт\w*|учебн\w*|домашн\w* задани|school\s+desk|study\s+desk", purpose_text, re.I):
                sig["furniture_purpose"] = "study"
            elif re.search(r"ігров\w*|игров\w*|песочниц\w*|пісочниц\w*|\blego\b|рисован\w*|малюван\w*|play\s+table", purpose_text, re.I):
                sig["furniture_purpose"] = "activity"
    elif typ == "kol":
        if head == "stroller_part":
            sig["role"] = "component"
        capacity_text = title + " " + body
        is_double = bool(MULTI_CHILD_STROLLER_RE.search(capacity_text))
        is_single = bool(SINGLE_CHILD_STROLLER_RE.search(capacity_text))
        # Capacity cues must refer to children/seats, not double suspension,
        # dual wheels, two brakes, or a product model name. Ambiguity fails closed.
        sig["child_capacity"] = ("double" if is_double else
                                  "single" if is_single else "single_unspecified")
        if TRAVEL_RE.search(title):
            sig["stroller_mode"] = "travel_system"
            m = re.search(r"([23])\s*(?:в|in)\s*1|([23])в1", title, re.I)
            if m: sig["travel_config"] = next(g for g in m.groups() if g)
        elif WALKING_RE.search(title):
            sig["stroller_mode"] = "walking"
    elif typ == "kreslo":
        m = re.search(r"(\d{1,2})\s*[-–]\s*(\d{1,2})\s*(?:кг|kg)", body, re.I)
        if m: sig["weight_range"] = (float(m.group(1)), float(m.group(2)))
        if not sig["weight_range"]:
            category_ids = {x.split(":", 1)[0] for x in str(row.get("cats", "")).split("|") if ":" in x}
            category_ranges = {"135":(0.0,13.0),"13":(0.0,13.0),"136":(0.0,18.0),"14":(0.0,18.0),"137":(9.0,18.0),"15":(9.0,18.0),"138":(9.0,36.0),"16":(9.0,36.0),"139":(15.0,36.0),"17":(15.0,36.0)}
            sig["weight_range"] = next((category_ranges[x] for x in sorted(category_ids) if x in category_ranges), None)
    elif typ == "transport":
        transport_text = title + " " + body
        if re.search(r"трехколесн\w*|триколесн\w*|триколісн\w*|\btricycle\b|\btrike\b|3\s*[хx-]\s*кол\w*", transport_text, re.I):
            sig["head"] = "tricycle"
        text_for_wheel = title + " " + body
        m = re.search(r"(?<!\d)(\d{1,2})\s*(?:дюйм(?:а|ов)?|д(?![a-zа-я])|[\"″]|inch(?:es)?)", text_for_wheel, re.I)
        if not m and head == "bicycle":
            m = re.search(r"/\s*(10|12|14|16|18|20)\b", title, re.I)
        if m and head == "bicycle":
            sig["wheel_size_inches"] = int(m.group(1))
    elif typ == "wear":
        sig["head"] = _head(title + " " + early, typ)
        for label, pattern in GENDER.items():
            if pattern.search(title): sig["gender"] = label; break
    return sig

def similar_compatibility(source, candidate):
    a = functional_signature(source)
    b = functional_signature(candidate)
    if source.get("type") != candidate.get("type"):
        return False, "bundle_type_mismatch", a, b
    if not a["head"] or not b["head"]:
        return False, "functional_type_unknown", a, b
    if a["head"] != b["head"]:
        return False, "functional_type_mismatch", a, b
    if a["role"] != b["role"]:
        return False, "kit_component_mismatch", a, b
    if source.get("type") in {"kol", "product_kit"}:
        if a["child_capacity"] != b["child_capacity"]:
            return False, "stroller_capacity_mismatch", a, b
        if a["stroller_mode"] and b["stroller_mode"] and a["stroller_mode"] != b["stroller_mode"]:
            return False, "stroller_use_mismatch", a, b
        if (a["travel_config"] or b["travel_config"]) and a["travel_config"] != b["travel_config"]:
            return False, "stroller_set_configuration_mismatch", a, b
    if a["bundle_components"] and b["bundle_components"] and a["bundle_components"] != b["bundle_components"]:
        return False, "bundle_component_mismatch", a, b
    if a.get("furniture_purpose") and b.get("furniture_purpose") and a["furniture_purpose"] != b["furniture_purpose"]:
        return False, "furniture_purpose_mismatch", a, b
    if a["weight_range"] and b["weight_range"]:
        if max(a["weight_range"][0], b["weight_range"][0]) > min(a["weight_range"][1], b["weight_range"][1]):
            return False, "weight_range_mismatch", a, b
    if a["head"] in {"bicycle", "tricycle"} and b["head"] == a["head"]:
        if bool(a.get("wheel_size_inches")) != bool(b.get("wheel_size_inches")):
            return False, "bicycle_wheel_size_unknown", a, b
        if a.get("wheel_size_inches") and b.get("wheel_size_inches") and abs(a["wheel_size_inches"] - b["wheel_size_inches"]) >= 2:
            return False, "bicycle_wheel_size_mismatch", a, b
    if a["gender"] and b["gender"] and a["gender"] != b["gender"]:
        return False, "clothing_gender_mismatch", a, b
    if a["head"] in {"rocking_center", "high_chair", "crib", "crib_mechanism", "bed_guard"} and a["head"] != b["head"]:
        return False, "functional_type_mismatch", a, b
    return True, "functional_signature_match", a, b

ACCESSORY_SOURCE_TYPES = {"kol", "kreslo", "mebel", "transport"}
ACCESSORY_CATEGORIES = {"20","134","140","815","590","593","1561","1562","1604","1605"}
ACCESSORY_HEADS = [
    ("rain_cover", r"дождевик\w*|дощовик\w*|rain\s*cover"),
    ("adapter", r"адаптер\w*|adapter\w*"),
    ("cup_holder", r"подстаканник\w*|підсклянник\w*|cup\s*holder"),
    ("mosquito_net", r"москитн\w*|москітн\w*|mosquito\s*net"),
    ("second_seat", r"прогулочн\w*\s+блок\w*\s+для\s+втор\w*\s+реб[её]нк\w*|seat\s+unit\s+for\s+second\s+child|second\s+seat\s+unit"),
    ("stroller_board", r"подножк\w*\s+для\s+втор\w*\s+реб[её]нк\w*|підніжк\w*\s+для\s+друг\w*\s+дит\w*|kidboard|wheeled\s+board"),
    ("safety_harness", r"harness|ремн\w*\s+(?:безопасности|безпеки)|паск\w* безпек"),
    ("mattress", r"матрасик\w*|матрацик\w*|матрас\w* для коляск|матрац\w* для коляск|\bmattress\b"),
    ("footmuff", r"конверт\w*|муфт\w*|footmuff"),
    ("seat_liner", r"вкладыш\w*|вкладиш\w*|liner\b|вкладка"),
    ("textile_cover", r"чехол\w*|чохол\w*|cover\b|textile|текстил\w*"),
    ("bag", r"сумк\w*|\bbag\b|органайзер\w*|organizer"),
    ("bumper", r"бампер\w*|\bbumper\b"),
    ("footrest", r"подножк\w*|підніжк\w*|footrest"),
    ("tray", r"поднос\w*|піднос\w*|\btray\b|столешниц\w*"),
    ("bassinet", r"люльк\w*|\bbassinet\b"),
    ("spare_part", r"запчаст\w*|запасн\w* част|replacement\s+part"),
]
MAIN_PRODUCT_HEAD = re.compile(r"коляск\w*|\bstroller\b|\bbuggy\b|автокресл\w*|автокрісл\w*|\bcar\s+seat\b|стульчик\w* для кормлен|стільчик\w* для годуван|кроват\w*|ліжк\w*|\bcrib\b|\bcot\b|велосипед\w*|\bbicycle\b|\bbike\b|самокат\w*|\bscooter\b|костюм\w*|реглан\w*|футболк\w*|мяч\w*|м['’]яч\w*|\btoy\b", re.I)
STRONG_COMPAT = re.compile(r"compatible\s+with|fits?\s+(?:the\s+)?|suitable\s+for|підходить\s+(?:до|для)|подходит\s+(?:к|ко|для)|сумісн\w*\s+(?:з|із|зі|для)|совместим\w*\s+(?:с|со|для)|сумісність|совместимость", re.I)
NEGATIVE = re.compile(r"not\s+(?:compatible|suitable|fit)|does\s+not\s+fit|не\s+(?:подходит|сумісн\w*|совместим\w*|підходить)|не\s+для|несовместим\w*|несумісн\w*", re.I)
GENERIC_ACCESSORY_RELATION = re.compile(r"(?:compatible|совместим\w*|сумісн\w*|подходит\s+(?:ко|к|для)|підходить\s+(?:до|для)).{0,40}(?:all|всеми?|усіма|усі|всі).{0,30}(?:accessor\w*|аксессуар\w*|аксесуар\w*)", re.I)
FITMENT_START = re.compile(r"compatible\s+(?:with|for)|fits?\s+(?:the\s+)?|suitable\s+for|підходить\s+(?:до|для)|подходит\s+(?:к|ко|для)|сумісн\w*\s+(?:з|із|зі|для)|совместим\w*\s+(?:с|со|для)|сумісність|совместимость", re.I)
TARGET_OBJECT = re.compile(r"\b(?:stroller|buggy|chair|high\s+chair|seat|car\s+seat|bassinet|cot|crib|коляск\w*|стул\w*|стілец\w*|стільц\w*|кресл\w*|автокресл\w*|автокрісл\w*|люльк\w*|кроват\w*|ліжк\w*)\b", re.I)

def explicit_model_fitment(evidence_sentence, matched_model_text):
    """Require the model name in the fitment claim itself, after the positive cue."""
    sentence = norm(evidence_sentence)
    model = norm(matched_model_text)
    if not model:
        return False
    for cue in FITMENT_START.finditer(sentence):
        tail = sentence[cue.end():cue.end() + 140]
        model_pos = tail.find(model)
        if model_pos < 0:
            continue
        if GENERIC_ACCESSORY_RELATION.search(sentence):
            relation = tail[:model_pos + len(model)]
            if not TARGET_OBJECT.search(relation):
                continue
        return True
    return False

DEPENDENCY_CONTEXT = re.compile(r"(?:only\s+(?:with|for|compatible|fits?)|только\s+(?:с|для|совместим)|лише\s+(?:з|для|сумісн)|requires?\b|must\s+be\s+used\s+with|needed\s+with|требуется|необходим\w*\s+(?:с|для)|нужен\s+(?:с|для)|потрібн\w*\s+(?:з|для)|потребує|вимагає).{0,100}(?:baby\s*set|car\s*seat|seat\b|base\b|adapter|адаптер\w*|баз\w*|сидін\w*|кресл\w*|option|version|верси\w*|опці\w*|комплект)", re.I|re.S)
VERSIONED_COMPONENT = re.compile(r"baby\s*set\s*(?:2|3|[²³])|babyset\s*(?:2|3)|baby\s*set.{0,80}(?:old|older|стар\w*|несовместим|несумісн|not\s+compatible)", re.I|re.S)

def accessory_class(title, body="", category_ids=None):
    """Identify a concrete accessory item, not a main product that mentions one."""
    title = norm(title)
    body = norm(body)
    hits = []
    for label, pattern in ACCESSORY_HEADS:
        m = re.search(pattern, title, re.I)
        if m: hits.append((m.start(), label, m.end()))
    if hits:
        pos, label, end = min(hits, key=lambda item: item[0])
        main = MAIN_PRODUCT_HEAD.search(title)
        if main and main.start() < pos:
            return None
        return label
    ids = set(category_ids or ())
    if ids & ACCESSORY_CATEGORIES:
        # Category alone is insufficient: require a concrete item noun in the full description.
        for label, pattern in ACCESSORY_HEADS:
            if re.search(pattern, body, re.I):
                return label
    return None

def unresolved_candidate_requirements(source_type, title, full_text, source_context, option_context="", kind=None):
    text = norm(title + " " + full_text)
    context = norm(source_context + " " + option_context)
    # Adapters have two physical endpoints. Unless the other endpoint is part of
    # the selected source bundle/options, a title match cannot prove a usable pair.
    if kind == "adapter":
        return "unresolved_option_or_component_dependency"
    cot_cover = re.search(r"(?:дождевик|дощовик|rain\s*cover|москитн\w*|москітн\w*|mosquito|сітка|сетка|чехол|чохол|textile|текстил).{0,80}(?:люльк\w*|bassinet|\bcot\b)|(?:для|на|for)\s+(?:люльк\w*|bassinet|\bcot\b)", norm(title), re.I)
    if cot_cover and not re.search(r"люльк\w*|bassinet|\bcot\b|(?:2|3)\s*(?:в|in)\s*1", context, re.I):
        return "unresolved_option_or_component_dependency"
    reversible = re.search(r"реверсивн\w*.{0,40}блок|reversib\w*.{0,40}block", norm(title), re.I)
    if reversible and not re.search(r"реверсивн\w*|reversib\w*", context, re.I):
        return "unresolved_option_or_component_dependency"
    second_child_footrest = kind == "footrest" and re.search(r"(?:подножк\w*|підніжк\w*|footrest).{0,60}(?:втор\w*|second|старш\w*)", norm(title), re.I)
    if second_child_footrest and not re.search(r"board|kidboard|wheeled\s+board|підніжк\w* для друг|подножк\w* для втор", context, re.I):
        return "unresolved_option_or_component_dependency"
    return ""

def unresolved_dependency(full_text, source_context, option_context=""):
    text = norm(full_text)
    context = norm(source_context + " " + option_context)
    if DEPENDENCY_CONTEXT.search(text):
        # A dependency phrase is unresolved unless the actual source title/body/options name it.
        match = DEPENDENCY_CONTEXT.search(text)
        tail = text[match.start():match.end()]
        dep = re.search(r"baby\s*set\s*(?:2|3|[²³])?|car\s*seat|seat\b|base\b|adapter|адаптер\w*|баз\w*|сидін\w*|кресл\w*|option|version|верси\w*|опці\w*|комплект", tail, re.I)
        if not dep or norm(dep.group(0)) not in context:
            return "unresolved_option_or_component_dependency"
    if VERSIONED_COMPONENT.search(text):
        versions = re.findall(r"baby\s*set\s*(?:2|3|[²³])?|babyset\s*(?:2|3)", text, re.I)
        if versions and not any(norm(v) in context for v in versions):
            return "unresolved_versioned_component"
    return ""

def accessory_candidate_status(source_type, title, body, category_ids, evidence_sentence,
                               full_candidate_text, source_context, option_context,
                               exact_model, brand_match, evidence_in_body=True,
                               matched_model_text=""):
    if source_type not in ACCESSORY_SOURCE_TYPES:
        return "ineligible_source_type", None, ""
    kind = accessory_class(title, body, category_ids)
    if not kind:
        return "candidate_not_clear_accessory", None, ""
    if not exact_model:
        return "exact_model_missing", kind, ""
    if not brand_match:
        return "brand_missing", kind, ""
    if not evidence_in_body:
        return "full_description_evidence_missing", kind, ""
    if NEGATIVE.search(evidence_sentence):
        return "negative_or_contradictory", kind, ""
    if not STRONG_COMPAT.search(evidence_sentence) or not explicit_model_fitment(evidence_sentence, matched_model_text):
        return "no_strong_compatibility_phrase", kind, ""
    dep = unresolved_candidate_requirements(source_type, title, full_candidate_text, source_context, option_context, kind)
    if not dep:
        dep = unresolved_dependency(full_candidate_text, source_context, option_context)
    if dep:
        return dep, kind, ""
    return "accepted_strong_text_only", kind, "same-sentence positive exact model; no local negation; no unresolved component/version/option requirement"

def generation_guard_tests():
    cases = [
        ("single stroller vs twin", {"type":"kol","title":"Emmaljunga прогулочная коляска Classic Sport"}, {"type":"kol","title":"Emmaljunga коляска для двойни DOUBLE CITY CROSS"}, False),
        ("roly-poly vs ball", {"type":"toy","title":"Playgro неваляшка Собачка"}, {"type":"toy","title":"Playgro веселый мячик"}, False),
        ("clothing set vs reglan", {"type":"wear","title":"Модный карапуз костюм велюровый для младенца"}, {"type":"wear","title":"Модный карапуз реглан для девочек"}, False),
        ("furniture set vs chair", {"type":"mebel","title":"Tega комплект стол + 2 стула Mamut"}, {"type":"mebel","title":"Верес стульчик Монако со спинкой"}, False),
        ("Aer+ vs Aer2 generations", {"type":"kol","title":"Joolz прогулочная коляска Aer+"}, {"type":"kol","title":"Joolz прогулочная коляска Aer2"}, True),
        ("kit vs component type", {"type":"product_kit","title":"Комплект коляска + автокресло"}, {"type":"kol","title":"Коляска прогулочная"}, False),
    ]
    out=[]
    for label,a,b,expected in cases:
        got,reason,sa,sb=similar_compatibility(a,b)
        out.append({"case":label,"expected_allowed":expected,"actual_allowed":got,"pass":got==expected,"reason":reason,"source_signature":sa,"candidate_signature":sb})
    return out
