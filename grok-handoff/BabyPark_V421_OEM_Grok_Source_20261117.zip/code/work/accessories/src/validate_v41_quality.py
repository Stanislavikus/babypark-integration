#!/usr/bin/env python3
"""V4.1 quality-specific independent checks beyond basic source/target structure."""
import copy
import gzip
import json
import sys
from collections import Counter
from pathlib import Path
ROOT=Path("/opt/bp-accessories-v41-targeted-rehearsal-20261112")
sys.path.insert(0,str(ROOT/"src"))
import accessory_v4 as v41
import accessory_auto_v39 as accessory
from ordered_model_v41 import match_exact_model

catalog=v41.read_rows(ROOT/"input/current_catalog_records.jsonl.gz")
manifest=json.loads((ROOT/"output/v4_candidate_manifest.json").read_text())["sources"]
ev=json.loads((ROOT/"output/v4_candidate_evidence.json").read_text())
index=json.loads((ROOT/"input/v36_worker_state.json").read_text())["index"]
checks=Counter()
universal_targets=Counter()
for sid,rec in manifest.items():
    source=catalog[int(sid)]
    entries=ev.get(sid,{"A_model":[],"B_universal":[],"targets":{}})
    a_ids=entries["A_model"]
    b_ids=entries["B_universal"]
    if b_ids:
        assert source["type"]=="kol"
        assert (source.get("function_signature") or {}).get("child_capacity")!="double"
        assert len(b_ids)<=3
    selected_a_roles=set()
    for target_id in a_ids:
        target=catalog[target_id]
        model=accessory.group_model(source,index)
        assert model
        status=accessory.reason_for(source,target,model)
        assert status.startswith("accepted_"),(sid,target_id,status)
        selected_a_roles.add(v41.v3_rules.accessory_class(
            target["title"],target["body"],v41.v39.pipe.categories(target)))
        checks["validated_A"]+=1
    for target_id in b_ids:
        target=catalog[target_id]
        scope=v41.broad_scope(target,"stroller")
        assert scope
        assert scope["role"] not in selected_a_roles
        assert not v41.HOOK_RE.search(target["title"])
        if scope["brand_tid"]:
            assert scope["brand_tid"]==source["brand_tid"]
        universal_targets[target_id]+=1
        checks["validated_B"]+=1
    checks["validated_source_rows"]+=1
assert checks["validated_source_rows"]==8471
assert len(universal_targets)>10

# Real negative regressions. Model-restricted accessories must not leak
# into universal rows, and positive model-description exceptions stay.
for bad in (138665,142852,139152,139153,142819):
    assert universal_targets[bad]==0,("universal false positive",bad)
checks["known_real_false_positive_targets_absent"]=5
for sid,target_id in ((127931,141846),(127932,141847)):
    assert target_id in ev[str(sid)]["A_model"]
    checks["explicit_public_description_pair"]=checks.get("explicit_public_description_pair",0)+1
assert not any(tid in ev[str(141723)]["B_universal"] for tid in (138665,142852))

# A new realistic 1C product appears without ANY manually linked NIDs.
source=catalog[120772] # Cybex Gazelle S (RU)
template=catalog[123678] # existing matching rain cover
new=copy.deepcopy(template)
new.update(nid=999997,tnid=999997,vid=999997,
           title="Cybex дождевик для коляски Gazelle S",
           price=990,published=1,field_status=1)
assert "field_accessories" not in new and "field_similar" not in new
pool=accessory.build_pool(catalog)
before,_=accessory.rank_source(source,index,pool)
candidate_rows=dict(catalog);candidate_rows[999997]=new
after,_=accessory.rank_source(source,index,accessory.build_pool(candidate_rows))
assert 999997 in after and 999997 not in before
checks["new_product_no_manual"]+=1
candidate_rows[999997]["field_status"]=0
gone,_=accessory.rank_source(source,index,accessory.build_pool(candidate_rows))
assert 999997 not in gone
checks["unavailable_new_product_removed"]+=1
wrong=copy.deepcopy(new)
wrong["field_status"]=1
wrong["title"]="Cybex дождевик для коляски Gazelle S TPE"
wrong["body"]="Совместим с коляской Gazelle S." # conflict => block!
assert accessory.reason_for(source,wrong,"Gazelle S")=="blocked_versioned_accessory_title"
checks["negative_version_specific_title_blocked"]+=1

out={"schema":"bp-v41-extra-quality-gate","passed":True,
     "checks":dict(checks),"B_unique_target_count":len(universal_targets),
     "highest_reused_B_nid_count":max(universal_targets.values()),
     "manufacturer_certification":False,
     "synced_to_production":False}
report=ROOT/"output/v41_quality_validation.json"
if report.exists():raise RuntimeError("Do not overwrite independent QA artifact")
report.write_text(json.dumps(out,ensure_ascii=False,indent=2)+"\n")
print(json.dumps(out,ensure_ascii=False,indent=2))
