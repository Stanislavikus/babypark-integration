#!/usr/bin/env python3
"""Reproducible V4.1/V4.2 comparison and source-slice runtime measurement."""
import collections, csv, json, re, sys, time
from pathlib import Path

ROOT=Path("/opt/bp-accessories-v421-integration-rehearsal-20261112/work/accessories")
sys.path.insert(0,str(ROOT/"src"))
import accessory_v4 as v42

def read_json(path):
    return json.loads(path.read_text())

def load_catalog():
    rows=v42.read_rows(ROOT/"input/current_catalog_records.jsonl.gz")
    supplemental=read_json(ROOT/"input/help_public_rows_v42.json")["rows"]
    for row in supplemental:
        rows[int(row["nid"])]=row
    return rows

def category_parts(row):
    out=[]
    raw=row.get("cats","") or ""
    for m in re.finditer(r"(?<!\d)(\d+)\s*:\s*([^;,|]+)",raw):
        out.append((int(m.group(1)),m.group(2).strip()))
    return out or [(0,"uncategorized")]

def source_groups(manifest,evidence,rows,policy):
    groups=collections.defaultdict(collections.Counter)
    brands=collections.defaultdict(collections.Counter)
    categories=collections.defaultdict(collections.Counter)
    target_use=collections.defaultdict(lambda:{"tiers":set(),"edges":0,"source_nids":set()})
    bad_edges=[]
    similar_ok=True
    base_similar=read_json(ROOT/"input/current_v36_similarity_only_manifest.json")["sources"]
    for sid,rec in manifest["sources"].items():
        source=rows.get(int(sid))
        if not source:
            bad_edges.append({"source_nid":int(sid),"error":"missing_source"})
            continue
        ev=evidence.get(sid,{})
        a=list(ev.get("A_model",[])); b=list(ev.get("B_universal",[]))
        ids=list(rec.get("accessories",[]))
        eligible=v42.eligible_source(source)
        head=v42.source_head(source,policy) or "excluded"
        typ=source.get("type","?")
        lang=source.get("lang","?")
        signature=(head,typ,lang)
        keys=[signature]
        brand=(source.get("brand_tid"),source.get("brand") or "unknown",typ,lang)
        brand_label=(f"{brand[1]} [tid={brand[0]}]",typ,lang)
        for key in keys:
            c=groups[key]; c["sources"]+=1
            if eligible:c["available_sources"]+=1
            if a:c["A_sources"]+=1
            if b:c["B_sources"]+=1
            if ids:c["any_sources"]+=1
            c["A_edges"]+=len(a);c["B_edges"]+=len(b)
            if eligible:
                if a:c["available_with_A"]+=1
                if b:c["available_with_B"]+=1
                if ids:c["available_with_any"]+=1
        bc=brands[brand_label];bc["sources"]+=1
        if eligible:bc["available_sources"]+=1
        if a:bc["A_sources"]+=1
        if b:bc["B_sources"]+=1
        if ids:bc["any_sources"]+=1
        bc["A_edges"]+=len(a);bc["B_edges"]+=len(b)
        if eligible and ids:bc["available_with_any"]+=1
        for tid,label in category_parts(source):
            ck=(head,tid,label,typ,lang)
            cc=categories[ck];cc["source_pages"]+=1
            if eligible:cc["available_sources"]+=1
            if a:cc["A_sources"]+=1
            if b:cc["B_sources"]+=1
            if ids:cc["any_sources"]+=1
            cc["A_edges"]+=len(a);cc["B_edges"]+=len(b)
            if eligible and ids:cc["available_with_any"]+=1
        if rec.get("similar")!=base_similar[sid].get("similar"):
            similar_ok=False
        if ids!=a+b or len(ids)!=len(set(ids)) or set(ids)&set(rec.get("similar",[])):
            bad_edges.append({"source_nid":int(sid),"error":"manifest/evidence/duplicate/similar invariant"})
        for tier,targets in (("A",a),("B",b)):
            for tid in targets:
                tid=int(tid);t=rows.get(tid)
                use=target_use[tid];use["tiers"].add(tier);use["edges"]+=1;use["source_nids"].add(int(sid))
                err=None
                if t is None:err="missing_target"
                elif t.get("lang")!=lang:err="language_mismatch"
                elif not v42.eligible_source(t):err="target_not_published_available_positive_price"
                elif t.get("type")=="product_kit":err="kit_target"
                elif (v42.target_head(t,policy) or "excluded")!=head:err="functional_head_mismatch"
                if err:bad_edges.append({"source_nid":int(sid),"target_nid":tid,"tier":tier,"error":err})
    totals=collections.Counter()
    for sid,rec in manifest["sources"].items():
        ev=evidence.get(sid,{})
        totals["A_edges"]+=len(ev.get("A_model",[]))
        totals["B_edges"]+=len(ev.get("B_universal",[]))
        if ev.get("A_model"):totals["A_sources"]+=1
        if ev.get("B_universal"):totals["B_sources"]+=1
        if rec.get("accessories"):totals["any_sources"]+=1
    totals["unique_A_targets"]=len({n for n,u in target_use.items() if "A" in u["tiers"]})
    totals["unique_B_targets"]=len({n for n,u in target_use.items() if "B" in u["tiers"]})
    totals["unique_targets"]=len(target_use)
    totals["similar_lists_identical"]=similar_ok
    totals["invalid_target_edges"]=len([x for x in bad_edges if "target_nid" in x])
    return {
        "totals":dict(totals),
        "by_source_head_type_locale":[{"head":k[0],"type":k[1],"lang":k[2],**dict(v)} for k,v in sorted(groups.items())],
        "by_brand_type_locale":[{"brand":k[0],"type":k[1],"lang":k[2],**dict(v)} for k,v in sorted(brands.items())],
        "by_source_category_locale":[{"head":k[0],"category_tid":k[1],"category":k[2],"type":k[3],"lang":k[4],**dict(v)} for k,v in sorted(categories.items())],
        "targets":target_use,"bad_edges":bad_edges
    }

def to_plain_targets(tuse,rows):
    result=[]
    for nid,use in sorted(tuse.items()):
        row=rows.get(int(nid),{})
        result.append({"nid":int(nid),"title":row.get("title"),"type":row.get("type"),
                       "lang":row.get("lang"),"brand":row.get("brand"),
                       "categories":row.get("cats"),"tiers":sorted(use["tiers"]),
                       "edge_count":use["edges"],"source_count":len(use["source_nids"])})
    return result

def main():
    rows=load_catalog()
    original=read_json(ROOT/"input/current_v36_similarity_only_manifest.json")
    policy=v42.taxonomy_policy(read_json(ROOT/"input/taxonomy_terms_v4.json"))
    v41_manifest=read_json(ROOT/"evidence/v41_baseline/v4_candidate_manifest.json")
    v41_evidence=read_json(ROOT/"evidence/v41_baseline/v4_candidate_evidence.json")
    v42_manifest=read_json(ROOT/"output/v4_candidate_manifest.json")
    v42_evidence=read_json(ROOT/"output/v4_candidate_evidence.json")
    base=source_groups(v41_manifest,v41_evidence,rows,policy)
    cand=source_groups(v42_manifest,v42_evidence,rows,policy)
    top={
      "schema":"bp-v42-v41-comparison-v1",
      "scope":{"core_localized_rows":28011,"supplemental_help_rows":2,"calculation_rows":len(rows),
               "v36_manifest_sources":len(original["sources"]),"similar_unchanged":cand["totals"]["similar_lists_identical"]},
      "baseline_v41":base["totals"],"candidate_v42":cand["totals"],
      "deltas":{k:cand["totals"].get(k,0)-base["totals"].get(k,0)
                for k in ("A_edges","B_edges","A_sources","B_sources","any_sources",
                          "unique_A_targets","unique_B_targets","unique_targets")},
      "by_source_head_type_locale":{"v41":base["by_source_head_type_locale"],
                                    "v42":cand["by_source_head_type_locale"]},
      "by_brand_type_locale":{"v41":base["by_brand_type_locale"],"v42":cand["by_brand_type_locale"]},
      "by_source_category_locale":{"v41":base["by_source_category_locale"],
                                   "v42":cand["by_source_category_locale"]},
      "quality":{"v41_invalid_target_edges":base["totals"]["invalid_target_edges"],
                 "v42_invalid_target_edges":cand["totals"]["invalid_target_edges"],
                 "v42_bad_invariants":cand["bad_edges"],
                 "precision_recall":"not estimable; no representative independent labeling set"}
    }
    (ROOT/"output/v42_comparison.json").write_text(json.dumps(top,ensure_ascii=False,indent=2)+"\n")
    for kind,keyname,fields in [
      ("brand","by_brand_type_locale",["brand","type","lang"]),
      ("category","by_source_category_locale",["head","category_tid","category","type","lang"])]:
        v41={tuple((str(x.get(k)) for k in fields)):x for x in base[keyname]}
        cand_rows={tuple((str(x.get(k)) for k in fields)):x for x in cand[keyname]}
        out=[]
        for k in sorted(set(v41)|set(cand_rows)):
            x=v41.get(k,{});y=cand_rows.get(k,{})
            r={field:value for field,value in zip(fields,k)}
            for metric in ("sources","source_pages","available_sources","A_sources","B_sources","any_sources",
                           "available_with_any","A_edges","B_edges"):
                left=x.get(metric,0);right=y.get(metric,0)
                if left or right:r[f"v41_{metric}"]=left;r[f"v42_{metric}"]=right;r[f"delta_{metric}"]=right-left
            out.append(r)
        path=ROOT/f"output/v42_{kind}_comparison.csv"
        cols=sorted({key for row in out for key in row})
        with path.open("w",newline="",encoding="utf-8") as f:
            w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(out)
    all_targets=to_plain_targets(cand["targets"],rows)
    with (ROOT/"output/v42_target_inventory.csv").open("w",newline="",encoding="utf-8") as f:
        cols=["nid","title","type","lang","brand","categories","tiers","edge_count","source_count"]
        w=csv.DictWriter(f,fieldnames=cols);w.writeheader()
        for x in all_targets:
            x["tiers"]=",".join(x["tiers"]);w.writerow(x)
    # Controls include real catalog product names/NIDs plus the documented synthetic gate checks.
    known_bad={138665,142852,139152,139153,142819}
    output_targets={int(x["nid"]):x for x in all_targets}
    negatives=[]
    for nid in sorted(known_bad):
        r=rows.get(nid,{})
        negatives.append({"nid":nid,"title":r.get("title"),"type":r.get("type"),
                         "lang":r.get("lang"),"emitted":nid in output_targets})
    manuf=[]
    for sid,ev in v42_evidence.items():
        source=rows.get(int(sid),{})
        for tid,why in ev.get("targets",{}).items():
            if why.get("reason")=="accepted_manufacturer_verified_fitment":
                target=rows.get(int(tid),{})
                manuf.append({"source_nid":int(sid),"source_title":source.get("title"),
                              "target_nid":int(tid),"target_title":target.get("title"),
                              "lang":source.get("lang"),"proof":why.get("evidence_key")})
    help_target_ids={int(r["nid"]) for r in read_json(ROOT/"input/help_public_rows_v42.json")["rows"]}
    help_examples=[]
    for tid in sorted(help_target_ids):
        target=rows.get(tid,{})
        source_pairs=[]
        for sid,ev in v42_evidence.items():
            if tid in ev.get("B_universal",[]):
                s=rows.get(int(sid),{})
                source_pairs.append({"source_nid":int(sid),"source_title":s.get("title"),
                                     "source_lang":s.get("lang")})
        help_examples.append({"target_nid":tid,"title":target.get("title"),"lang":target.get("lang"),
                              "type":target.get("type"),"edge_count":len(source_pairs),
                              "sample_sources":source_pairs[:5]})
    controls={"positive_manufacturer_pairs":manuf,"cross_type_help_targets":help_examples,
              "known_real_negative_universal_targets":negatives,
              "block_results":{"known_bad_targets_emitted":sum(x["emitted"] for x in negatives),
                 "known_bad_targets_checked":len(negatives),
                 "model_variant_and_OID_gates":"covered by 5 V42 tests; separate regression log",
                 "manual_reference_fields_read":False}}
    (ROOT/"output/v42_control_examples.json").write_text(json.dumps(controls,ensure_ascii=False,indent=2)+"\n")
    # Explain every eligible stroller/car-seat source left without suggestions.
    gap_counts=collections.Counter();gap_samples=[]
    for sid,record in original["sources"].items():
        source=rows.get(int(sid));head=v42.source_head(source,policy) if source else None
        if head not in ("stroller","car_seat") or not v42.eligible_source(source):continue
        if v42_manifest["sources"][sid].get("accessories"):continue
        signature=source.get("function_signature") or {}
        if head=="car_seat" and not v42.source_supports_isofix(source):
            reason="no_explicit_isofix_for_universal_protector"
        elif head=="stroller" and signature.get("child_capacity")=="double":
            reason="no_double_capacity_qualified_accessory"
        else:
            reason="no_qualifying_model_or_universal_accessory"
        key=(head,source.get("lang"),reason)
        gap_counts[key]+=1
        if len(gap_samples)<80:
            gap_samples.append({"nid":int(sid),"title":source.get("title"),"lang":source.get("lang"),
                                "head":head,"reason":reason})
    gaps={"schema":"bp-v42-eligible-source-coverage-gaps-v1",
          "counts":[{"head":k[0],"lang":k[1],"reason":k[2],"source_pages":v} for k,v in sorted(gap_counts.items())],
          "samples":gap_samples}
    (ROOT/"output/v42_coverage_gaps.json").write_text(json.dumps(gaps,ensure_ascii=False,indent=2))
    # An honest source-slice benchmark: selected sources only, but full candidate pools rebuilt.
    # This is not a live worker/queue/cache benchmark.
    subset={}
    for sid,record in original["sources"].items():
        source=rows.get(int(sid))
        if source and v42.source_head(source,policy)=="car_seat" and v42.eligible_source(source) and v42.source_supports_isofix(source):
            subset[sid]=record
    fitment=read_json(ROOT/"input/manufacturer_fitment_evidence_v42.json")["rules"]
    profiles=v42.validate_variant_profiles(read_json(ROOT/"input/variant_option_profiles_v42.json")["profiles"])
    t0=time.perf_counter()
    partial,partial_evidence,pm=v42.build_catalog(rows,subset,read_json(ROOT/"input/v36_worker_state.json")["index"],
                                                   policy,fitment,profiles)
    wall=time.perf_counter()-t0
    mismatch=[sid for sid in subset if partial[sid]["accessories"]!=v42_manifest["sources"][sid]["accessories"]]
    inc={"schema":"bp-v42-source-slice-benchmark-v1","selected_source_pages":len(subset),
         "selection":"currently published/available car-seat source pages explicitly exposing ISOFIX; one Coo Coo help-target update scope",
         "wall_seconds":round(wall,6),"algorithm_internal_seconds":pm["elapsed_seconds"],
         "outputs_match_full_calculation":not mismatch,"mismatch_source_nids":[int(s) for s in mismatch],
         "limitation":"candidate pools are rebuilt from the full catalog, so this is an isolated source-slice algorithm measurement, not a true incremental worker/transport/cache benchmark"}
    (ROOT/"output/v42_incremental_subset_benchmark.json").write_text(json.dumps(inc,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps({"v41":base["totals"],"v42":cand["totals"],"delta":top["deltas"],
                      "bad_candidate_edges":cand["totals"]["invalid_target_edges"],
                      "incremental_subset":inc,"manufacturer_pairs":len(manuf),"negative_targets_emitted":controls["block_results"]["known_bad_targets_emitted"]},
                     ensure_ascii=False,indent=2))

if __name__=="__main__":main()
