#!/usr/bin/env python3
"""V4.1 exact ordered-token model matcher, REHEARSAL-ONLY.

Builds upon the V3.9 single-family matcher. No fuzzy/string similarity.
A positive text mention is NOT OEM physical-fit confirmation.
"""
from __future__ import annotations
import re
from canonical_models import normal
from model_mentions import match_exact_model as simple_model_matcher

WORDS=re.compile(r"[a-zа-яёіїєґ0-9]+",re.I)
# Version markers must remain distinct from the base model.
VERSION_TAIL={
 "pro","plus","lux","style","tpe","premium","elite","s","m","l","z",
 "i","isize","isense","x","xl","special","gen","generation","2025","2026"
}
AMBIGUOUS_SLASH=re.compile(r"^\s*/\s*(?:pro|plus|lux|style|tpe)\s*\(\s*\d+",re.I)
# Full publisher model lists, not a fuzzy semantic guess.
NUMERIC_LIST=re.compile(
    r"(?<!\w)(?P<head>[a-zа-яёіїєґ]{3,}(?:[ -][a-zа-яёіїєґ]{3,})?)"
    r"\s+(?P<first>\d{1,3})\s*/\s*(?P<second>\d{1,3})"
    r"\s+(?P<suffix>pro|plus|lux|style|isize)\b",re.I)
LETTER_LIST=re.compile(
    r"(?<!\w)(?P<head>[a-zа-яёіїєґ]{3,})\s+(?P<first>[a-z])\s*/\s*(?P<second>[a-z])\b",re.I)

def normalize(s):
    s=normal(s).casefold()
    s=re.sub(r"(?<!\w)i[- ]?size\b","isize",s)
    s=re.sub(r"\bbaby[- ]?safe(?=\d|\b)","babysafe",s)
    s=re.sub(r"(?<=[a-z])(?=\d)|(?<=\d)(?=[a-z])"," ",s)
    # Hyphens between letters are boundaries, never blindly joined.
    s=re.sub(r"(?<=[a-z])-(?=[a-z])"," ",s)
    # Aer-2 / Day-5, but NOT promotional Aer-20% (source matcher handles).
    s=re.sub(r"(?<=[a-z])-(?=\d)"," ",s)
    return s

def tokens(s):
    return [m for m in WORDS.finditer(s)]

def _direct(text,model):
    source=[m.group(0) for m in tokens(normalize(model))]
    if len(source)<2:return "absent","not_multitoken"
    raw=normalize(text)
    found=tokens(raw)
    if not found:return "absent","no_tokens"
    rejected_variant=False
    for i in range(len(found)-len(source)+1):
        span=found[i:i+len(source)]
        if [m.group(0) for m in span]!=source:continue
        # In Aer2/Aer3 the slash introduces another full model, but in
        # Pebble 360/PRO(2) the ambiguous parenthetical invalidates the title.
        tail=raw[span[-1].end():]
        if AMBIGUOUS_SLASH.match(tail):
            rejected_variant=True
            continue
        # A special generation token adjacent to matched base means it is
        # a different product: Gazelle S TPE / Pebble 360 Pro / Mios Style.
        if len(found)>i+len(source):
            after=found[i+len(source)]
            gap=raw[span[-1].end():after.start()]
            next_word=after.group(0)
            if (not re.search(r"[/,;]|\b(?:and|or|и|та|або)\b",gap)
                and (next_word in VERSION_TAIL or next_word.isdigit())):
                rejected_variant=True
                continue
            # Gazelle S / TPE is a generation shorthand, not full
            # explicit evidence for the base S without supplier context.
            if re.search(r"/",gap) and next_word in VERSION_TAIL:
                rejected_variant=True
                continue
        return "candidate","ordered_token_full_model"
    if rejected_variant:
        return "version_review","different_or_ambiguous_generation"
    return "absent","no_exact_ordered_model"

def _expanded(text,model):
    raw=normalize(text)
    model_tokens=[m.group(0) for m in tokens(normalize(model))]
    if len(model_tokens)>=3 and model_tokens[-2].isdigit() and model_tokens[-1] in (
            "pro","plus","lux","style","isize"):
        head_tokens=model_tokens[:-2]
        head=r"[\s-]+".join(map(re.escape,head_tokens))
        version=re.escape(model_tokens[-2]);suffix=re.escape(model_tokens[-1])
        pattern=(r"(?<!\w)"+head+r"\s+\d{1,3}\s*/\s*"+
                 version+r"\s+"+suffix+r"(?!\w)")
        if re.search(pattern,raw,re.I):
            return "candidate","explicit_numeric_list_expanded"
    for match in LETTER_LIST.finditer(raw):
        expanded=match.group("head")+" "+match.group("second")
        if [x.group(0) for x in tokens(normalize(expanded))]==model_tokens:
            return "candidate","explicit_letter_list_expanded"
    return "absent","no_explicit_shared_head_expansion"

def match_exact_model(text,model):
    # Preserve the successful and well-tested Aer2/Day5/Aer+/2 branches.
    from model_mentions import source_identity
    identity=source_identity(model)
    if identity is not None:
        family,version=identity
        if not version:
            # A bare Aer may not inherit Aer S/Z or any two-letter
            # enumerated variant; the list contains Aer S and Aer Z.
            if re.search(r"(?<!\w)"+re.escape(family)+r"\s+[a-z]\s*/\s*[a-z]\b",
                         normalize(text),re.I):
                return "absent","letter_suffix_is_not_bare_model"
        return simple_model_matcher(text,model)
    if not model or len(model)>110:
        return "review_complex_model","invalid_model_identity"
    found,detail=_direct(text,model)
    if found in ("candidate","version_review"):return found,detail
    return _expanded(text,model)
