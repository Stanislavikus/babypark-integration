#!/usr/bin/env python3
import csv, gzip, hashlib, json, os, sys, time, zlib
from collections import Counter, defaultdict
from pathlib import Path

BASE = Path("/opt/bp-v421-v36-full-category-decision-20261115")
REBUILD = BASE / "car_seat_correction_20261117"
INPUT = REBUILD / "input"
OUT = REBUILD / "output"
CAP = BASE / "capture"
ENGINE = Path("/opt/bp-v421-v36-full-category-decision-20261115/car_seat_correction_20261117/engine_root/work/accessories")
SRC = ENGINE / "src"
sys.path.insert(0, str(SRC))
import accessory_v4 as v4
import v32_pipeline as v32
import v3_rules_v421 as rules

for d in (INPUT, OUT):
    d.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chmod(d, 0o700)

def log(event, **data):
    row = {"utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "event": event, **data}
    print(json.dumps(row, ensure_ascii=False, sort_keys=True), flush=True)

def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def write_json_new(path, value):
    if path.exists():
        raise FileExistsError(str(path))
    path.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n", encoding="utf-8")
    os.chmod(path, 0o600)

def write_gzip_new(path, raw):
    if path.exists():
        raise FileExistsError(str(path))
    with open(path, "wb") as f:
        with gzip.GzipFile(fileobj=f, mode="wb", mtime=0, compresslevel=6) as gz:
            gz.write(raw)
    os.chmod(path, 0o600)

def normalize_capture(raw, fields):
    r = dict(zip(fields, raw))
    cats = []
    for part in (r.get("catalog_tid_name_hex_pairs") or "").split(";"):
        if not part:
            continue
        tid, name_hex = part.split(":", 1)
        cats.append(str(int(tid)) + ":" + bytes.fromhex(name_hex).decode("utf-8"))
    r.update({
        "nid": int(r["nid"]), "tnid": int(r["tnid"]), "vid": int(r["vid"]),
        "lang": r["language"], "published": int(r["published"]),
        "field_status": int(r["field_status"]), "price": float(r["price"] or 0),
        "brand_tid": int(r["brand_tid"] or 0), "cats": "|".join(cats),
    })
    return r

def refs(values):
    out = []
    for pair in values or []:
        if not isinstance(pair, (list, tuple)) or len(pair) < 2:
            raise ValueError("malformed reference delta")
        out.append(int(pair[1]))
    return out

def gzip_json_read(path):
    return json.loads(gzip.open(path, "rt", encoding="utf-8").read())

def dump_json_gzip(path, value):
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    write_gzip_new(path, raw)
    return {"bytes": path.stat().st_size, "sha256": sha(path), "raw_bytes": len(raw),
            "raw_sha256": hashlib.sha256(raw).hexdigest()}

log("START", campaign=str(REBUILD))
capture_path = CAP / "full_category_capture.json.gz"
capture = gzip_json_read(capture_path)
capture_sha = sha(capture_path)
assert capture_sha == "30829f6bcc903b66dc26a6ace53fefbc41d3a50916dfdf8b29d42aaf5951a3e4"
assert len(capture["cohort_rows"]) == 8129
fields = capture["row_fields"]
ix = {name: i for i, name in enumerate(fields)}

taxonomy_terms = []
for item in capture["taxonomy_terms"]:
    if len(item) < 4:
        raise ValueError("taxonomy row shape")
    taxonomy_terms.append({"tid": int(item[0]), "parent": int(item[3]), "name": item[2]})
fresh_taxonomy = {"schema": "current-capture-taxonomy-v1", "terms": taxonomy_terms}
policy = v4.taxonomy_policy(fresh_taxonomy)
if not {109, 1588, 2, 111}.issubset(policy["by_id"]):
    raise ValueError("current category tree missing required root terms")
log("CAPTURE_LOADED", cohort_rows=len(capture["cohort_rows"]),
    peer_extra_rows=len(capture["peer_extra_rows"]), extra_target_rows=len(capture["extra_target_rows"]),
    taxonomy_terms=len(taxonomy_terms), capture_sha256=capture_sha)

body_doc = gzip_json_read(CAP / "body_delta_recovery_20261116" / "recovered_body_delta.json.gz")
assert body_doc["schema"] == "babypark-current-description-delta-recovery-v1"
assert len(body_doc["rows"]) == 405
body_by_nid = {int(r["nid"]): r for r in body_doc["rows"]}
assert len(body_by_nid) == 405

live_transfer_path = INPUT / "v36_live_transfer" / "live_v36_tree_sources.json.gz"
live_doc = gzip_json_read(live_transfer_path)
assert live_doc["schema"] == "babypark-live-v36-tree-source-rows-v1"
assert live_doc["generation"] == "v34-bf39d0b17c0f5dc6d0e1"
assert live_doc["requested_nids"] == 8129
live_sources = live_doc["sources"]
live_root_sha = live_doc["root_sha256"]
log("LIVE_V36_LOADED", generation=live_doc["generation"], sequence=live_doc["sequence"],
    source_rows=len(live_sources), missing_nids=len(live_doc["missing_nids"]),
    active_root_sha256=live_root_sha)

old_catalog_path = ENGINE / "input" / "current_catalog_records.jsonl.gz"
old_rows = v4.read_rows(old_catalog_path)
original_base = json.loads((ENGINE / "input" / "current_v36_similarity_only_manifest.json").read_text(encoding="utf-8"))["sources"]
profile_doc = json.loads((ENGINE / "input" / "variant_option_profiles_v42.json").read_text(encoding="utf-8"))
option_profiles = v4.validate_variant_profiles(profile_doc["profiles"])
fitment_doc = json.loads((ENGINE / "input" / "manufacturer_fitment_evidence_v42.json").read_text(encoding="utf-8"))
fitment_rules = fitment_doc["rules"]
log("BASELINE_INPUTS_LOADED", old_catalog_rows=len(old_rows), old_manifest_sources=len(original_base),
    profile_count=len(option_profiles), fitment_rules=len(fitment_rules),
    old_catalog_sha256=sha(old_catalog_path))

current_by_nid = {}
for raw in capture["cohort_rows"] + capture["peer_extra_rows"] + capture["extra_target_rows"]:
    cur = normalize_capture(raw, fields)
    nid = cur["nid"]
    prev = current_by_nid.get(nid)
    if prev is not None and prev != cur:
        raise ValueError("conflicting duplicate capture row NID " + str(nid))
    current_by_nid[nid] = cur

fresh_rows = dict(old_rows)
missing_deleted = {int(n) for n in capture["missing_target_nids"]}
deleted_present = missing_deleted & set(fresh_rows)
for nid in deleted_present:
    del fresh_rows[nid]

for nid, cur in current_by_nid.items():
    row = dict(fresh_rows.get(nid, {}))
    row.update({
        "nid": cur["nid"], "tnid": cur["tnid"], "vid": cur["vid"], "lang": cur["lang"],
        "type": cur["type"], "published": cur["published"], "changed": int(cur["changed"]),
        "title": cur["title"], "brand_tid": cur["brand_tid"], "brand": cur["brand"],
        "field_status": cur["field_status"], "price": cur["price"], "sku": cur["sku"],
        "cats": cur["cats"], "option_digest": cur["option_digest"],
        "oid_weight_price_rows": cur["oid_weight_price_rows"],
    })
    fresh_rows[nid] = row

body_missing = sorted(set(body_by_nid) - set(current_by_nid))
if body_missing:
    raise ValueError("body delta NIDs missing from current capture")
for nid, item in body_by_nid.items():
    cur = current_by_nid[nid]
    if int(item["vid"]) != cur["vid"] or int(item["changed"]) != int(cur["changed"]):
        raise ValueError("body delta VID/changed mismatch NID " + str(nid))
    fresh_rows[nid]["body"] = item["body"]
    fresh_rows[nid]["body_summary"] = item.get("body_summary", "")
    fresh_rows[nid]["body_format"] = item.get("body_format", "")

if set(fresh_rows) & missing_deleted:
    raise ValueError("known absent current targets survived in candidate catalog")

for row in fresh_rows.values():
    row["function_signature"] = rules.functional_signature(row)

groups = v32.locales_by_group(fresh_rows)
bad_groups = v32.invalid_translation_groups(groups)
excluded_groups = {int(x) for x in bad_groups}
excluded_groups.update(int(tid) for tid, items in groups.items() if len(items) != 2)
for row in fresh_rows.values():
    row["translation_ambiguous"] = int(row["tnid"]) in excluded_groups

relevant_current_targets = {nid for nid, row in fresh_rows.items() if v4.target_head(row, policy)}
captured_current_targets = {nid for nid, row in current_by_nid.items() if v4.target_head(row, policy)}
uncaptured_target_candidates = sorted(relevant_current_targets - captured_current_targets)
captured_target_missing_from_fresh = sorted(captured_current_targets - set(fresh_rows))
if captured_target_missing_from_fresh:
    raise ValueError("captured current target missing from fresh rows")
log("CURRENT_OVERLAY_COMPLETE", old_catalog_rows=len(old_rows), fresh_catalog_rows=len(fresh_rows),
    current_capture_nids=len(current_by_nid), changed_bodies=len(body_by_nid),
    deleted_t1_target_ids=len(missing_deleted), deleted_old_rows_removed=len(deleted_present),
    current_target_candidates=len(captured_current_targets),
    uncaptured_old_target_candidates=len(uncaptured_target_candidates),
    body_missing=len(body_missing))

cohort_ids = {int(raw[ix["nid"]]) for raw in capture["cohort_rows"]}
assert len(cohort_ids) == 8129
scope_original = {}
scope_rows = {}
active_rows = 0
fallback_rows = 0
locale_mismatch = []
for nid, row in current_by_nid.items():
    if nid not in cohort_ids:
        continue
    if str(nid) in live_sources:
        live = live_sources[str(nid)]
        if live["language"] != row["lang"]:
            locale_mismatch.append(nid)
            sim = refs(row["current_similar_delta_nid"])
        else:
            sim = [int(x) for x in live["similar"]]
            active_rows += 1
    else:
        sim = refs(row["current_similar_delta_nid"])
        fallback_rows += 1
    scope_original[str(nid)] = {"language": row["lang"], "similar": sim, "accessories": []}
    scope_rows[nid] = row
if locale_mismatch:
    raise ValueError("current language differs from live V3.6 source row")

index = v32.build_indexes(fresh_rows)
if index["catalog_nids"] != len(fresh_rows):
    raise ValueError("fresh index catalog dimension mismatch")
log("FRESH_INDEX_READY", catalog_nids=len(fresh_rows),
    source_models=len(index["source_models"]), invalid_translation_groups=len(index["invalid_translation_groups"]),
    similar_excluded_groups=len(index["similar_excluded_groups"]),
    similar_bucket_keys=index["metrics"]["similar_bucket_keys"], build_seconds=index["metrics"]["build_seconds"])

tax_policy_doc = fresh_taxonomy
sources, evidence, metrics = v4.build_catalog(
    fresh_rows, scope_original, index, policy, fitment_rules, option_profiles)
assert len(sources) == 8129
for nid in scope_original:
    assert nid in sources
    similar = scope_original[nid]["similar"]
    assert sources[nid]["similar"] == similar
    assert len(sources[nid]["accessories"]) == len(set(sources[nid]["accessories"]))

t2_counts = Counter()
source_state = Counter()
type_head = Counter()
for nid, row in scope_rows.items():
    head = v4.source_head(row, policy)
    eligible = v4.eligible_source(row)
    typ = row.get("type", "?")
    source_state[(head or "excluded", row["lang"], "eligible" if eligible else "ineligible")] += 1
    type_head[(head or "excluded", typ, row["lang"])] += 1
    selected = sources[str(nid)]["accessories"]
    if head:
        t2_counts[(head, row["lang"], "sources")] += 1
        if eligible:
            t2_counts[(head, row["lang"], "eligible_sources")] += 1
        if selected:
            t2_counts[(head, row["lang"], "sources_with_T2")] += 1
        t2_counts[(head, row["lang"], "T2_edges")] += len(selected)
        if not selected and eligible:
            t2_counts[(head, row["lang"], "eligible_sources_with_zero_T2")] += 1
        for target_nid in selected:
            ev = evidence.get(str(nid), {}).get("targets", {}).get(str(target_nid), {})
            t2_counts[(head, row["lang"], "A_edges" if ev.get("tier") == "A_model" else "B_edges")] += 1

current_similar_gen = "production-live-v34"
candidate_manifest = {"schema": "babypark-recommendations-v42-rehearsal-candidate-v1",
    "generation_id": "v421-t2-fresh-20261116-live-v34",
    "sources": sources}
candidate_evidence = {"schema": "babypark-v42-rehearsal-evidence-v1", "sources": evidence}
metrics.update({
    "schema": "babypark-v42-catalog-metrics-v1",
    "core_catalog_rows": len(fresh_rows), "calculation_catalog_rows": len(fresh_rows),
    "manifest_sources": len(scope_original), "manual_fields_read": False, "manual_fallback": False,
    "similar_lists_preserved": True, "similar_list_source": current_similar_gen,
    "live_v36_generation": live_doc["generation"], "live_v36_sequence": live_doc["sequence"],
    "live_v36_root_sha256": live_root_sha, "changed_description_rows": len(body_by_nid),
    "current_capture_rows": len(current_by_nid), "deleted_t1_target_ids_removed": len(deleted_present),
    "uncaptured_old_target_candidates": len(uncaptured_target_candidates),
    "taxonomy_snapshot": "current production category capture",
    "groups": "A_model_then_B_universal", "no_oem_certification": True,
    "help_rows_imported": 0, "cross_type_policy": "existing export taxonomy branch and functional role",
    "scope_counts": [{"head": k[0], "lang": k[1], "metric": k[2], "value": v}
                     for k, v in sorted(t2_counts.items())],
    "source_state_counts": [{"head": k[0], "lang": k[1], "eligibility": k[2], "count": v}
                            for k, v in sorted(source_state.items())],
    "type_head_counts": [{"head": k[0], "type": k[1], "lang": k[2], "count": v}
                         for k, v in sorted(type_head.items())],
    "v36_source_rows_current": active_rows,
    "v36_source_fallback_to_current_manual_similar": fallback_rows,
})
write_json_new(OUT / "t2_v421_manifest.json", candidate_manifest)
write_json_new(OUT / "t2_v421_evidence.json", candidate_evidence)
write_json_new(OUT / "t2_v421_metrics.json", metrics)

catalog_path = INPUT / "fresh_current_catalog_records.jsonl.gz"
if catalog_path.exists():
    raise FileExistsError(str(catalog_path))
raw_buf = bytearray()
for nid in sorted(fresh_rows):
    raw_buf.extend(json.dumps(fresh_rows[nid], ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8"))
    raw_buf.extend(b"\n")
write_gzip_new(catalog_path, bytes(raw_buf))
index_path = INPUT / "fresh_v32_index.json.gz"
write_gzip_new(index_path, json.dumps(index, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8"))
write_json_new(INPUT / "fresh_v36_scope_sources.json", scope_original)

input_meta = {
    "schema": "babypark-v421-fresh-t2-input-meta-v1",
    "captured_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "production_read_only": True,
    "production_writes_attempted": False,
    "capture_sha256": capture_sha,
    "body_delta_gzip_sha256": sha(CAP / "body_delta_recovery_20261116" / "recovered_body_delta.json.gz"),
    "live_v36_transfer_sha256": sha(live_transfer_path),
    "live_v36_generation": live_doc["generation"],
    "live_v36_root_sha256": live_root_sha,
    "baseline_catalog_sha256": sha(old_catalog_path),
    "baseline_manifest_sha256": sha(ENGINE / "input" / "current_v36_similarity_only_manifest.json"),
    "taxonomy_current_terms": len(taxonomy_terms),
    "cohort_rows": len(capture["cohort_rows"]),
    "current_rows_overlaid": len(current_by_nid),
    "body_rows_overlaid": len(body_by_nid),
    "fresh_catalog_rows": len(fresh_rows),
    "deleted_t1_ids_removed": len(deleted_present),
    "uncaptured_old_target_candidates": len(uncaptured_target_candidates),
    "live_v36_source_rows": active_rows,
    "non_live_v36_source_rows_using_current_manual_similar": fallback_rows,
    "engine_source_path": str(SRC / "accessory_v4.py"),
    "engine_sha256": sha(SRC / "accessory_v4.py"),
    "v32_pipeline_sha256": sha(SRC / "v32_pipeline.py"),
    "v421_rules_sha256": sha(SRC / "v3_rules_v421.py"),
    "taxonomy_policy": "fresh capture terms converted to the existing V4.2.1 policy structure",
}
write_json_new(REBUILD / "fresh_t2_run_metadata.json", input_meta)
log("V421_T2_COMPLETE", sources=len(sources), fresh_catalog_rows=len(fresh_rows),
    t2_edges=metrics["edges"], scope_counts=metrics["scope_counts"],
    output_manifest_sha256=sha(OUT / "t2_v421_manifest.json"),
    evidence_sha256=sha(OUT / "t2_v421_evidence.json"),
    metrics_sha256=sha(OUT / "t2_v421_metrics.json"),
    catalog_sha256=sha(catalog_path), index_sha256=sha(index_path),
    uncaptured_old_target_candidates=len(uncaptured_target_candidates))
