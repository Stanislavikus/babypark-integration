#!/usr/bin/env python3
import csv, gzip, json, re, sys, hashlib
from collections import Counter, defaultdict
from pathlib import Path

BASE=Path("/opt/bp-v421-v36-full-category-decision-20261115")
CAM=BASE/"car_seat_correction_20261117"
OUT=CAM/"output"
ENG=CAM/"engine_root"/"work"/"accessories"
sys.path.insert(0,str(ENG/"src"))
import accessory_v4 as v4
import accessory_auto_v39 as v39

DETAIL=BASE/"FINAL_T0_T1_T2_DETAILS.csv"
ORIG=BASE/"t2_rebuild_20261116_livev34_corrected"/"output"
FIX1=BASE/"car_seat_fix_20261116"/"output"
CORR=CAM/"output"
FRESH=CAM/"input"/"fresh_current_catalog_records.jsonl.gz"
STAGE1=BASE/"car_seat_fix_20261116"/"stage1_new_targets_validation.json"

def read_json(p): return json.loads(Path(p).read_text(encoding="utf-8"))
def read_manifest(folder):
    return read_json(folder/"t2_v421_manifest.json")["sources"]
def read_evidence(folder):
    return read_json(folder/"t2_v421_evidence.json")["sources"]
def read_rows(path):
    rows={}
    with gzip.open(path,"rt",encoding="utf-8") as f:
        for line in f:
            r=json.loads(line); rows[int(r["nid"])]=r
    return rows
def norm(v): return re.sub(r"\s+"," ",str(v or "")).strip()
def yn(x): return "yes" if x else "no"
def available(row):
    return (row is not None and int(row.get("published") or 0)==1
        and int(row.get("field_status") or 0)==1 and float(row.get("price") or 0)>0)
def csv_write(name,fields,rows):
    p=CAM/name
    with p.open("w",encoding="utf-8-sig",newline="") as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction="ignore")
        w.writeheader()
        for r in rows:w.writerow(r)
    return p

rows=read_rows(FRESH)
taxonomy=read_json(ENG/"input"/"taxonomy_terms_v4.json")
policy=v4.taxonomy_policy(taxonomy)
index=json.loads(gzip.open(CAM/"input"/"fresh_v32_index.json.gz","rt",encoding="utf-8").read())
fitment_rules=read_json(ENG/"input"/"manufacturer_fitment_evidence_v42.json")["rules"]
profiles=v4.validate_variant_profiles(read_json(ENG/"input"/"variant_option_profiles_v42.json")["profiles"])
stage_doc=read_json(STAGE1)
stage_by_nid={int(x["nid"]):x for x in stage_doc.get("targets",[])}

details=[]
with DETAIL.open(newline="",encoding="utf-8-sig") as f:
    details=list(csv.DictReader(f))
source_meta={}
details_by_source=defaultdict(list)
pairs={}
manual_pair_rows={}
for r in details:
    sid=int(r["source_nid"])
    source_meta.setdefault(sid,r)
    details_by_source[sid].append(r)
    if (r["row_kind"]=="relationship" and r["category"]=="Автокресла"
        and r["source_v421_engine_eligible"]=="1"
        and r["T1_manual_field_currently_displayable"]=="1"
        and r["target_nid"]):
        tid=int(r["target_nid"])
        pairs[(sid,tid)]=r
assert len(source_meta)==8129,len(source_meta)
assert len(pairs)==1978,len(pairs)

orig_manifest=read_manifest(ORIG); fix1_manifest=read_manifest(FIX1); corr_manifest=read_manifest(CORR)
orig_evidence=read_evidence(ORIG); fix1_evidence=read_evidence(FIX1); corr_evidence=read_evidence(CORR)
assert len(orig_manifest)==len(fix1_manifest)==len(corr_manifest)==8129

def links_for(sid,manifest,evidence):
    ev=evidence.get(str(sid),{})
    a=[int(x) for x in ev.get("A_model",[])]
    b=[int(x) for x in ev.get("B_universal",[])]
    linked=set(int(x) for x in manifest[str(sid)]["accessories"])
    return {"all":sorted(linked),"A":a,"B":b}

seat_ids={sid for sid,m in source_meta.items() if m["category"]=="Автокресла"}
stroller_ids={sid for sid,m in source_meta.items() if m["category"]=="Коляски"}
old_eligible_seat={sid for sid in seat_ids if source_meta[sid]["source_v421_engine_eligible"]=="1"}
primary_classes={"primary_car_seat","booster_restraint","primary_seat_set"}
source_class={}
for sid,m in source_meta.items():
    r=rows.get(sid)
    if m["category"]=="Автокресла" and r:
        source_class[sid]=v4.car_seat_source_class(r)
    elif m["category"]=="Коляски":
        source_class[sid]="stroller_source"
    else:
        source_class[sid]="other_source"
primary_seat_ids={sid for sid in old_eligible_seat if source_class[sid] in primary_classes}
assert len(old_eligible_seat)==334,len(old_eligible_seat)
assert len(primary_seat_ids)==324,len(primary_seat_ids)
assert Counter(source_class[s] for s in old_eligible_seat)==Counter({
    "primary_car_seat":318,"isofix_base":8,"booster_restraint":4,
    "primary_seat_set":2,"accessory":2
})

def targets(evidence,sid,tier):
    return sorted(int(x) for x in evidence.get(str(sid),{}).get(tier,[]))
def target_summary(sid,manifest,evidence,tier):
    return "|".join(map(str,targets(evidence,sid,tier)))
def manual_counts(sid):
    rel=[r for r in details_by_source.get(sid,[]) if r["row_kind"]=="relationship"]
    # Relationship rows are unique pairs; do not add row-level reference counts.
    t0=len({r["target_nid"] for r in rel if int(r["T0_manual_ref_count"] or 0)>0 and r["target_nid"]})
    t1=len({r["target_nid"] for r in rel if int(r["T1_saved_manual_ref_count"] or 0)>0 and r["target_nid"]})
    display=len({r["target_nid"] for r in rel if r["T1_manual_field_currently_displayable"]=="1" and r["target_nid"]})
    purch=len({r["target_nid"] for r in rel if r["T1_manual_field_currently_displayable"]=="1"
               and r["target_nid"] and r["target_status"]=="1"
               and r["target_field_status"]=="1" and float(r["target_sell_price"] or 0)>0
               and r["target_node_access"]=="1"})
    return t0,t1,display,purch

# Score the T1 candidates independently; manual edges are never fed to the engine.
source_models={}
for sid in old_eligible_seat:
    if sid in rows:source_models[sid]=v39.group_model(rows[sid],index)
review_rows=[]; reject_rows=[]
review_counts=Counter()
for (sid,tid),d in sorted(pairs.items()):
    source=rows.get(sid); target=rows.get(tid)
    src_cls=source_class.get(sid,"unknown")
    target_available=available(target)
    gate=(target_available and int(d["target_node_access"] or 0)==1)
    model=source_models.get(sid)
    role=v4.target_role(target,"car_seat") if target else ""
    why=v39.reason_for(source,target,model) if source and target else "target_not_captured"
    ev_text=""
    if target:
        title=norm(target.get("title"))
        body=norm(re.sub(r"<[^>]*>"," ",str(target.get("body") or "")))
        if why=="accepted_model_title":
            ev_text="Exact source model appears in target title: "+title[:380]
        elif why=="accepted_model_positive_body":
            for sentence in v39.SEPARATOR.split(body):
                if v39.POSITIVE.search(sentence) and v39.match_exact_model(sentence,model or "")[0]=="candidate":
                    ev_text=sentence[:500];break
            if not ev_text:ev_text="Positive exact-model match in target description; excerpt unavailable after normalization."
        elif why=="blocked_mechanical_fitment":
            ev_text="Mechanical title: "+title[:260]+"; no matching manufacturer fitment rule for this source-target pair."
        else:
            ev_text=title[:380]
    if not target:
        compatibility="uncertain_missing_target"
        detail="Target absent from the captured catalog; compatibility and purchase gate cannot be checked."
    elif not gate:
        compatibility="not_commercially_available"
        bad=[]
        if int(target.get("published") or 0)!=1:bad.append("unpublished")
        if int(target.get("field_status") or 0)!=1:bad.append("field_status_not_1")
        if float(target.get("price") or 0)<=0:bad.append("no_positive_sell_price")
        if int(d["target_node_access"] or 0)!=1:bad.append("native_node_access_not_confirmed")
        detail="Purchase/catalog gate failed: "+",".join(bad or ["captured access gate failed"])+". Compatibility not inferred from display."
    elif src_cls not in primary_classes:
        compatibility="wrong_source_role"
        detail="Source is classified as "+src_cls+"; it is not a primary child restraint for the A/B source block."
    elif not model:
        compatibility="uncertain_source_model"
        detail="No confirmed bilingual source-model identity in the catalog index; this is missing evidence, not incompatibility."
    elif why.startswith("accepted_") and role=="seat_liner" and not v4.seat_liner_age_group_compatible(source,target):
        compatibility="not_proven_age_weight_fit"
        detail="The insert has no confirmed age/weight match for this seat; source range="+str((source.get("function_signature") or {}).get("weight_range"))+"."
    elif why.startswith("accepted_"):
        compatibility="compatibility_confirmed"
        detail="Existing exact-model rule passed ("+why+"); insert age/weight gate also passed where applicable."
    elif why=="blocked_identity":
        compatibility="wrong_identity"
        parts=[]
        if source and target and int(source.get("tnid") or 0)==int(target.get("tnid") or -1):parts.append("same physical translation group")
        if source and target and source.get("lang")!=target.get("lang"):parts.append("language mismatch")
        if source and target and source.get("brand_tid")!=target.get("brand_tid"):parts.append("brand mismatch")
        if source and target and source.get("type")!=target.get("type"):parts.append("Drupal type mismatch")
        detail="Identity guard failed: "+(", ".join(parts) or "source and target identity constraints differ")+"."
    elif why=="blocked_mechanical_fitment":
        compatibility="uncertain_mechanical_fitment"
        detail="Mechanical component requires an exact manufacturer fitment rule and matching physical interfaces/OID gates; no rule matches this pair."
    elif why=="blocked_versioned_accessory_title":
        compatibility="version_mismatch"
        detail="The accessory title names a different or versioned model; the source model match is not accepted."
    elif why=="absent_explicit_model":
        compatibility="not_proven_model_fitment"
        detail="The source model '"+str(model)+"' is not positively enumerated in the accessory title or a positive description sentence."
    elif why=="blocked_role_or_model":
        compatibility="wrong_role_or_category"
        if not model:
            detail="Source-model group is unresolved, so exact matching cannot run."
        elif not v39.explicit_accessory(target):
            detail="Target fails the engine accessory gate (taxonomy role/recognized accessory class or commercial/translation gate); title evidence alone cannot make it a recommendation."
        else:
            detail="Target role or product type is not valid for this automatic car-seat accessory relation."
    else:
        compatibility="uncertain"
        detail="Rule returned "+why+"; no positive compatibility claim is asserted."
    selected=tid in links_for(sid,corr_manifest,corr_evidence)["all"]
    recommended=(compatibility=="compatibility_confirmed" and gate and src_cls in primary_classes)
    review_counts[compatibility]+=1
    review_rows.append({
        "source_nid":sid,"source_tnid":source.get("tnid","") if source else "",
        "source_sku":source.get("sku","") if source else d["source_sku"],
        "source_language":source.get("lang","") if source else d["language"].lower(),
        "source_class":src_cls,"source_title":source.get("title","") if source else d["source_title"],
        "source_model":model or "","target_nid":tid,"target_tnid":target.get("tnid","") if target else "",
        "target_sku":target.get("sku","") if target else "",
        "target_language":target.get("lang","") if target else d["target_language"].lower(),
        "target_title":target.get("title","") if target else d.get("target_title",""),
        "target_type":target.get("type","") if target else d["target_type"],
        "target_role":role,"currently_displayed":"yes",
        "source_weight_range":json.dumps((source.get("function_signature") or {}).get("weight_range")) if source else "",
        "seat_liner_age_weight_gate":("pass" if role=="seat_liner" and v4.seat_liner_age_group_compatible(source,target) else ("fail" if role=="seat_liner" else "not_applicable")),
        "target_published":target.get("published","") if target else d["target_status"],
        "target_field_status":target.get("field_status","") if target else d["target_field_status"],
        "target_sell_price":target.get("price","") if target else d["target_sell_price"],
        "target_node_access":d["target_node_access"],
        "catalog_purchase_gate":yn(gate),"stock_quantity":"not captured; do not infer inventory",
        "engine_reason":why,"compatibility_decision":compatibility,
        "automatic_corrected_output":yn(selected),"manual_fallback_used":"no",
        "should_offer_if_gate_passes":yn(recommended),"evidence_or_exact_gap":detail,
        "target_evidence_excerpt":ev_text
    })
    if not recommended:
        reject_rows.append({
            "source_nid":sid,"source_sku":source.get("sku","") if source else d["source_sku"],
            "source_class":src_cls,"target_nid":tid,"target_sku":target.get("sku","") if target else "",
            "target_title":target.get("title","") if target else d.get("target_title",""),
            "target_role":role,"compatibility_decision":compatibility,
            "engine_reason":why,"catalog_purchase_gate":yn(gate),
            "rejection_or_uncertainty_reason":detail,"evidence_excerpt":ev_text
        })

review_fields=list(review_rows[0].keys())
csv_write("MANUAL_CANDIDATE_REVIEW.csv",review_fields,review_rows)
csv_write("REJECTION_REASONS.csv",list(reject_rows[0].keys()),reject_rows)

# C candidates are vehicle-general product claims, not child-seat fitment.
any_vehicle=re.compile(r"(?i)(?:\b(?:in|for)\s+any\s+(?:car|vehicle)\b|\bany\s+(?:car|vehicle)\b|\bв\s+любой\s+(?:машин\w*|автомобил\w*)|\b(?:в|у)\s+будь[- ]якій\s+(?:машин\w*|автомобіл\w*)|\b(?:fits?|compatible\s+with)\s+any\s+(?:car|vehicle)\b)")
headrest=re.compile(r"(?i)(?:подголовник\w*|підголівник\w*|head[ -]?rest)")
bagtitle=re.compile(r"(?i)(?:сумк\w*|органайзер\w*|\bbag\b|organizer)")
c_rows=[]
for tid,t in sorted(rows.items()):
    title=norm(t.get("title"))
    if not bagtitle.search(title):continue
    body=norm(re.sub(r"<[^>]*>"," ",str(t.get("body") or "")))
    alltext=title+" . "+body
    ev=""
    for sentence in re.split(r"(?<=[.!?;])\s+|[\r\n]+",alltext):
        if any_vehicle.search(sentence) and headrest.search(sentence):
            ev=sentence[:600];break
    if not ev:continue
    stage=stage_by_nid.get(tid,{})
    c_rows.append({
        "nid":tid,"tnid":t.get("tnid",""),"sku":t.get("sku",""),"language":t.get("lang",""),
        "title":title,"brand":t.get("brand",""),"drupal_type":t.get("type",""),
        "categories":t.get("cats",""),"published":t.get("published",""),
        "field_status":t.get("field_status",""),"sell_price":t.get("price",""),
        "catalog_purchase_gate":yn(available(t)),
        "native_stage1_checked":yn(bool(stage)),
        "native_stage1_pass":yn(bool(stage.get("native_stage1_probe",{}).get("stage1_pass"))),
        "compatibility_class":"C_vehicle_general",
        "A_B_compatibility":"not established; general headrest/vehicle use only",
        "evidence_excerpt":ev,
        "automatic_A_B_selected":"no"
    })
csv_write("C_VEHICLE_GENERAL.csv",list(c_rows[0].keys()) if c_rows else
          ["nid","tnid","sku","language","title","compatibility_class","evidence_excerpt"],c_rows)

# Per-source triage for all 8,129 cards.
source_class_rows=[]
for sid,m in sorted(source_meta.items()):
    r=rows.get(sid,{})
    cls=source_class[sid]
    old_eligible=m["source_v421_engine_eligible"]=="1"
    is_primary=(m["category"]=="Автокресла" and sid in primary_seat_ids)
    t0,t1,display,purch=manual_counts(sid)
    corr=links_for(sid,corr_manifest,corr_evidence)
    c_lang=[x["nid"] for x in c_rows if x["language"]==r.get("lang")]
    if m["category"]=="Автокресла":
        if is_primary:
            exclusion=""
        elif cls=="isofix_base":exclusion="standalone Isofix base; installation component, not child restraint"
        elif cls=="accessory":exclusion="standalone liner/accessory; not child restraint"
        elif cls=="adapter":exclusion="adapter component, not child restraint"
        elif cls=="other_component":exclusion="component, not child restraint"
        else:exclusion="not classified as a primary child restraint from the product title"
    else:exclusion=""
    source_class_rows.append({
        "source_nid":sid,"tnid":r.get("tnid",""),"sku":r.get("sku",""),
        "language":r.get("lang",""),"category_domain":m["category"],
        "drupal_type":r.get("type",""),"brand":r.get("brand",""),
        "model_or_title":r.get("title",m.get("source_title","")),
        "source_product_class":cls,"function_signature":json.dumps(r.get("function_signature",{}),ensure_ascii=False,sort_keys=True),
        "published":r.get("published",""),"field_status":r.get("field_status",""),
        "sell_price":r.get("price",""),"old_engine_eligible":yn(old_eligible),
        "primary_seat_metric_eligible":yn(is_primary),
        "primary_exclusion_reason":exclusion,
        "T0_saved_manual_target_count":t0,"T1_saved_manual_target_count":t1,
        "T1_currently_displayed_target_count":display,
        "T1_currently_displayed_target_purchase_gate_pass_count":purch,
        "T2_original_A_targets":target_summary(sid,orig_manifest,orig_evidence,"A_model"),
        "T2_original_B_targets":target_summary(sid,orig_manifest,orig_evidence,"B_universal"),
        "T2_fix1_A_targets":target_summary(sid,fix1_manifest,fix1_evidence,"A_model"),
        "T2_fix1_B_targets":target_summary(sid,fix1_manifest,fix1_evidence,"B_universal"),
        "T2_corrected_A_targets":target_summary(sid,corr_manifest,corr_evidence,"A_model"),
        "T2_corrected_B_functional_targets":target_summary(sid,corr_manifest,corr_evidence,"B_universal"),
        "C_vehicle_general_candidates_same_language":"|".join(map(str,sorted(c_lang))),
        "confirmed_A_B_pairs":"|".join(map(str,corr["all"])),
        "final_A_B_result":"has_A_or_B" if corr["all"] else "no_proven_A_or_B",
        "final_reason_if_no_A_B":exclusion if not is_primary else ("no confirmed compatible commercially eligible A/B target selected" if not corr["all"] else "")
    })
csv_write("SOURCE_CLASSIFICATION.csv",list(source_class_rows[0].keys()),source_class_rows)

# Full cohort, one row per source, with all three immutable/recalculated snapshots.
three_rows=[]
for sid,m in sorted(source_meta.items()):
    r=rows.get(sid,{})
    o=links_for(sid,orig_manifest,orig_evidence); f=links_for(sid,fix1_manifest,fix1_evidence); c=links_for(sid,corr_manifest,corr_evidence)
    three_rows.append({
        "source_nid":sid,"source_tnid":r.get("tnid",""),"source_sku":r.get("sku",""),
        "language":r.get("lang",""),"category":m["category"],"source_product_class":source_class[sid],
        "old_engine_eligible":yn(m["source_v421_engine_eligible"]=="1"),
        "corrected_primary_seat_eligible":yn(sid in primary_seat_ids),
        "T2_original_targets":"|".join(map(str,o["all"])),"T2_original_A_targets":"|".join(map(str,o["A"])),"T2_original_B_targets":"|".join(map(str,o["B"])),
        "T2_fix1_targets":"|".join(map(str,f["all"])),"T2_fix1_A_targets":"|".join(map(str,f["A"])),"T2_fix1_B_targets":"|".join(map(str,f["B"])),
        "T2_corrected_targets":"|".join(map(str,c["all"])),"T2_corrected_A_targets":"|".join(map(str,c["A"])),"T2_corrected_B_functional_targets":"|".join(map(str,c["B"])),
        "original_link_count":len(o["all"]),"fix1_link_count":len(f["all"]),"corrected_link_count":len(c["all"]),
        "V36_similar_unchanged":yn(orig_manifest[str(sid)]["similar"]==fix1_manifest[str(sid)]["similar"]==corr_manifest[str(sid)]["similar"])
    })
csv_write("T2_THREE_WAY_COMPARISON.csv",list(three_rows[0].keys()),three_rows)

# A/B net-new compared with the original snapshot; include exact evidence and all delivery gates.
orig_pairs={(int(s),int(t)) for s,m in orig_manifest.items() for t in m["accessories"]}
fix_pairs={(int(s),int(t)) for s,m in fix1_manifest.items() for t in m["accessories"]}
corr_pairs={(int(s),int(t)) for s,m in corr_manifest.items() for t in m["accessories"]}
net_new=sorted(corr_pairs-orig_pairs)
new_recommendations=[]
for sid,tid in net_new:
    source=rows[sid]; target=rows[tid]; ev=corr_evidence.get(str(sid),{}).get("targets",{}).get(str(tid),{})
    stage=stage_by_nid.get(tid,{})
    if ev.get("tier")=="A_model":
        model=v39.group_model(source,index)
        why=v39.reason_for(source,target,model)
        proof=("Exact source model appears in target title: "+norm(target.get("title"))) if why=="accepted_model_title" else \
              ("Positive exact-model description evidence: "+norm(target.get("body"))[:500])
    else:
        why=""; proof=ev.get("evidence","")
    digest_match=bool(stage and str(stage.get("option_digest") or "")==str(target.get("option_digest") or ""))
    vid_match=bool(stage and int(stage.get("vid") or 0)==int(target.get("vid") or 0))
    lang_match=bool(source.get("lang")==target.get("lang"))
    new_recommendations.append({
        "source_nid":sid,"source_tnid":source.get("tnid",""),"source_sku":source.get("sku",""),
        "source_language":source.get("lang",""),"source_title":source.get("title",""),
        "target_nid":tid,"target_tnid":target.get("tnid",""),"target_sku":target.get("sku",""),
        "target_language":target.get("lang",""),"target_title":target.get("title",""),
        "tier":ev.get("tier",""),"role":v4.target_role(target,"car_seat"),
        "compatibility_engine_reason":why or ev.get("reason",""),
        "compatibility_evidence":proof,
        "source_model":v39.group_model(source,index) or "",
        "same_language":yn(lang_match),"catalog_purchase_gate":yn(available(target)),
        "target_published":target.get("published",""),"target_field_status":target.get("field_status",""),
        "target_sell_price":target.get("price",""),"stock_quantity":"not captured; do not infer inventory",
        "current_target_vid":target.get("vid",""),"current_option_digest":target.get("option_digest",""),"target_oid_weight_price_rows":target.get("oid_weight_price_rows",""),"stage1_oid_rows_match_current":yn(bool(stage and str(stage.get("oid_weight_price_rows") or "")==str(target.get("oid_weight_price_rows") or ""))),"stage1_native_access":json.dumps(stage.get("native_access",{}),ensure_ascii=False,sort_keys=True),"stage1_native_states":json.dumps(stage.get("native_stage1_probe",{}).get("native_states",[]),ensure_ascii=False,sort_keys=True),
        "stage1_target_row_found":yn(bool(stage)),
        "stage1_pass":yn(bool(stage.get("native_stage1_probe",{}).get("stage1_pass"))),
        "stage1_all_gates_pass":yn(bool(stage.get("all_gates_pass"))),
        "stage1_vid_matches_current":yn(vid_match),"stage1_option_digest_matches_current":yn(digest_match),
        "stage1_current_language_matches_source":yn(lang_match),
        "manual_fallback_used":"no"
    })
csv_write("NEW_A_B_RECOMMENDATIONS.csv",list(new_recommendations[0].keys()) if new_recommendations else
          ["source_nid","target_nid","tier","compatibility_evidence"],new_recommendations)

# Aggregate exact pair sets and metrics.
def edge_pairs(ids,manifest):
    return {(sid,int(t)) for sid in ids for t in manifest[str(sid)]["accessories"]}
state={}
for name,man,ev in [("original",orig_manifest,orig_evidence),("fix1",fix1_manifest,fix1_evidence),("corrected",corr_manifest,corr_evidence)]:
    seat_a=[];seat_b=[]
    for sid in old_eligible_seat:
        a=targets(ev,sid,"A_model");b=targets(ev,sid,"B_universal")
        if sid in primary_seat_ids:
            if a:seat_a.append((sid,a))
            if b:seat_b.append((sid,b))
    state[name]={"eligible_seat_sources":len(old_eligible_seat),"primary_sources":len(primary_seat_ids),
        "A_source_count_all_old_eligible":sum(bool(targets(ev,s,"A_model")) for s in old_eligible_seat),
        "B_source_count_all_old_eligible":sum(bool(targets(ev,s,"B_universal")) for s in old_eligible_seat),
        "A_edges_all_old_eligible":sum(len(targets(ev,s,"A_model")) for s in old_eligible_seat),
        "B_edges_all_old_eligible":sum(len(targets(ev,s,"B_universal")) for s in old_eligible_seat),
        "A_source_count_primary":len(seat_a),"B_source_count_primary":len(seat_b),
        "A_edges_primary":sum(len(x[1]) for x in seat_a),"B_edges_primary":sum(len(x[1]) for x in seat_b),
        "primary_without_A_B":len(primary_seat_ids)-len({s for s,_ in seat_a}|{s for s,_ in seat_b}),
        "total_edges":sum(len(x["accessories"]) for x in man.values())}
    state[name]["stroller_edges"]=sum(len(man[str(s)]["accessories"]) for s in stroller_ids)
stroller_pairs={name:edge_pairs(stroller_ids,man) for name,man in [("original",orig_manifest),("fix1",fix1_manifest),("corrected",corr_manifest)]}
similar_diffs={}
for name,man in [("fix1",fix1_manifest),("corrected",corr_manifest)]:
    similar_diffs[name]=sum(orig_manifest[str(s)]["similar"]!=man[str(s)]["similar"] for s in source_meta)
similar_diffs["corrected_vs_fix1"]=sum(corr_manifest[str(s)]["similar"]!=fix1_manifest[str(s)]["similar"] for s in source_meta)
pair_delta={"new_vs_original":len(corr_pairs-orig_pairs),"removed_vs_original":len(orig_pairs-corr_pairs),
            "new_vs_fix1":len(corr_pairs-fix_pairs),"removed_vs_fix1":len(fix_pairs-corr_pairs)}
summary={
 "source_count":len(source_meta),"catalog_rows":len(rows),
 "old_seat_eligible_sources":len(old_eligible_seat),"primary_seat_sources":len(primary_seat_ids),
 "class_counts_original_eligible":dict(Counter(source_class[s] for s in old_eligible_seat)),
 "seat_state":state,"stroller_links_by_state":{k:len(v) for k,v in stroller_pairs.items()},
 "stroller_pair_diffs":{"original_vs_fix1":len(stroller_pairs["original"]^stroller_pairs["fix1"]),
                         "original_vs_corrected":len(stroller_pairs["original"]^stroller_pairs["corrected"]),
                         "fix1_vs_corrected":len(stroller_pairs["fix1"]^stroller_pairs["corrected"])},
 "similar_differences":similar_diffs,"pair_delta":pair_delta,
 "manual_displayed_pairs":len(pairs),"manual_review_decisions":dict(review_counts),
 "manual_commercial_gate_pass":sum(x["catalog_purchase_gate"]=="yes" for x in review_rows),
 "manual_automatic_corrected_selected":sum(x["automatic_corrected_output"]=="yes" for x in review_rows),
 "manual_confirmed_should_offer":sum(x["should_offer_if_gate_passes"]=="yes" for x in review_rows),
 "C_vehicle_general_rows":len(c_rows),"C_vehicle_general_physical_tnids":len({str(x["tnid"]) for x in c_rows}),
 "net_new_A_B_recommendation_rows":len(new_recommendations),
 "new_recommendations_all_gates":all(x["stage1_all_gates_pass"]=="yes" and x["stage1_option_digest_matches_current"]=="yes" for x in new_recommendations),
 "production_writes_attempted":False,"manual_fallback_used":False
}
(CAM/"analysis_summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps(summary,ensure_ascii=False,indent=2))
