from pathlib import Path
D=Path('/opt/bp-accessories-v421-integration-rehearsal-20261112/work/accessories')
for p in list((D/'src').glob('*.py'))+list((D/'tests').glob('*.py')):
    s=p.read_text(encoding='utf8')
    s=s.replace('/opt/bp-accessories-v42-rehearsal-20261112',str(D))
    s=s.replace('/opt/bp-recommendations-full-rollout-rehearsal-20261111/v3.2/engine',
                '/opt/bp-accessories-v421-integration-rehearsal-20261112/upstream/v32/engine')
    p.write_text(s,encoding='utf8')
p=D/'src/v3_rules.py'; s=p.read_text(encoding='utf8')
needle='DOUBLE_RE = re.compile(r"двойн|двійн|близнец|twin|double|duo|для\\s+двух\\s+дет|для\\s+двох\\s+діт", re.I)'
assert needle in s
s=s.replace(needle,needle+'\nMULTI_CHILD_STROLLER_RE = re.compile(r"(?:для\\s+(?:двойн\\w*|двійн\\w*|близнец\\w*|двух\\s+дет\\w*|двох\\s+діт\\w*)|(?:двойн\\w*|двійн\\w*)\\s+(?:коляск\\w*|візк\\w*)|\\b(?:twin|double)\\s+(?:stroller|buggy|pram|pushchair)\\b|\\bfor\\s+(?:two|2)\\s+(?:children|kids)\\b|\\b(?:two|2)[ -]seater\\b)", re.I)\nSINGLE_CHILD_STROLLER_RE = re.compile(r"(?:\\b(?:single|one)[ -]?(?:child|seat|seater)\\s+(?:stroller|buggy|pram|pushchair)\\b|\\bfor\\s+(?:one|1)\\s+(?:child|kid)\\b|одноместн\\w*|одномісн\\w*|для\\s+однієї\\s+дитини|для\\s+одного\\s+реб[её]нк\\w*)", re.I)')
old='''        capacity_text = title + " " + early
        is_double = bool(DOUBLE_RE.search(capacity_text))
        # Width alone is not reliable evidence of a two-child stroller.
        sig["child_capacity"] = "double" if is_double else "single_unspecified"'''
new='''        capacity_text = title + " " + body
        is_double = bool(MULTI_CHILD_STROLLER_RE.search(capacity_text))
        is_single = bool(SINGLE_CHILD_STROLLER_RE.search(capacity_text))
        # Capacity cues must refer to children/seats, not double suspension,
        # dual wheels, two brakes, or a product model name. Ambiguity fails closed.
        sig["child_capacity"] = ("double" if is_double else
                                  "single" if is_single else "single_unspecified")'''
assert old in s;s=s.replace(old,new)
p.write_text(s,encoding='utf8')
p=D/'src/accessory_v4.py'; s=p.read_text(encoding='utf8')
old='''def target_head(row,policy):
    ids=cat_ids(row)
    typ=row.get("type")
    if typ=="kol" and ids & policy["stroller_accessories"]:return "stroller"
    if typ=="kol" and ids & policy["stroller_carrycots"]:return "stroller"
    if typ=="kreslo" and (ids & policy["seat_accessories"] or ids & policy["seat_bases"]):return "car_seat"
    # Only the public car-seat-protector role is admitted from the omitted
    # Drupal help type, and only inside the native car-seat accessories branch.
    if typ=="help" and ids & policy["seat_accessories"]:return "car_seat"
    return None'''
new='''def target_head(row,policy):
    ids=cat_ids(row)
    typ=row.get("type")
    # The source type and target type are distinct. Existing public-export
    # types may provide a target only when Drupal taxonomy places it in the
    # precise stroller/car-seat accessory branch. Kits and omitted help rows
    # remain excluded; no whole-help-category import is performed.
    if typ in ("product_kit","help"):
        return None
    if ids & policy["stroller_accessories"] or ids & policy["stroller_carrycots"]:
        return "stroller"
    if ids & policy["seat_accessories"] or ids & policy["seat_bases"]:
        return "car_seat"
    return None'''
assert old in s;s=s.replace(old,new)
old='''def target_role(target,head):
    title=(target.get("title") or "")
    body=(target.get("body") or "")
    if target.get("type")=="help" and head=="car_seat":
        has_protector=bool(re.search(r"(?i)(?:защитн\\w*\\s+(?:коврик|килимок)|(?:car[ -]?seat|автокресл\\w*)\\s+protector)",title))
        has_seat_context=bool(re.search(r"(?i)(?:автокресл\\w*|car[ -]?seats?)",title))
        if has_protector and has_seat_context:
            return "vehicle_seat_protector"
    return v3_rules.accessory_class(title,body,v39.pipe.categories(target))'''
new='''def target_role(target,head):
    title=(target.get("title") or "")
    body=(target.get("body") or "")
    # A stroller handle muff is not a child footmuff or seat liner.
    if head=="stroller" and re.search(r"(?i)(?:муфт\\w*|muff)\\s+(?:на|для)\\s+(?:ручк\\w*|handle)|(?:ручк\\w*|handle)\\s+(?:муфт\\w*|muff)",title):
        return "handle_muff"
    return v3_rules.accessory_class(title,body,v39.pipe.categories(target))'''
assert old in s;s=s.replace(old,new)
old='''def source_supports_isofix(source):
    text=_text_without_markup((source.get("title") or "")+" "+(source.get("body") or ""))
    for sentence in SENTENCE.split(text):
        if not re.search(r"(?i)\\b(?:isofix|iso[ -]?fix|изофикс|ізофікс)\\b",sentence):
            continue
        if re.search(r"(?i)(?:не|нет|без|not|without).{0,80}(?:isofix|iso[ -]?fix|изофикс|ізофікс)|(?:isofix|iso[ -]?fix|изофикс|ізофікс).{0,80}(?:не|not|without)",sentence):
            continue
        return True
    return False'''
new='''def source_supports_isofix(source):
    text=_text_without_markup((source.get("title") or "")+" "+(source.get("body") or ""))
    term=r"(?:isofix|iso[ -]?fix|изофикс|ізофікс)"
    negative=re.compile(r"(?i)(?:\\b(?:не|нет|без|відсутн\\w*|відсутн\\w*|no|not|without|absent|отсутств\\w*)\\b.{0,100}\\b"+term+r"\\b|\\b"+term+r"\\b.{0,100}\\b(?:не|нет|без|відсутн\\w*|no|not|without|absent|отсутств\\w*)\\b)")
    other_model=re.compile(r"(?i)(?:только|лише|лишь|only)\\s+(?:у|в|для|на)?\\s*(?:друг\\w*|інш\\w*|other)\\s+(?:модел\\w*|model\\w*)|(?:у|в|для)\\s+(?:друг\\w*|інш\\w*)\\s+модел\\w*")
    question=re.compile(r"(?i)(?:\\?|можно\\s+ли|чи\\s+можна|може\\s+ли|можна\\s+чи|под\\s+вопрос\\w*|під\\s+питан\\w*|is\\s+it\\s+possible|can\\s+.{0,20}\\?)")
    for sentence in SENTENCE.split(text):
        if not re.search(r"(?i)\\b"+term+r"\\b",sentence):
            continue
        if negative.search(sentence) or other_model.search(sentence) or question.search(sentence):
            continue
        # A neutral mention, a competitor comparison, or a safety question is
        # not proof of this model's installation hardware.
        if re.search(r"(?i)(?:установка|креплен\\w*|оснащ\\w*|систем\\w*|fit(?:ted)?\\s+with|mounts?\\s+with|equipped\\s+with).{0,80}\\b"+term+r"\\b|\\b"+term+r"\\b.{0,80}(?:систем\\w*|креплен\\w*|крепеж\\w*|mounts?|fitted)",sentence):
            return True
    return False'''
assert old in s;s=s.replace(old,new)
old='''    if role=="vehicle_seat_protector":
        body=_text_without_markup(target.get("body",""))
        all_types=bool(re.search(r"(?i)(?:для всех типов детских автокресел|підходить для всіх типів дитячих автокрісел|all types of (?:child )?car[ -]?seats)",body))
        any_size=bool(re.search(r"(?i)(?:любого размера,? конструкции и высоты|будь-якого розміру,? конструкції та висоти|any size,? construction and height)",body))
        universal=bool(re.search(r"(?i)(?:универсальн\\w*|универсален\\w*|універсальн\\w*|universal\\w*)",body))
        install=bool(re.search(r"(?i)(?:isofix|iso[ -]?fix|изофикс|ізофікс)",body))
        if head!="car_seat" or target.get("type")!="help" or not (all_types and any_size and universal and install):
            return None
        return {"role":role,"evidence":"explicit seller claim: all child-seat types/ages and sizes; ISOFIX installation scope",
                "scope":"category_wide","capacity":"unspecified","brand_tid":None,"requires_isofix":True}'''
new='''    if role=="vehicle_seat_protector":
        # Safety-sensitive under-seat mats require exact model-maker approval
        # and are never admitted as category-universal B from seller wording.
        return None'''
assert old in s;s=s.replace(old,new)
s=s.replace('STROLLER_BROAD={"bag","cup_holder","rain_cover","mosquito_net","seat_liner","textile_cover"}',
            'STROLLER_BROAD={"bag","cup_holder","rain_cover","mosquito_net","seat_liner","textile_cover","handle_muff"}')
# Add role marker used to distinguish a handle muff from unrelated text.
needle=''' "textile_cover":re.compile(r"(?i)(?:чехол\\w*|чохол\\w*|cover\\b|textile|текстил\\w*)")
}'''
replace=''' "textile_cover":re.compile(r"(?i)(?:чехол\\w*|чохол\\w*|cover\\b|textile|текстил\\w*)"),
 "handle_muff":re.compile(r"(?i)(?:муфт\\w*|muff).{0,40}(?:ручк\\w*|handle)|(?:ручк\\w*|handle).{0,40}(?:муфт\\w*|muff)")
}'''
assert needle in s;s=s.replace(needle,replace)
# Capacity evidence from explicit public text, with manufacturer model proof
# kept free of NIDs. Exact model matching inherits to UA/RU translations.
needle='''def eligible_source(row):
    return (row and int(row.get("published") or 0)==1 and'''
insert='''CAPACITY_EVIDENCE=[{
    "brand":"Lionelo", "model":"Elia", "capacity":"single",
    "evidence":"Lionelo Elia is a one-child stroller; the V4.2 function signature was triggered by double suspension/wheels, not passenger capacity.",
    "source":"https://lionelo.pl/products/wozek-spacerowy-elia-beige-taupe"
}]

def stroller_capacity(row):
    sig=row.get("function_signature") or {}
    text=(row.get("title") or "")+" "+(row.get("body") or "")
    multi=bool(v3_rules.MULTI_CHILD_STROLLER_RE.search(text))
    single=bool(v3_rules.SINGLE_CHILD_STROLLER_RE.search(text))
    for rule in CAPACITY_EVIDENCE:
        brand=(row.get("brand") or "").split("(",1)[0].strip().casefold()
        if brand.casefold()!=rule["brand"].casefold():continue
        hit,_=v39.match_exact_model(row.get("title",""),rule["model"])
        if hit=="candidate":
            return rule["capacity"] if not multi else None
    if multi and single:return None
    if multi:return "double"
    if single:return "single"
    # Recompute stale signatures under the corrected capacity rule; never
    # trust an old broad 'double' keyword hit from wheels/suspension.
    if row.get("type")=="kol":
        return v3_rules.functional_signature(row).get("child_capacity")
    return sig.get("child_capacity")

def eligible_source(row):
    return (row and int(row.get("published") or 0)==1 and'''
assert needle in s;s=s.replace(needle,insert)
# Add tier/role stable commercial ordering helper.
needle='''def build_catalog(rows,original,index,policy,fitment_rules=None,option_profiles=None):'''
insert='''def commercial_accessory_order(ids,source,rows,evidence_by_id):
    """Stable preferred-brand ordering within, never across, A/B and role."""
    buckets=collections.OrderedDict()
    for tid in ids:
        row=rows[tid]
        reason=evidence_by_id.get(str(tid),{})
        role=reason.get("role") or target_role(row,source_head(source,{})) if False else None
        role=reason.get("role") or v3_rules.accessory_class(
            row.get("title",""),row.get("body",""),v39.pipe.categories(row)) or "unknown"
        buckets.setdefault(role,[]).append(tid)
    result=[]
    for role,group in buckets.items():
        base={65:0,67:1}
        preferred=sorted([x for x in group if int(rows[x].get("brand_tid") or 0) in base],
                         key=lambda x:base[int(rows[x].get("brand_tid") or 0)])
        result.extend(preferred+[x for x in group if x not in preferred])
    return result

def build_catalog(rows,original,index,policy,fitment_rules=None,option_profiles=None):'''
assert needle in s;s=s.replace(needle,insert)
# Cross-type target pool now respects category branch; reject unsupported type data through taxonomy + role.
# Fix B candidate role order and preserve only selected language/source semantics.
s=s.replace('''        a_ids=list(dict.fromkeys(a_ids))
        old_similar=list(record["similar"])''','''        a_ids=list(dict.fromkeys(a_ids))
        a_ids=commercial_accessory_order(a_ids,source,rows,a_reasons)
        old_similar=list(record["similar"])''')
s=s.replace('''            role_priority={"bag":0,"cup_holder":1,"rain_cover":2,"mosquito_net":3,
                           "seat_liner":4,"textile_cover":5,"vehicle_seat_protector":6}
            # Same-brand compatible-purpose goods outrank cross-brand
            # genuinely universal candidates. Never require 3 to fill.
            candidates.sort(key=lambda x:(
                0 if int(rows[x[1]].get("brand_tid") or 0)==int(source.get("brand_tid") or 0) else 1,
                role_priority.get(x[0],99),x[1]))''','''            role_priority={"bag":0,"cup_holder":1,"handle_muff":2,"rain_cover":3,
                           "mosquito_net":4,"seat_liner":5,"textile_cover":6}
            # First retain V4.2's safe base order, then move only eligible
            # Joolz/Maxi-Cosi products ahead within the same B role.
            candidates.sort(key=lambda x:(
                0 if int(rows[x[1]].get("brand_tid") or 0)==int(source.get("brand_tid") or 0) else 1,
                role_priority.get(x[0],99),x[1]))
            base_by_role=collections.OrderedDict()
            for item in candidates:base_by_role.setdefault(item[0],[]).append(item)
            candidates=[]
            for role,group_items in base_by_role.items():
                pref={65:0,67:1}
                preferred=sorted([x for x in group_items if int(rows[x[1]].get("brand_tid") or 0) in pref],
                                 key=lambda x:pref[int(rows[x[1]].get("brand_tid") or 0)])
                candidates.extend(preferred+[x for x in group_items if x not in preferred])''')
s=s.replace('''                capacity=(source.get("function_signature") or {}).get("child_capacity")''',
            '''                capacity=stroller_capacity(source) if head=="stroller" else (source.get("function_signature") or {}).get("child_capacity")''')
# Remove all V4.2 supplemental help rows; current 28,011 public export already includes cross-type classified goods.
s=s.replace('''    help_doc=json.loads((D/"input/help_public_rows_v42.json").read_text())
    help_rows=help_doc["rows"]
    for row in help_rows:
        if row.get("type")!="help" or row.get("nid") in rows or target_head(row,policy)!="car_seat":
            raise ValueError("invalid scoped help supplemental record")
        rows[int(row["nid"])]=row''','''    # No type=help import. Existing public export already contains a narrow
    # cross-type set in the exported Drupal bundles, gated by exact taxonomy.
    help_rows=[]''')
s=s.replace('''            "no_oem_certification":True})''','''            "no_oem_certification":True,"help_rows_imported":0,
                    "cross_type_policy":"existing_export_taxonomy_branch_and_functional_role"})''')
p.write_text(s,encoding='utf8')
