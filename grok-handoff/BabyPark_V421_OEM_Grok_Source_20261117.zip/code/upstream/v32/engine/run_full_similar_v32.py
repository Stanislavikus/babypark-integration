#!/usr/bin/env python3
"""BabyPark V3 full-current-catalog *preliminary similar* backfill (rehearsal).

Uses V3's original class/category, semantic function gates, full-text TF-IDF and
90% text + 10% price score. Adds only safe candidate indexing, current commerce
target restriction and conservative lexical floor. No production writes.
"""
import argparse
import ast
import collections
import csv
import gzip
import json
import math
import os
import random
import re
import resource
import sys
import time
from pathlib import Path

ROOT=Path("/opt/bp-recommendations-full-rollout-rehearsal-20261111/v3.2/shadow")
V3=Path("/opt/bp-recommendations-full-rollout-rehearsal-20261111/v3.2/engine")
sys.path.insert(0,str(V3))
from v3_rules import similar_compatibility, accessory_class, norm

def get_v3_static_constants():
    source=(V3/"run_v3_final.py").read_text(encoding="utf-8")
    tree=ast.parse(source)
    categories=None;stop=None
    for node in tree.body:
        if not isinstance(node,ast.Assign):continue
        targets={t.id for t in node.targets if isinstance(t,ast.Name)}
        if "CLASS_CATS" in targets:
            categories=ast.literal_eval(node.value)
        if "STOP" in targets:
            expr=ast.get_source_segment(source,node.value)
            match=re.fullmatch(r'set\("""(.*?)"""\.split\(\)\)',expr,re.S)
            assert match, "STOP must have original V3 format"
            stop=set(match.group(1).split())
    assert categories and stop
    return categories,stop

TOKEN_RE=re.compile(r"[a-zа-яёіїєґ0-9]+",re.I)

def tokens(row,stop):
    text=(row["title"]+" "+row["body"]).lower()
    return collections.Counter(w for w in TOKEN_RE.findall(norm(text)) if len(w)>1 and w not in stop)

def cat_ids(row, allowed):
    return {part.split(":",1)[0] for part in row["cats"].split("|") if ":" in part}&allowed

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--sample-sources",type=int,default=0)
    args=parser.parse_args()
    assert args.sample_sources>=0
    started=time.monotonic()
    class_cats,stop=get_v3_static_constants()
    rows=[]
    with gzip.open(ROOT/"current_catalog_records.jsonl.gz","rt",encoding="utf-8") as inp:
        for line in inp:
            r=json.loads(line)
            assert r["lang"] in ("ru","uk") and r["published"]==1
            rows.append(r)
    assert len(rows)==28013
    bynid={r["nid"]:r for r in rows}
    assert len(bynid)==len(rows)
    groups=collections.defaultdict(list)
    for r in rows:
        groups[r["tnid"]].append(r)
    invalid_translation_groups=set()
    for tid,items in groups.items():
        if len(items)!=2 or {x["lang"] for x in items}!={"uk","ru"}:
            invalid_translation_groups.add(tid);continue
        ua=next(x for x in items if x["lang"]=="uk")
        ru=next(x for x in items if x["lang"]=="ru")
        su=ua["function_signature"]; sr=ru["function_signature"]
        if (ua["type"]!=ru["type"] or ua["brand_tid"]!=ru["brand_tid"] or
            su.get("head")!=sr.get("head") or su.get("role")!=sr.get("role")):
            invalid_translation_groups.add(tid)
    counts={}
    dfs=collections.defaultdict(collections.Counter)
    langsizes=collections.Counter()
    for r in rows:
        ct=tokens(r,stop)
        counts[r["nid"]]=ct
        dfs[r["lang"]].update(ct.keys())
        langsizes[r["lang"]]+=1
    idf_by_lang={
        lang:{word:math.log((langsizes[lang]+1)/(df+1))+1 for word,df in dfs[lang].items()}
        for lang in dfs
    }
    vectors={}
    for r in rows:
        lang=r["lang"]
        raw={k:(1+math.log(v))*idf_by_lang[lang][k] for k,v in counts[r["nid"]].items()}
        normval=math.sqrt(sum(v*v for v in raw.values())) or 1.0
        vectors[r["nid"]]={k:v/normval for k,v in raw.items()}
    # Persist the one-time frozen IDF and sparse vectors for scoped incremental reranks.
    with (ROOT/"frozen_idf_v32.json").open("w",encoding="utf-8") as out:
        json.dump(idf_by_lang,out,ensure_ascii=False,sort_keys=True,separators=(",",":"))
        out.write("\n")
    with gzip.open(ROOT/"frozen_vector_index_v32.jsonl.gz","wt",encoding="utf-8",compresslevel=1) as out:
        for nid in sorted(vectors):
            out.write(json.dumps({"nid":nid,"vector":vectors[nid]},ensure_ascii=False,separators=(",",":"))+"\n")
    os.chmod(ROOT/"frozen_idf_v32.json",0o600)
    os.chmod(ROOT/"frozen_vector_index_v32.jsonl.gz",0o600)
    del counts,dfs
    buckets=collections.defaultdict(set)
    target_nids=set()
    for r in rows:
        if r["type"]=="product_kit" or r["tnid"] in invalid_translation_groups:continue
        if not r["eligible_as_similar_target_preliminary"]:continue
        categories=cat_ids(r,class_cats.get(r["type"],set()))
        if not categories:continue
        if accessory_class(r["title"],"",categories):continue
        sig=r["function_signature"]
        if sig["role"]=="component":continue
        for c in categories:
            buckets[(r["lang"],r["type"],c,sig["head"])].add(r["nid"])
        target_nids.add(r["nid"])
    sources=[]
    for r in rows:
        if r["type"]=="product_kit" or r.get("translation_ambiguous") or r["tnid"] in invalid_translation_groups:continue
        cats=cat_ids(r,class_cats.get(r["type"],set()))
        if not cats or not r["function_signature"]["head"]:continue
        if accessory_class(r["title"],"",cats):continue
        if r["function_signature"]["role"]=="component":continue
        sources.append((r,cats))
    if args.sample_sources:
        sources=random.Random(20261109).sample(sources,min(len(sources),args.sample_sources))
    outbase="current_full_similar_sample" if args.sample_sources else "current_full_similar_v32_shadow"
    dest=ROOT/(outbase+".tsv.gz")
    part=dest.with_name(dest.name+".part")
    assert not part.exists()
    if dest.exists():
        raise RuntimeError("Output exists. No implicit overwrite permitted: "+str(dest))
    stats=collections.Counter()
    failures=collections.Counter()
    rows_written=0
    sample=[]
    cosine_ops=0
    start_rank=time.monotonic()
    try:
        with gzip.open(part,"wt",encoding="utf-8",newline="",compresslevel=1) as fh:
            w=csv.writer(fh,delimiter="\t")
            w.writerow(["source_nid","source_tnid","language","source_type","candidate_nid","candidate_tnid","rank","score","tfidf_cosine","price_similarity","shared_category_ids","candidate_field_status","candidate_base_price","evidence"])
            for src,categories in sources:
                sid=src["nid"];stype=src["type"];lang=src["lang"];head=src["function_signature"]["head"]
                ids=set()
                for cat in categories:
                    ids.update(buckets.get((lang,stype,cat,head),()))
                ids.discard(sid)
                ids={i for i in ids if bynid[i]["tnid"]!=src["tnid"]}
                # All existing sources may receive alternatives even when unavailable.
                stats["scanned_source_lang_records"]+=1
                cosine_ops+=len(ids)
                v1=vectors[sid]
                suggestions=[]
                for cid in ids:
                    candidate=bynid[cid]
                    v2=vectors[cid]
                    cosine=sum(w*v2.get(token,0.0) for token,w in v1.items())
                    if cosine<.075:
                        failures["lexical_floor"]+=1
                        continue
                    ok,reason,_,_=similar_compatibility(src,candidate)
                    if not ok:
                        failures[reason]+=1
                        continue
                    p1=src["price"];p2=candidate["price"]
                    psim=1.0/(1.0+abs(math.log(max(p1,1)/max(p2,1)))) if p1>0 and p2>0 else 0.0
                    score=.90*cosine+.10*psim
                    shared=sorted(categories&cat_ids(candidate,class_cats.get(stype,set())))
                    suggestions.append((score,cosine,psim,cid,shared))
                suggestions.sort(key=lambda t:(t[0],t[1],t[2],-t[3]),reverse=True)
                if suggestions:
                    stats["covered_source_lang_records"]+=1
                    stats["covered_"+lang]+=1
                for rank,(score,cosine,psim,cid,shared) in enumerate(suggestions[:20],1):
                    cr=bynid[cid]
                    assert cr["field_status"]==1 and cr["price"]>0 and cr["lang"]==lang
                    assert shared and cr["tnid"]!=src["tnid"] and cr["type"]==stype
                    w.writerow([sid,src["tnid"],lang,stype,cid,cr["tnid"],rank,
                                f"{score:.5f}",f"{cosine:.5f}",f"{psim:.5f}","|".join(shared),
                                cr["field_status"],cr["price"],"V3_FUNCTION_CATEGORY_TFIDF_PRICE_PRELIMINARY"])
                    rows_written+=1
                if suggestions and len(sample)<75 and src["tnid"]%53==0:
                    cr=bynid[suggestions[0][3]]
                    sample.append({"source_nid":sid,"source_title":src["title"],"candidate_nid":cr["nid"],"candidate_title":cr["title"],"score":round(suggestions[0][0],5),"language":lang})
        os.chmod(part,0o600)
        os.replace(part,dest)
    except Exception:
        part.unlink(missing_ok=True)
        raise
    metrics={
        "status":"REHEARSAL_PRELIMINARY_SIMILAR_NO_DRUPAL_DEPLOYMENT",
        "algorithm":"V3 original taxonomy, functional_signature, similar_compatibility, full-text TF-IDF and 0.90 cosine / 0.10 price with minimum cosine 0.075",
        "source_locale_rows":len(rows),
        "distinct_source_groups":len(groups),
        "invalid_translation_groups_excluded":len(invalid_translation_groups),
        "preliminary_target_nids":len(target_nids),
        "eligible_source_records_for_this_strict_run":len(sources),
        "pairs_retrieved_through_existing_type_category_role_index":cosine_ops,
        "recommendation_rows":rows_written,
        "statistics":dict(sorted(stats.items())),
        "rejection_counts":dict(sorted(failures.items())),
        "sample":sample,
        "ranking_seconds":round(time.monotonic()-start_rank,3),
        "total_seconds":round(time.monotonic()-started,3),
        "peak_rss_kib":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "output":dest.name,
        "limitations":[
            "Does not include accessory block",
            "Product kits excluded until validated component membership available",
            "This is no proof of independent relevance beyond prior V3 150-group review",
            "Selected option purchasability is not verified; candidates must be rechecked at render",
            "Only a strict subset of V3 categories/functional roles is eligible",
            "No Drupal render-time selected-OID purchasability or anonymous-page-cache invalidation proof",
            "Incremental event planner and frozen-vector scoped reranker are separate V3.2 rehearsal artifacts",
            "Minimum cosine threshold is a V3 preliminary gate, not independent semantic approval"
        ],
    }
    (ROOT/(outbase+"_metrics.json")).write_text(json.dumps(metrics,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({k:v for k,v in metrics.items() if k not in ("sample","rejection_counts")},ensure_ascii=False,indent=2))
if __name__=="__main__":main()
