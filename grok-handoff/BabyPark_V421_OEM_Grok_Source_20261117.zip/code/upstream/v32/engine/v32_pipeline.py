#!/usr/bin/env python3
"""V3.2 rehearsal: dynamic source indexes and scoped event planning.

Catalog-derived only. Does not read manual recommendation fields or write Drupal.
"""
from __future__ import annotations
import ast, collections, copy, gzip, hashlib, json, resource, sys, time
from pathlib import Path
BASE=Path("/opt/bp-recommendations-full-rollout-rehearsal-20261111/v3.2")
ENGINE=BASE/"engine"
INPUT=BASE/"input/current_catalog_records.jsonl.gz"
INDEX=BASE/"index"
sys.path.insert(0,str(ENGINE))
import canonical_models as cm
from v3_rules import accessory_class, ACCESSORY_SOURCE_TYPES
sys.path.insert(0,str(ENGINE))

def class_categories():
    tree=ast.parse((ENGINE/"run_v3_final.py").read_text(encoding="utf-8"))
    for n in tree.body:
        if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="CLASS_CATS" for t in n.targets):
            return ast.literal_eval(n.value)
    raise RuntimeError("V3 CLASS_CATS not found")

CLASS_CATS=class_categories()

def read_catalog(path=INPUT):
    data={}
    with gzip.open(path,"rt",encoding="utf-8") as f:
        for line in f:
            r=json.loads(line); nid=int(r["nid"])
            if nid in data: raise ValueError("duplicate NID "+str(nid))
            data[nid]=r
    return data

def categories(row):
    allow=CLASS_CATS.get(row.get("type"),set())
    return {p.split(":",1)[0] for p in (row.get("cats") or "").split("|") if ":" in p}&allow

def locales_by_group(rows):
    groups=collections.defaultdict(list)
    for r in rows.values(): groups[int(r["tnid"])].append(r)
    return groups

def invalid_translation_groups(groups):
    bad={}
    for tid,items in groups.items():
        langs=[x.get("lang") for x in items]
        if len(items)>2 or len(langs)!=len(set(langs)) or any(x.get("translation_ambiguous") for x in items):
            bad[str(tid)]="duplicate_or_ambiguous_locale"; continue
        if len(items)==2:
            ua=next((x for x in items if x.get("lang")=="uk"),None)
            ru=next((x for x in items if x.get("lang")=="ru"),None)
            if not ua or not ru:
                bad[str(tid)]="unexpected_locale_pair"; continue
            a=ua.get("function_signature") or {}; b=ru.get("function_signature") or {}
            if ua.get("type")!=ru.get("type"): bad[str(tid)]="type_mismatch"
            elif int(ua.get("brand_tid") or 0)!=int(ru.get("brand_tid") or 0): bad[str(tid)]="brand_mismatch"
            elif a.get("head")!=b.get("head"): bad[str(tid)]="function_head_mismatch"
            elif a.get("role")!=b.get("role"): bad[str(tid)]="role_mismatch"
    return bad

def basic_available(row):
    try: return bool(int(row.get("published") or 0)==1 and int(row.get("field_status") or 0)==1 and float(row.get("price") or 0)>0)
    except (ValueError,TypeError): return False

def identity_group(tid, items):
    bylang={r["lang"]:r for r in items}
    if set(bylang)=={"uk","ru"}:
        ua,ru=bylang["uk"],bylang["ru"]
        iu=cm.extract(ua.get("title",""),ua.get("brand",""))
        ir=cm.extract(ru.get("title",""),ru.get("brand",""))
        if int(ua.get("brand_tid") or 0)!=int(ru.get("brand_tid") or 0):
            status,reason="review","brand_tid_mismatch"
        elif ua.get("type")!=ru.get("type"):
            status,reason="review","type_mismatch"
        elif (ua.get("function_signature") or {}).get("head")!=(ru.get("function_signature") or {}).get("head"):
            status,reason="review","function_head_mismatch"
        elif (ua.get("function_signature") or {}).get("role")!=(ru.get("function_signature") or {}).get("role"):
            status,reason="review","role_mismatch"
        elif iu.status!="indexed" or ir.status!="indexed":
            status,reason="review","canonical_identity_review"
        elif iu.key!=ir.key:
            status,reason="review","ua_ru_model_disagreement"
        else:
            status,reason="indexed","consistent_catalog_identity_candidate"
        model_key=iu.key if iu.key==ir.key else ""
        models={"uk":iu.model,"ru":ir.model}
        ident_status={"uk":iu.status,"ru":ir.status}
    else:
        status,reason="waiting_for_translation","bilingual_pair_not_yet_present"
        models={lang:cm.extract(r.get("title",""),r.get("brand","")).model for lang,r in bylang.items()}
        ident_status={lang:cm.extract(r.get("title",""),r.get("brand","")).status for lang,r in bylang.items()}
        model_key=""
    return status,reason,model_key,models,ident_status,bylang

def build_indexes(rows):
    started=time.perf_counter()
    groups=locales_by_group(rows)
    bad=invalid_translation_groups(groups)
    bad_ids={int(k) for k in bad}
    similar_bad_ids=bad_ids | {int(tid) for tid,items in groups.items() if len(items)!=2}
    source_models={}
    reverse=collections.defaultdict(set)
    token_index=collections.defaultdict(set)
    group_index={}
    counts=collections.Counter()
    for tid,items in groups.items():
        bylang={r["lang"]:r for r in items}
        group_index[str(tid)]={lang:int(r["nid"]) for lang,r in bylang.items()}
        status,reason,mkey,models,istatus,locales=identity_group(tid,items)
        type_set={r.get("type") for r in items}
        type_=next(iter(type_set)) if len(type_set)==1 else None
        candidates=bool(type_ in ACCESSORY_SOURCE_TYPES and tid not in bad_ids)
        if candidates:
            for lang,r in locales.items():
                sig=r.get("function_signature") or {}
                cats=categories(r)
                if not sig.get("head") or sig.get("role")=="component" or not cats:
                    candidates=False; break
                if accessory_class(r.get("title",""),"",cats):
                    candidates=False; break
        if not candidates: continue
        counts["accessory_source_locale_groups"]+=1
        counts["source_groups_by_type:"+str(type_)] += 1
        brandtid=int(next(iter(locales.values())).get("brand_tid") or 0)
        usable=(status=="indexed" and mkey and set(locales)=={"uk","ru"} and brandtid>0)
        record={
            "tnid":int(tid),"type":type_,"brand_tid":brandtid,
            "index_status":status,"reason":reason,"model_key":mkey if usable else None,
            "models":models,"identity_status":istatus,
            "locales":{lang:{"nid":int(r["nid"]),"eligible_at_snapshot":basic_available(r),
                             "published":int(r.get("published") or 0),
                             "status":int(r.get("field_status") or 0),
                             "price":float(r.get("price") or 0),
                             "head":(r.get("function_signature") or {}).get("head")}
                       for lang,r in locales.items()},
        }
        source_models[str(tid)]=record
        if usable:
            counts["indexed_bilingual_groups"]+=1
            key=f"{record['brand_tid']}:{mkey}"
            reverse[key].add(int(tid))
            for lang,model in models.items():
                toks={x.casefold() for x in cm.TOKEN.findall(cm.normal(model))}
                for tok in toks:
                    token_index[f"{record['brand_tid']}:{lang}:{tok}"].add(int(tid))
        else:
            counts["review_or_waiting_groups"]+=1
            counts["review_reason:"+reason]+=1
    # Build existing V3 similar peer buckets once. These indices are consumed by
    # scoped deltas; a content event does not score all source/target pairs.
    bucket=collections.defaultdict(lambda:{"sources":set(),"targets":set()})
    for nid,r in rows.items():
        tid=int(r["tnid"])
        if tid in similar_bad_ids: continue
        if r.get("type")=="product_kit" or r.get("translation_ambiguous"): continue
        cats=categories(r); sig=r.get("function_signature") or {}
        if not cats or not sig.get("head") or sig.get("role")=="component": continue
        if accessory_class(r.get("title",""),"",cats): continue
        for cat in cats:
            key=f"{r.get('lang')}|{r.get('type')}|{cat}|{sig['head']}"
            bucket[key]["sources"].add(int(nid))
            if r.get("eligible_as_similar_target_preliminary") and basic_available(r):
                bucket[key]["targets"].add(int(nid))
    idx={
        "schema":"babypark-v3.2-dynamic-index-v1",
        "catalog_nids":len(rows),
        "source_models":source_models,
        "reverse_models":{k:sorted(v) for k,v in sorted(reverse.items())},
        "model_tokens":{k:sorted(v) for k,v in sorted(token_index.items())},
        "groups":group_index,
        "invalid_translation_groups":bad,
        "similar_excluded_groups":sorted(similar_bad_ids),
        "similar_buckets":{k:{"sources":sorted(v["sources"]),"targets":sorted(v["targets"])}
                           for k,v in sorted(bucket.items())},
        "metrics":{"groups":len(groups),"invalid_translation_groups":len(bad),
                   "model_index_source_groups":len(source_models),**dict(counts),
                   "reverse_model_keys":len(reverse),
                   "reverse_key_collisions":sum(len(v)>1 for v in reverse.values()),
                   "similar_bucket_keys":len(bucket),
                   "similar_groups_excluded_for_incomplete_or_inconsistent_translation":len(similar_bad_ids),
                   "build_seconds":round(time.perf_counter()-started,4),
                   "peak_rss_kib":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},
    }
    return idx

def save_indexes(idx):
    INDEX.mkdir(mode=0o700,parents=True,exist_ok=True)
    rows=idx["source_models"]
    with gzip.open(INDEX/"source_model_index_v32.jsonl.gz","wt",encoding="utf-8",compresslevel=5) as f:
        for tid in sorted(rows,key=int):
            f.write(json.dumps(rows[tid],ensure_ascii=False,sort_keys=True,separators=(",",":"))+"\n")
    for name,obj in (("reverse_model_index_v32.json",idx["reverse_models"]),
                     ("model_token_index_v32.json",idx["model_tokens"]),
                     ("translation_group_index_v32.json",idx["groups"]),
                     ("invalid_translation_groups_v32.json",idx["invalid_translation_groups"]),
                     ("similar_group_exclusions_v32.json",idx["similar_excluded_groups"]),
                     ("similar_bucket_index_v32.json",idx["similar_buckets"]),
                     ("index_build_metrics_v32.json",idx["metrics"])):
        (INDEX/name).write_text(json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(",",":"))+"\n",encoding="utf-8")
    for p in INDEX.iterdir(): p.chmod(0o600)

def index_from_disk():
    def read(name): return json.loads((INDEX/name).read_text(encoding="utf-8"))
    with gzip.open(INDEX/"source_model_index_v32.jsonl.gz","rt",encoding="utf-8") as f:
        models={str(x["tnid"]):x for x in map(json.loads,f)}
    return {
        "source_models":models,"reverse_models":read("reverse_model_index_v32.json"),
        "model_tokens":read("model_token_index_v32.json"),
        "groups":read("translation_group_index_v32.json"),
        "similar_buckets":read("similar_bucket_index_v32.json"),
        "invalid_translation_groups":read("invalid_translation_groups_v32.json"),
        "similar_excluded_groups":read("similar_group_exclusions_v32.json"),
    }

def accessory_class_for(row):
    return accessory_class(row.get("title",""),row.get("body",""),categories(row))

def lookup_accessory_sources(row,idx,rows):
    lang=row.get("lang"); brand=int(row.get("brand_tid") or 0)
    if lang not in ("uk","ru") or brand<=0 or row.get("type")=="product_kit": return []
    if not accessory_class_for(row): return []
    text=cm.normal((row.get("title","") or "")+" "+(row.get("body","") or ""))
    words={x.casefold() for x in cm.TOKEN.findall(text)}
    possible=set()
    for word in words:
        possible.update(idx["model_tokens"].get(f"{brand}:{lang}:{word}",()))
    hits=[]
    for tid in sorted(possible):
        entry=idx["source_models"].get(str(tid))
        if not entry or entry.get("index_status")!="indexed" or int(entry.get("brand_tid") or 0)!=brand: continue
        locale=entry.get("locales",{}).get(lang)
        model=entry.get("models",{}).get(lang)
        if not locale or not model: continue
        decision,detail=cm.exact_mention(text,model)
        if decision in ("candidate","version_review"):
            hits.append({"source_tnid":int(tid),"source_nid":int(locale["nid"]),
                         "language":lang,"model":model,"evidence_decision":decision,
                         "evidence_detail":detail,"recompute_only":True})
    return hits

def semantic_fingerprint(r):
    return {
        "tnid":int(r.get("tnid") or r["nid"]),"lang":r.get("lang"),"type":r.get("type"),
        "title":cm.normal(r.get("title","")).casefold(),"body":cm.normal(r.get("body","")).casefold(),
        "brand_tid":int(r.get("brand_tid") or 0),"brand":cm.normal(r.get("brand","")).casefold(),
        "cats":sorted(categories(r)),
        "function_signature":r.get("function_signature"),
        "translation_ambiguous":bool(r.get("translation_ambiguous")),
    }

def commerce_fingerprint(r):
    return (int(r.get("published") or 0),int(r.get("field_status") or 0),
            round(float(r.get("price") or 0),4),str(r.get("option_digest") or ""))

def event_type(old,new):
    if old is None: return "new_published" if new and int(new.get("published") or 0)==1 else "new_draft"
    if new is None: return "removed"
    if int(old.get("published") or 0)!=1 and int(new.get("published") or 0)==1: return "first_publication"
    if int(old.get("published") or 0)==1 and int(new.get("published") or 0)!=1: return "unpublished"
    if semantic_fingerprint(old)!=semantic_fingerprint(new): return "semantic_content_changed"
    if commerce_fingerprint(old)!=commerce_fingerprint(new): return "commercial_projection_changed"
    return "metadata_only"

def event_bucket_keys(row):
    if not row or row.get("type")=="product_kit" or row.get("translation_ambiguous"): return set()
    cats=categories(row); sig=row.get("function_signature") or {}
    if not cats or not sig.get("head") or sig.get("role")=="component": return set()
    if accessory_class(row.get("title",""),"",cats): return set()
    return {f"{row.get('lang')}|{row.get('type')}|{cat}|{sig['head']}" for cat in cats}

def plan_single_event(old,new,idx,rows,generated_reverse=None):
    generated_reverse=generated_reverse or {}
    nid=int((new or old)["nid"]); et=event_type(old,new)
    out=collections.defaultdict(set)
    reasons=collections.Counter()
    if et in ("new_draft","metadata_only"):
        return {"nid":nid,"event":et,"affected_source_nids":[],"reasons":{},"full_catalog_rescore":False}
    # New/changed source page; use group index so UA/RU pages remain separate
    # locale payloads but are refreshed as a shared physical model group.
    item=new or old
    tid=str(int(item.get("tnid") or nid))
    for lang,source_nid in idx["groups"].get(tid,{}).items():
        out[int(source_nid)].add("source_group_changed")
    if not idx["groups"].get(tid) and item.get("type")!="product_kit":
        out[nid].add("source_or_target_changed")
    # Recalculate only same function/category peer buckets affected by the old/new row.
    if et in ("new_published","first_publication","unpublished","removed","semantic_content_changed","commercial_projection_changed"):
        for row in (old,new):
            for key in event_bucket_keys(row):
                for peer in idx["similar_buckets"].get(key,{}).get("sources",()):
                    out[int(peer)].add("similar_bucket_refresh")
                    reasons["similar_bucket_refresh"]+=1
    # Existing generated edges are reverse dependencies for removal/price/status.
    for source_nid in generated_reverse.get(str(nid),()):
        out[int(source_nid)].add("generated_target_changed")
    # Model mentions in old AND new accessory text trigger affected model groups.
    for row in (old,new):
        if row:
            for hit in lookup_accessory_sources(row,idx,rows):
                out[hit["source_nid"]].add("accessory_model_evidence_refresh")
                reasons["accessory_model_evidence_refresh"]+=1
    return {
        "nid":nid,"event":et,"affected_source_nids":sorted(out),
        "reasons":{str(k):sorted(v) for k,v in sorted(out.items())},
        "affected_source_count":len(out),"full_catalog_rescore":False,
        "manual_recommendation_fields_read":False,
    }

def write_event_report(events,output):
    output.write_text(json.dumps(events,ensure_ascii=False,indent=2,sort_keys=True)+"\n",encoding="utf-8")

def main():
    rows=read_catalog()
    idx=build_indexes(rows)
    save_indexes(idx)
    out={"schema":"babypark-v3.2-index-build-v1","status":"REHEARSAL_ONLY",
         "catalog_rows":len(rows),"metrics":idx["metrics"],
         "source_types":sorted(ACCESSORY_SOURCE_TYPES),
         "source_group_model_index_path":"index/source_model_index_v32.jsonl.gz",
         "reverse_model_index_path":"index/reverse_model_index_v32.json",
         "similar_bucket_index_path":"index/similar_bucket_index_v32.json"}
    (BASE/"evidence/index_build_summary_v32.json").write_text(json.dumps(out,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    (BASE/"evidence/index_build_summary_v32.json").chmod(0o600)
    print(json.dumps(out,ensure_ascii=False,indent=2))
if __name__=="__main__": main()
