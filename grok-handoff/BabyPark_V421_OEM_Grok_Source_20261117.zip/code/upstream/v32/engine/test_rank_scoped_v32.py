#!/usr/bin/env python3
"""V3.2 frozen-vector scoped-ranker parity and new-product rehearsal tests."""
import csv,gzip,json,hashlib,copy,sys,time,resource
from pathlib import Path
BASE=Path("/opt/bp-recommendations-full-rollout-rehearsal-20261111/v3.2")
sys.path.insert(0,str(BASE/"engine"))
import rank_scoped_v32 as r
import v32_pipeline as p
rows=r.load_rows()
read_start=time.perf_counter()
idf,vectors=r.load_frozen()
vector_load_s=time.perf_counter()-read_start
bucket=json.loads((BASE/"index/similar_bucket_index_v32.json").read_text(encoding="utf-8"))
full={}
with gzip.open(BASE/"shadow/current_full_similar_v32_shadow.tsv.gz","rt",encoding="utf-8",newline="") as f:
    for x in csv.DictReader(f,delimiter="\t"):
        full.setdefault(int(x["source_nid"]),[]).append((int(x["rank"]),int(x["candidate_nid"]),round(float(x["score"]),5)))
source=next(n for n in sorted(full) if rows[n]["type"]=="kol" and rows[n]["lang"]=="uk")
start=time.perf_counter()
scoped=r.scope_rank([source],rows,vectors,idf,bucket=bucket)
parity_s=time.perf_counter()-start
actual=[(x["rank"],x["candidate_nid"],x["score"]) for x in scoped["sources"][source]]
expected=sorted(full[source])
passed=[];failed=[]
def check(name,ok,detail=None):
    (passed if ok else failed).append({"name":name,"detail":detail})
check("SCOPED_RERANK_MATCHES_FULL_SHADOW_TOP20",actual==expected,
      {"source_nid":source,"expected_count":len(expected),"actual_count":len(actual),
       "first_expected":expected[:3],"first_actual":actual[:3]})
check("SCOPED_RANKER_DID_NOT_SCORE_FULL_CORPUS",
      scoped["full_corpus_pair_rescore"] is False and scoped["source_count"]==1 and scoped["candidate_pairs_scored"]<2000,
      {"source_count":scoped["source_count"],"pair_count":scoped["candidate_pairs_scored"]})

# Synthetic new bilingual main product, added only to in-memory rehearsal rows.
src=copy.deepcopy(rows[source])
nid_uk=99000001;nid_ru=99000002;tnid=99000000
new_uk=copy.deepcopy(src);new_ru=copy.deepcopy(src)
ru_source=next(r for r in rows.values() if int(r["tnid"])==int(src["tnid"]) and r["lang"]=="ru")
new_ru.update(title=ru_source["title"],body=ru_source.get("body",""))
for x,n,lang in ((new_uk,nid_uk,"uk"),(new_ru,nid_ru,"ru")):
    x["nid"]=n;x["tnid"]=tnid;x["raw_tnid"]=tnid;x["lang"]=lang
    x["title"]=(src["title"] if lang=="uk" else ru_source["title"])+" Nova 77"
    x["sku"]="IN_MEMORY_TEST_ONLY"
    x["published"]=1;x["field_status"]=1;x["price"]=float(src["price"] or 1000)
    x["translation_ambiguous"]=False;x["eligible_as_similar_target_preliminary"]=True
rows[nid_uk]=new_uk;rows[nid_ru]=new_ru
before_idf=hashlib.sha256(json.dumps(idf,sort_keys=True,separators=(",",":")).encode()).hexdigest()
start=time.perf_counter();new_vec=r.vector_for(new_uk,idf,r.load_static()[1]);vector_create_s=time.perf_counter()-start
vectors[nid_uk]=new_vec
new_result=r.scope_rank([source],rows,vectors,idf,extra_target_nids=[nid_uk],bucket=bucket)
new_targets=[x["candidate_nid"] for x in new_result["sources"][source]]
check("NEW_PRODUCT_VECTOR_USES_FROZEN_IDF",
      nid_uk not in full and new_vec and before_idf==hashlib.sha256(json.dumps(idf,sort_keys=True,separators=(",",":")).encode()).hexdigest(),
      {"new_vector_terms":len(new_vec),"idf_sha256_stable":before_idf==hashlib.sha256(json.dumps(idf,sort_keys=True,separators=(",",":")).encode()).hexdigest()})
check("NEW_PRODUCT_TARGET_AFFECTS_ONLY_SCOPED_SOURCE",
      nid_uk in new_targets and new_result["source_count"]==1 and new_result["candidate_pairs_scored"]<2000,
      {"new_target_rank":new_targets.index(nid_uk)+1 if nid_uk in new_targets else None,
       "scored_source_count":new_result["source_count"],
       "candidate_pairs":new_result["candidate_pairs_scored"]})
# Changed body updates just that node's sparse vector; baseline IDF remains frozen.
edited=copy.deepcopy(src);edited["body"]=(edited.get("body") or "")+" Event content update."
edited_vec=r.vector_for(edited,idf,r.load_static()[1])
check("SEMANTIC_EDIT_REBUILDS_ONLY_CHANGED_VECTOR",
      edited_vec!=vectors[source] and before_idf==hashlib.sha256(json.dumps(idf,sort_keys=True,separators=(",",":")).encode()).hexdigest(),
      {"old_terms":len(vectors[source]),"new_terms":len(edited_vec),"idf_sha256_stable":True})
# Commercial-only edit has no semantic fingerprint change and no vector update path.
price_edit=copy.deepcopy(src);price_edit["price"]=float(src.get("price") or 0)+1
check("PRICE_ONLY_CHANGE_DOES_NOT_CHANGE_SEMANTIC_FINGERPRINT",
      p.semantic_fingerprint(src)==p.semantic_fingerprint(price_edit))

report={
 "schema":"babypark-v3.2-scoped-ranker-tests-v1",
 "status":"PASS" if not failed else "FAIL",
 "passed":len(passed),"failed":len(failed),"cases":passed+failed,
 "selected_real_source_nid":source,
 "full_shadow_source_count":len(full),
 "cached_vector_count":len(vectors)-1,
 "catalog_load_seconds":None,
 "frozen_vector_load_seconds":round(vector_load_s,4),
 "warm_scoped_rerank_seconds":round(parity_s,4),
 "new_vector_build_seconds":round(vector_create_s,6),
 "new_event_candidate_pairs_scored":new_result["candidate_pairs_scored"],
 "full_corpus_pair_rescore":False,
 "peak_rss_kib":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
 "note":"The new source fixture exists only in process memory. This proves frozen-IDF scoped scoring, not a 1C import or native Drupal generation commit."
}
out=BASE/"evidence/scoped_ranker_tests_v32.json"
out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8");out.chmod(0o600)
print(json.dumps({"status":report["status"],"passed":report["passed"],"failed":report["failed"],
                  "failures":failed,"source_nid":source,"candidate_pairs":new_result["candidate_pairs_scored"],
                  "scoped_rerank_seconds":report["warm_scoped_rerank_seconds"],
                  "new_target_rank":new_targets.index(nid_uk)+1 if nid_uk in new_targets else None,
                  "peak_rss_kib":report["peak_rss_kib"]},ensure_ascii=False,indent=2))
if failed:raise SystemExit(1)
