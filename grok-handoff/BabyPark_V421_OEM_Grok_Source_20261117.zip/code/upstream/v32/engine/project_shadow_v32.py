#!/usr/bin/env python3
"""Validate V3.2 shadow candidates against the current public catalog snapshot."""
import csv,gzip,hashlib,json,collections,sys,time
from pathlib import Path
BASE=Path("/opt/bp-recommendations-full-rollout-rehearsal-20261111/v3.2")
sys.path.insert(0,str(BASE/"engine"))
import v32_pipeline as v
import canonical_models as cm
rows=v.read_catalog()
idx=v.index_from_disk()
full_metrics=json.loads((BASE/"shadow/current_full_similar_v32_shadow_metrics.json").read_text(encoding="utf-8"))
def stream(path):
    with gzip.open(path,"rt",encoding="utf-8",newline="") as f:
        yield from csv.DictReader(f,delimiter="\t")
sim_path=BASE/"shadow/current_full_similar_v32_shadow.tsv.gz"
acc_path=BASE/"shadow/pilot_accessories_v32-dynamic.tsv.gz"
similar=collections.defaultdict(list)
accessories=collections.defaultdict(list)
reject_sim=collections.Counter();reject_acc=collections.Counter()
source_type=collections.Counter();lang_counts=collections.Counter()
bad_group_ids={int(k) for k in idx["invalid_translation_groups"]}
for x in stream(sim_path):
    sid=int(x["source_nid"]);tid=int(x["candidate_nid"])
    s=rows.get(sid);t=rows.get(tid)
    reason=None
    if not s or not t: reason="nid_missing_current_snapshot"
    elif s["lang"]!=x["language"] or t["lang"]!=x["language"]: reason="language_mismatch"
    elif int(s["tnid"])==int(t["tnid"]): reason="same_physical_group"
    elif s["type"]!=t["type"] or s["type"]=="product_kit" or t["type"]=="product_kit": reason="type_or_kit"
    elif not v.basic_available(t) or not t.get("eligible_as_similar_target_preliminary"): reason="target_not_basic_eligible"
    elif int(t["tnid"]) in bad_group_ids: reason="target_translation_group_inconsistent"
    elif not x.get("shared_category_ids"): reason="no_shared_category"
    if reason: reject_sim[reason]+=1; continue
    key=str(sid)
    similar[key].append({"nid":tid,"tnid":int(t["tnid"]),"rank":int(x["rank"]),
                         "score":float(x["score"]),"language":s["lang"],"type":s["type"]})
    source_type[s["type"]]+=1;lang_counts[s["lang"]]+=1

for x in stream(acc_path):
    sid=int(x["source_nid"]);tid=int(x["candidate_nid"]);stnid=int(x["source_tnid"])
    s=rows.get(sid);t=rows.get(tid);entry=idx["source_models"].get(str(stnid))
    reason=None
    if not s or not t: reason="nid_missing_current_snapshot"
    elif not entry or entry.get("index_status")!="indexed": reason="source_model_not_indexed"
    elif int(entry["locales"].get(s["lang"],{}).get("nid",-1))!=sid: reason="source_locale_mismatch"
    elif s["lang"]!=x["language"] or t["lang"]!=x["language"]: reason="language_mismatch"
    elif int(s["tnid"])!=stnid or int(t["tnid"])==stnid: reason="self_or_group_mismatch"
    elif s["type"]=="product_kit" or t["type"]=="product_kit": reason="kit"
    elif t.get("translation_ambiguous") or not v.basic_available(t): reason="target_not_basic_eligible"
    else:
        model=entry.get("models",{}).get(s["lang"],"")
        decision,_=cm.exact_mention((t.get("title","") or "")+" "+(t.get("body","") or ""),model)
        if not model or decision!="candidate": reason="canonical_model_or_generation_review"
    if reason: reject_acc[reason]+=1;continue
    key=str(sid)
    accessories[key].append({"nid":tid,"tnid":int(t["tnid"]),"rank":int(x["rank"]),
                             "language":s["lang"],"relation_type":"unverified_text_fitment_candidate",
                             "evidence_span":x["evidence_span"]})
# Preserve score order, remove duplicate physical target groups; suppress cross-block overlap.
manifest_sources={}
cross_block_suppressed=0
source_langs={}
for sid in sorted(set(similar)|set(accessories),key=int):
    sr=rows[int(sid)]
    seen_tnids=set()
    s_list=[]
    for item in sorted(similar.get(sid,[]),key=lambda a:(a["rank"],-a["score"],a["nid"])):
        if item["tnid"] in seen_tnids: continue
        seen_tnids.add(item["tnid"])
        if len(s_list)<20:s_list.append(item["nid"])
    a_list=[];seen_acc=set()
    for item in sorted(accessories.get(sid,[]),key=lambda a:(a["rank"],a["nid"])):
        if item["tnid"] in seen_tnids:
            cross_block_suppressed+=1;continue
        if item["tnid"] in seen_acc: continue
        seen_acc.add(item["tnid"])
        if len(a_list)<20:a_list.append(item["nid"])
    manifest_sources[sid]={"language":sr["lang"],"similar":s_list,"accessories":a_list}
manifest={
 "schema":"babypark-recommendations-v3.2-shadow-v1",
 "generation_id":"v3.2-shadow-pending",
 "sources":manifest_sources,
}
payload=json.dumps(manifest,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode("utf-8")
generation=hashlib.sha256(payload).hexdigest()[:18]
manifest["generation_id"]="v3.2-shadow-"+generation
payload=json.dumps(manifest,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode("utf-8")
(BASE/"shadow/manifest_v32_shadow.json").write_bytes(payload+b"\n")
(BASE/"shadow/manifest_v32_shadow.json").chmod(0o600)
# Quality/coverage projection: full lists are candidate coverage; 5/4 caps mimic native carousel limits.
sim_counts=collections.Counter();acc_counts=collections.Counter()
for source,items in similar.items():sim_counts[rows[int(source)]["type"]]+=len({x["tnid"] for x in items})
for source,items in accessories.items():acc_counts[rows[int(source)]["type"]]+=len({x["tnid"] for x in items})
capped_sim=collections.Counter();capped_acc=collections.Counter()
for sid,x in manifest_sources.items():
    capped_sim[rows[int(sid)]["type"]]+=min(5,len(x["similar"]))
    capped_acc[rows[int(sid)]["type"]]+=min(4,len(x["accessories"]))
metrics={
 "schema":"babypark-v3.2-full-shadow-validation-v1",
 "status":"REHEARSAL_SHADOW_NOT_PRODUCTION_APPROVAL",
 "catalog_nids":len(rows),
 "similar":{
  "rows_after_current_snapshot_guards":sum(len(vv) for vv in similar.values()),
  "source_locale_blocks_with_candidates":len(similar),
  "source_locale_blocks_scored":int(full_metrics["eligible_source_records_for_this_strict_run"]),
  "coverage_of_scored_sources":round(len(similar)/int(full_metrics["eligible_source_records_for_this_strict_run"]),6),
  "candidate_counts_by_source_type":dict(sorted(sim_counts.items())),
  "max5_visible_candidates_by_source_type":dict(sorted(capped_sim.items())),
  "rejected_current_snapshot":dict(reject_sim),
  "historical_independent_quality_sample":{"correct":91,"reviewed":106,"strict_precision":round(91/106,6),
   "wrong_observed":0,"unknown":15,"scope":"selected V3 top-1 review only; not a full-catalog estimate"}
 },
 "accessories":{
  "raw_v32_dynamic_rows":sum(1 for _ in stream(acc_path)),
  "source_locale_blocks_with_candidates":len(accessories),
  "rows_after_dynamic_identity_and_current_eligibility":sum(len(vv) for vv in accessories.values()),
  "candidate_counts_by_source_type":dict(sorted(acc_counts.items())),
  "max4_visible_candidates_by_source_type":dict(sorted(capped_acc.items())),
  "rejected_current_snapshot":dict(reject_acc),
  "manufacturer_verified_relations":0,
  "relation_label":"all accepted rows remain text-evidenced, manufacturer-unverified candidates"
 },
 "deduplication":{
  "cross_block_target_groups_suppressed":cross_block_suppressed,
  "same_locale_cross_block_duplicates_after_suppression":0
 },
 "dynamic_manifest":{
  "source_locale_blocks":len(manifest_sources),
  "bytes":len(payload)+1,
  "gzip_bytes":len(gzip.compress(payload+b"\n",compresslevel=6)),
  "renderer_cap_5_similar_4_accessory_bytes":len(json.dumps({
      "schema":manifest["schema"],"generation_id":manifest["generation_id"],
      "sources":{k:{"language":v["language"],"similar":v["similar"][:5],"accessories":v["accessories"][:4]}
                  for k,v in manifest["sources"].items()}},
      ensure_ascii=False,sort_keys=True,separators=(",",":")).encode("utf-8")),
  "current_six_source_manifest_bytes":(Path("/opt/bp-recommendations-v3-native-integration-20261109/private/active.json").stat().st_size),
  "production_relay_limit_bytes":65536,
  "exceeds_existing_relay_limit":len(payload)+1>65536,
  "schema":"shadow schema only; existing production strict pilot schema/whitelist unchanged"
 },
 "frozen_index":{
  "idf_bytes":(BASE/"shadow/frozen_idf_v32.json").stat().st_size,
  "vectors_gzip_bytes":(BASE/"shadow/frozen_vector_index_v32.jsonl.gz").stat().st_size
 },
 "limitations":[
  "Similarity truth is not independently labeled at catalog scale; use historical selected evaluation only.",
  "Accessories are not OEM verified; selected OID, kit/component and live stock checks are not represented in this public catalog snapshot.",
  "Native Drupal renderer, manifest receiver and page-cache invalidation are still six-source pilot only.",
  "Old live anonymous cache can bypass render-time Stage1 checks; no full-catalog cache freshness guarantee."
 ]
}
out=BASE/"evidence/full_shadow_validation_v32.json"
out.write_text(json.dumps(metrics,ensure_ascii=False,indent=2,sort_keys=True)+"\n",encoding="utf-8");out.chmod(0o600)
print(json.dumps(metrics,ensure_ascii=False,indent=2))
