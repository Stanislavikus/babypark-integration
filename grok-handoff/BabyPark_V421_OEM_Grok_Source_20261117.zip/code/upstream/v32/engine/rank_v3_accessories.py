#!/usr/bin/env python3
"""Conservative current-catalog V3 accessory retrieval, rehearsal only.

Reuses original V1 model extractor and V3 generation/negative/fitment gates.
May produce text-evidenced *candidates*, never manufacturer certified fitment.
No product links, manual fields, production access or runtime modifications.
"""
from __future__ import annotations
import collections
import csv
import os
import gzip
import json
import os
import re
import resource
import sys
import time
from pathlib import Path

ROOT=Path(os.environ.get("BP_V3_INPUT_DIR","/opt/bp-recommendations-full-catalog-20261109"))
OUTROOT=Path(os.environ.get("BP_V3_OUTPUT_DIR",str(ROOT)))
GENERATION=os.environ.get("BP_V3_GENERATION","candidate")
V3=Path("/opt/bp-recommendations-full-rollout-rehearsal-20261111/v3.2/engine")
V1=Path("/opt/bp-recommendations-full-rollout-rehearsal-20261111/v3.2/engine/v1")
sys.path.insert(0,str(V3))
from v3_rules import (
    accessory_class, accessory_candidate_status, ACCESSORY_SOURCE_TYPES,
    norm
)

# Both reused fragments contain ONLY imports, regex and pure helper definitions;
# each prefix ends before the original catalog loading/writing.
model_ns={}
model_source=(V1/"prepare_sources.py").read_text(encoding="utf-8")
assert model_source.count("\nrows=[]")==1
exec(compile(model_source.split("\nrows=[]")[0],str(V1/"prepare_sources.py"),"exec"),model_ns)
extract_model=model_ns["extract_model"]
variants=model_ns["variants"]

v3_ns={}
runner_source=(V3/"run_v3_final.py").read_text(encoding="utf-8")
assert runner_source.count("# Catalog records")==1
exec(compile(runner_source.split("# Catalog records")[0],str(V3/"run_v3_final.py"),"exec"),v3_ns)
toks=v3_ns["toks"]
toks_with_spans=v3_ns["toks_with_spans"]
find_spans_from_tokens=v3_ns["find_spans_from_tokens"]
sentence_at=v3_ns["sentence_at"]
cat_ids=v3_ns["cat_ids"] if "cat_ids" in v3_ns else lambda s:{q.split(":",1)[0] for q in s.split("|") if ":" in q}

def safe_csv(s):
    return re.sub(r"[\t\r\n]+"," ",str(s or "")).strip()

STROLLER_OBJECT=re.compile(r"(?:коляс(?:к|ок)\w*|віз(?:к|ок)\w*|stroller\w*|buggy\b)",re.I)
CAR_SEAT_OBJECT=re.compile(r"(?:автокресл\w*|автокрісл\w*|car\s+seat|infant\s+carrier)",re.I)

def source_object_conflict(source_type, evidence_sentence):
    # A text match for a model name is not proof that an accessory fits
    # a different *kind of product* with that model's name.
    if source_type=="kreslo" and STROLLER_OBJECT.search(evidence_sentence) and not CAR_SEAT_OBJECT.search(evidence_sentence):
        return True
    if source_type=="kol" and CAR_SEAT_OBJECT.search(evidence_sentence) and not STROLLER_OBJECT.search(evidence_sentence):
        return True
    return False

def main():
    started=time.monotonic()
    bygroup=collections.defaultdict(dict)
    records=[]
    with gzip.open(ROOT/"current_catalog_records.jsonl.gz","rt",encoding="utf-8") as f:
        for line in f:
            x=json.loads(line)
            if not x.get("translation_ambiguous"):
                assert x["lang"] not in bygroup[x["tnid"]],("duplicate",x["tnid"],x["lang"])
                bygroup[x["tnid"]][x["lang"]]=x
            records.append(x)
    assert len(records)>=20000
    only_sources={int(x) for x in os.environ.get("BP_V3_SOURCE_NIDS","").split(",") if x.isdigit()}
    known={}
    token_to_keys=collections.defaultdict(set)
    skipped=collections.Counter()
    for tid,locales in bygroup.items():
        if only_sources and not any(v["nid"] in only_sources for v in locales.values()):
            continue
        if len(locales)!=2 or set(locales)!={"uk","ru"}:
            skipped["not_bilingual"]+=1;continue
        base=locales["ru"]
        if base["type"] not in ACCESSORY_SOURCE_TYPES:continue
        if base["type"]=="product_kit":continue
        if base["function_signature"]["role"]=="component":continue
        if not base["function_signature"]["head"]:continue
        if accessory_class(base["title"],"",cat_ids(base["cats"])):
            skipped["source_is_accessory"]+=1;continue
        extracted={}
        for lang,row in locales.items():
            model,confidence=extract_model(row["title"],row["brand"])
            extracted[lang]=(model,confidence)
        if min(v[1] for v in extracted.values())<.55:
            skipped["low_model_confidence"]+=1;continue
        brandbase=norm(base["brand"].split("(")[0].strip())
        if len(brandbase)<3:
            skipped["unknown_brand"]+=1;continue
        known[tid]={"brand":brandbase,"model":{lang:x[0] for lang,x in extracted.items()},"source":locales}
        for lang,(model,confidence) in extracted.items():
            for alias in variants(model):
                pat=tuple(toks(alias))
                if not pat:continue
                if len("".join(pat))<4:continue
                key=(tid,lang,pat)
                for token in set(pat):
                    token_to_keys[(lang,token)].add(key)
    status=collections.Counter()
    rejected=collections.Counter()
    hits=collections.defaultdict(dict)
    candidates=0
    checks=0
    evidence_found=0
    for item in records:
        if item["type"]=="product_kit" or item.get("translation_ambiguous"):continue
        if item["field_status"]!=1 or item["price"]<=0:continue
        if not item["body"]:continue
        ck=accessory_class(item["title"],item["body"],cat_ids(item["cats"]))
        if not ck:continue
        candidates+=1
        lang=item["lang"]
        tokenized=toks_with_spans(item["body"])
        all_tokens={t[0] for t in tokenized}
        possible=set()
        for token in all_tokens:
            possible.update(token_to_keys.get((lang,token),()))
        full=norm(item["title"]+" "+item["body"])
        for tid,mlang,pat in possible:
            if not set(pat)<=all_tokens:continue
            src=known.get(tid)
            if not src or tid==item["tnid"] or src["brand"] not in full:continue
            checks+=1
            matches=find_spans_from_tokens(tokenized,list(pat))
            if not matches:continue
            best=None
            source_row=src["source"][lang]
            context=source_row["title"]+" "+src["model"][lang]
            for start,end in matches:
                sentence=sentence_at(item["body"],start,end)
                matching=item["body"][start:end]
                if source_object_conflict(source_row["type"],sentence):
                    status["explicit_evidence_wrong_product_role"]+=1
                    rejected["explicit_evidence_wrong_product_role"]+=1
                    continue
                decision,kind,_=accessory_candidate_status(
                    source_row["type"],item["title"],item["body"],cat_ids(item["cats"]),
                    sentence,item["title"]+" "+item["body"],context,"",
                    True,True,True,matching)
                status[decision]+=1
                if decision!="accepted_strong_text_only":
                    rejected[decision]+=1
                    continue
                quality=(len(sentence),item["nid"])
                if best is None or quality<best[0]:
                    best=(quality,sentence,kind,matching)
            if best is None:continue
            evidence_found+=1
            key=(tid,lang)
            # Deduplicate aliases/translations of the same physical target group.
            prev=hits[key].get(item["tnid"])
            result={
                "source_tnid":tid,"source_nid":source_row["nid"],"language":lang,
                "candidate_tnid":item["tnid"],"candidate_nid":item["nid"],
                "accessory_class":best[2],"source_model":src["model"][lang],
                "evidence_span":safe_csv(best[1]),
                "evidence_confidence":"high_text_evidence_unverified_manufacturer",
            }
            if prev is None or len(result["evidence_span"])<len(prev["evidence_span"]):
                hits[key][item["tnid"]]=result
    dest=OUTROOT/("pilot_accessories_"+GENERATION+".tsv.gz")
    assert not dest.exists()
    tmp=dest.with_name(dest.name+".part")
    n=0;covered=0
    with gzip.open(tmp,"wt",encoding="utf-8",newline="",compresslevel=1) as f:
        w=csv.DictWriter(f,fieldnames=["source_tnid","source_nid","language","candidate_tnid","candidate_nid","rank","accessory_class","source_model","evidence_span","evidence_confidence"],delimiter="\t")
        w.writeheader()
        for key,items in sorted(hits.items()):
            ranked=sorted(items.values(),key=lambda r:(len(r["evidence_span"]),r["candidate_nid"]))[:20]
            if ranked:covered+=1
            for rank,row in enumerate(ranked,1):
                w.writerow({**row,"rank":rank})
                n+=1
    os.chmod(tmp,0o600);os.rename(tmp,dest)
    met={
        "status":"REHEARSAL_PRELIMINARY_ACCESSORIES_UNVERIFIED_MANUFACTURER",
        "source_main_model_groups_with_usable_aliases":len(known),
        "candidate_accessories_in_stock_with_concrete_class_and_body":candidates,
        "explicit_model_checks":checks,
        "strong_fitment_hit_raw_count":evidence_found,
        "source_locale_blocks_with_accepted_text":covered,
        "recommendation_rows":n,
        "skipped_model_reasons":dict(skipped),
        "v3_gate_decisions":dict(status),
        "v3_rejections":dict(rejected),
        "runtime_seconds":round(time.monotonic()-started,3),
        "peak_rss_kib":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "output":dest.name,
        "limitations":[
            "Explicit public product text is not manufacturer-verified fitment.",
            "Only selected available accessory products and bilingual confidently extracted main model sources.",
            "Conservative: adapters and option/kit-dependent fitment are blocked, not assumed.",
            "Source model extraction can be wrong; independent human review still needed.",
            "No proof all fitment statements or negative conflicts are covered.",
            "No Drupal integration, page-cache strategy, published stock/option recheck or incremental recompute.",
            "No manual recommendation references read."
        ],
    }
    (OUTROOT/("pilot_accessories_"+GENERATION+"_metrics.json")).write_text(json.dumps(met,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(met,ensure_ascii=False,indent=2))
if __name__=="__main__":main()
