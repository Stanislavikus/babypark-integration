#!/usr/bin/env python3
import base64,csv,html,json,math,re,time,unicodedata
from pathlib import Path
from collections import Counter,defaultdict
from itertools import combinations
R=Path("/opt/bp-auto-recommendations-v3-20261109/baseline_inputs")
O=Path("/opt/bp-auto-recommendations-v3-20261109")
from v3_rules import similar_compatibility, accessory_candidate_status, accessory_class, generation_guard_tests, generation_suffix_after_tokens
t0=time.perf_counter()
def dec(s):
 try:return base64.b64decode(s).decode("utf-8","replace")
 except:return ""
def plain(s):
 s=html.unescape(s or "")
 s=re.sub(r"</(?:p|li|h[1-6]|div)>"," . ",s,flags=re.I)
 s=re.sub(r"<br\s*/?>"," . ",s,flags=re.I)
 s=re.sub(r"<[^>]+>"," ",s)
 return re.sub(r"[ \t]+"," ",s).strip()
def norm(s):
 s=unicodedata.normalize("NFKC",html.unescape(s or ""))
 for a,b in zip("⁰¹²³⁴⁵⁶⁷⁸⁹","0123456789"):s=s.replace(a,b)
 return s.lower()
TOKEN_RE=re.compile(r"[a-zа-яёіїєґ0-9]+(?:[-/][a-zа-яёіїєґ0-9]+)*\+?|[+]",re.I)
def toks_with_spans(s):
 s=norm(s); raw=[]
 for m in TOKEN_RE.finditer(s):
  val=m.group(0).lower()
  if raw and raw[-1][0].isalpha() and val.isdigit() and s[raw[-1][2]:m.start()].isspace():
   raw[-1]=(raw[-1][0]+val,raw[-1][1],m.end())
  else:raw.append((val,m.start(),m.end()))
 return raw
def toks(s):return [x[0] for x in toks_with_spans(s)]
def find_spans_from_tokens(ts,pat):
 vals=[x[0] for x in ts];n=len(pat);out=[]
 for i in range(len(vals)-n+1):
  if vals[i:i+n]==pat:
   suffix=generation_suffix_after_tokens(vals,i+n)
   if suffix:continue
   out.append((ts[i][1],ts[i+n-1][2]))
 return out
def find_spans(text,pat):return find_spans_from_tokens(toks_with_spans(text),pat)
def find_generation_conflicts_from_tokens(ts,pat):
 vals=[x[0] for x in ts];n=len(pat);out=[]
 for i in range(len(vals)-n):
  if vals[i:i+n]==pat:
   suffix=generation_suffix_after_tokens(vals,i+n)
   if suffix:out.append((ts[i][1],ts[i+n-1][2],suffix))
 return out
def find_generation_conflicts(text,pat):return find_generation_conflicts_from_tokens(toks_with_spans(text),pat)
def sentence_at(text,start,end):
 left=max(text.rfind(".",0,start),text.rfind("!",0,start),text.rfind("?",0,start),text.rfind("\n",0,start),text.rfind(";",0,start))
 stops=[x for x in [text.find(".",end),text.find("!",end),text.find("?",end),text.find("\n",end),text.find(";",end)] if x>=0]
 right=min(stops) if stops else len(text)
 return text[left+1:right].strip()
def safe_csv(s):return re.sub(r"[\t\r\n]+"," ",str(s or "")).strip()
ACC_RE=re.compile(r"\b(аксессуар\w*|аксесуар\w*|accessor\w*|дождевик|дощовик|rain\s?cover|umbrella|адаптер\w*|adapter\w*|подстаканник|підсклянник|cup\s?holder|сумк\w*|\bbag\b|чехол|чохол|cover|вкладыш|вкладиш|liner|footmuff|конверт|муфт\w*|бампер\w*|bumper|москитн\w*|mosquito|сітка|сетка|люльк\w*|bassinet|подножк\w*|footrest|накидк\w*|органайзер|organizer|текстиль|textile|столешниц\w*|\btray\b|ремн\w*\s+(?:безопасности|безпеки)|harness|спинк\w*|backrest|насадк\w*|запчаст\w*)\b",re.I)
ACCESSORY_CATS={"20","134","140","815","590","593","1561","1562","1604","1605"}
STRONG_POS=re.compile(r"\b(compatible\s+with|fits?\s+(?:the\s+)?|suitable\s+for|підходить\s+(?:до|для)|подходит\s+(?:к|для)|сумісн\w*\s+(?:з|із|зі|для)|совместим\w*\s+(?:с|со|для)|сумісність|совместимость)\b",re.I)
WEAK_POS=re.compile(r"\b(for|für|для)\b",re.I)
NEG=re.compile(r"\b(not\s+(?:compatible|suitable|fit)|does\s+not\s+fit|не\s+(?:подходит|сумісн\w*|совместим\w*|підходить)|не\s+для|несовместим\w*|несумісн\w*)\b",re.I)
# Catalog records
src_rows=[json.loads(x) for x in (R/"source_records.jsonl").read_text(encoding="utf-8").splitlines() if x.strip()]
kit_component_titles=defaultdict(list)
with (R/"product_kit_components.jsonl").open(encoding="utf-8") as f:
 for line in f:
  if line.strip():
   item=json.loads(line)
   kit_component_titles[str(item.get("kit_nid",""))].append(str(item.get("component_title","")))
for row in src_rows:
 row["kit_component_titles"]=" ".join(kit_component_titles.get(str(row.get("nid","")),[]))
model_rows={}
with (R/"model_inventory.tsv").open(encoding="utf-8",newline="") as f:
 for x in csv.DictReader(f,delimiter="\t"):
  model_rows[x["tnid"]]={**x,"eligible":x["source_eligible"]=="1","pat":toks(x["model"])}
sources=defaultdict(dict)
for x in src_rows:sources[str(x["tnid"])][x["lang"]]=x
candidate={}
def add_full_file(path):
 with (R/path).open(encoding="utf-8",newline="") as f:
  for x in csv.reader(f,delimiter="\t"):
   if len(x)!=10:continue
   nid,tnid,typ,lang,sku,price,title64,body64,brand64,cats=x
   candidate[nid]={"nid":nid,"tnid":tnid,"type":typ,"lang":lang,"sku":sku,"price":price,"title":plain(dec(title64)),"body":plain(dec(body64)),"brand":plain(dec(brand64)),"cats":cats}
add_full_file("accessory_hit_bodies.tsv")
add_full_file("body_model_matches.tsv")
title_rows=[]
with (R/"candidate_title_matches.tsv").open(encoding="utf-8",newline="") as f:
 for x in csv.reader(f,delimiter="\t"):
  if len(x)!=9:continue
  nid,tnid,typ,lang,sku,price,title64,brand64,cats=x
  title_rows.append({"nid":nid,"tnid":tnid,"type":typ,"lang":lang,"sku":sku,"price":price,"title":plain(dec(title64)),"brand":plain(dec(brand64)),"cats":cats})
  if nid not in candidate:candidate[nid]=title_rows[-1]|{"body":""}
# Similar algorithm: strict bundle and primary catalog category; lexical TF-IDF + price proximity.
CLASS_CATS={
 "kol":{"128","108","909","110","1591","1589","908","1590"},
 "kreslo":{"138","139","135","136","137","16","17","13","14","15"},
 "mebel":{"147","21","377","301","145","26","24","143","142","23"},
 "product_kit":{"128","108","909","110","1591","1589","908","1590","138","139","135","136","137","16","17","13","14","15","147","21"},
 "toy":{"361","365","363","352","1208","1167","364","353","1466","362","279","283","175","1207","1166","299"},
 "transport":{"149","29"},
 "wear":{"911","910","1056","1473"},
 "product":set()
}
def cat_ids(cats):return {x.split(":",1)[0] for x in (cats or "").split("|") if ":" in x}
def is_acc(title,cats,typ):
 ids=cat_ids(cats)
 return bool(ACC_RE.search(title)) or bool(ids&ACCESSORY_CATS)
STOP=set("""для та і в з на по у від до як або що це этот эта такие детский детская дитячий дитяча baby kids stroller коляска коляски автокресло автокрісло автокресла кресло стілець стульчик стулья автокресло для оплата доставка гарантия гарантія товар новый новий купить купити модель можно можноя the and or with for a an in of de la und der die das""".split())
def content_tokens(row):
 text=(row.get("title","")+" "+(row.get("body") or row.get("body_html") or "")).lower()
 arr=[t for t in re.findall(r"[a-zа-яёіїєґ0-9]+",norm(text)) if len(t)>1 and t not in STOP]
 return Counter(arr)
lang_docs={}
for lang in ("uk","ru"):
 docs=[]
 for tid,lmap in sources.items():
  row=lmap.get(lang)
  if row:docs.append((tid,row,content_tokens(row)))
 df=Counter()
 for _,_,ct in docs:df.update(ct.keys())
 N=max(1,len(docs))
 idf={w:math.log((N+1)/(df[w]+1))+1 for w in df}
 vec={}
 for tid,row,ct in docs:
  v={w:(1+math.log(n))*idf[w] for w,n in ct.items()}
  normv=math.sqrt(sum(a*a for a in v.values())) or 1
  vec[(tid,lang)]={w:a/normv for w,a in v.items()}
 lang_docs[lang]=(docs,vec)
def cos(a,b):
 return sum(v*b.get(k,0.0) for k,v in a.items())
similar_rows=[]; pair_reason=Counter(); block_covered=Counter(); sim_start=time.perf_counter()
for sid,langs in sources.items():
 sm=model_rows.get(sid,{})
 if not sm or not sm.get("eligible"):continue
 srow=langs.get("uk") or langs.get("ru")
 stype=srow["type"]
 for lang,sr in langs.items():
  if lang not in ("uk","ru"):continue
  scats=cat_ids(sr.get("cats",""))&CLASS_CATS.get(stype,set())
  candidates=[]
  for cid,clangs in sources.items():
   if cid==sid:continue
   cr=clangs.get(lang)
   if not cr:continue
   cm=model_rows.get(cid,{})
   if not cm or not cm.get("eligible"):pair_reason["accessory_or_unclassified"]+=1;continue
   if cr["type"]!=sr["type"]:pair_reason["bundle_type_mismatch"]+=1;continue
   if cr["type"]=="product_kit" and sr["type"]!="product_kit":pair_reason["kit_separated"]+=1;continue
   ccat=cat_ids(cr.get("cats",""))&CLASS_CATS.get(stype,set())
   shared=scats&ccat
   if not shared:pair_reason["no_shared_main_category"]+=1;continue
   compatible, gate, source_signature, candidate_signature = similar_compatibility(sr, cr)
   if not compatible:
    pair_reason[gate]+=1
    continue
   sim=cos(lang_docs[lang][1].get((sid,lang),{}),lang_docs[lang][1].get((cid,lang),{}))
   try:p1=float(sr.get("price") or 0);p2=float(cr.get("price") or 0)
   except:p1=p2=0
   psim=1.0/(1.0+abs(math.log(max(p1,1)/max(p2,1)))) if p1>0 and p2>0 else 0.0
   score=.90*sim+.10*psim
   candidates.append((score,sim,psim,cid,cr,sorted(shared),source_signature,candidate_signature))
   pair_reason["category_eligible_pair"]+=1
  candidates.sort(key=lambda x:(x[0],x[1],x[2]),reverse=True)
  top=candidates[:20]
  if top:block_covered[lang]+=1
  for rank,(score,sim,psim,cid,cr,shared,source_signature,candidate_signature) in enumerate(top,1):
   similar_rows.append([sid,sr["type"],lang,sr["title"],cid,cr["title"],"|".join(shared),rank,f"{score:.5f}",f"{sim:.5f}",f"{psim:.5f}",cr.get("price",""),cr.get("sku",""),cr.get("nid",""),json.dumps(source_signature,ensure_ascii=False,sort_keys=True),json.dumps(candidate_signature,ensure_ascii=False,sort_keys=True)])
sim_seconds=time.perf_counter()-sim_start
sim_counts_by_block=Counter((x[0],x[2]) for x in similar_rows)
sim_blocks_capped=sum(n>=20 for n in sim_counts_by_block.values())
with (O/"similar_recommendations.tsv").open("w",encoding="utf-8",newline="") as f:
 w=csv.writer(f,delimiter="\t");w.writerow(["source_tnid","source_type","language","source_title","candidate_tnid","candidate_title","shared_main_category_ids","rank","score","tfidf_cosine","price_similarity","candidate_sell_price","candidate_sku","candidate_nid","source_function","candidate_function"]);w.writerows(similar_rows)
# V3 accessory matcher: only concrete item types with direct positive full-text fitment evidence.
acc_start=time.perf_counter()
body_pairs=[];rejected=[];source_body_hit=set();source_title_hit=set();source_body_lang_hit=set();source_title_lang_hit=set();source_lang_cov=Counter();status_counts=Counter();unique_acc=set();by_model=defaultdict(set);body_rows_seen=set()
option_rows_by_nid=defaultdict(list)
with (R/"product_options_subset.jsonl").open(encoding="utf-8") as f:
 for line in f:
  if line.strip():
   item=json.loads(line);option_rows_by_nid[str(item.get("nid",""))].append(item)
kit_rows_by_nid=defaultdict(list)
with (R/"product_kit_components.jsonl").open(encoding="utf-8") as f:
 for line in f:
  if line.strip():
   item=json.loads(line);kit_rows_by_nid[str(item.get("kit_nid",""))].append(item)
for c in candidate.values():
 title=c["title"];body=c.get("body","");typ=c["type"];lang=c["lang"]
 texts=[("title",title,toks_with_spans(title))]
 if body:texts.append(("body",body,toks_with_spans(body)))
 category_ids=cat_ids(c.get("cats",""))
 candidate_kind=accessory_class(title,body,category_ids)
 if typ=="product_kit":candidate_kind=None
 for sid,m in model_rows.items():
  if not m.get("eligible") or min(float(m["ua_confidence"] or 0),float(m["ru_confidence"] or 0))<.55:continue
  if lang not in sources.get(sid,{}):continue
  pat=m["pat"]
  if not pat:continue
  found=[]
  for where,txt,tokenized in texts:
   for a,b in find_spans_from_tokens(tokenized,pat):
    sent=sentence_at(txt,a,b)
    found.append((where,txt,sent,txt[a:b]))
  if not found:
   conflicts=[(where,x) for where,txt,tokenized in texts for x in find_generation_conflicts_from_tokens(tokenized,pat)]
   if conflicts:
    where,hit=conflicts[0]
    rejected.append([sid,m["type"],m["brand"],m["model"],c["nid"],c["tnid"],typ,lang,title,"generation_suffix_mismatch:"+hit[2]])
    status_counts["generation_suffix_mismatch"]+=1
   continue
  if any(where=="title" for where,_,_,_ in found):source_title_hit.add(sid);source_title_lang_hit.add((sid,lang))
  if any(where=="body" for where,_,_,_ in found):source_body_hit.add(sid);source_body_lang_hit.add((sid,lang))
  if sid==c["tnid"]:continue
  brandbase=m["brand"].split("(")[0].strip()
  combined_text=title+" "+body
  brand_ok=not brandbase or norm(brandbase) in norm(combined_text)
  if not brand_ok:
   rejected.append([sid,m["type"],m["brand"],m["model"],c["nid"],c["tnid"],typ,lang,title,"brand_missing"])
   status_counts["brand_missing"]+=1;continue
  if candidate_kind is None:
   reason="candidate_not_clear_accessory"
   rejected.append([sid,m["type"],m["brand"],m["model"],c["nid"],c["tnid"],typ,lang,title,reason])
   status_counts[reason]+=1;continue
  src=sources[sid].get(lang,{})
  src_options=option_rows_by_nid.get(str(src.get("nid","")),[])
  src_kit=kit_rows_by_nid.get(str(src.get("nid","")),[])
  source_context=" ".join([str(src.get("title","")),str(m.get("model",""))])
  option_context=" ".join([str(x.get("label",""))+" "+str(x.get("option_name","")) for x in src_options]+[str(x.get("component_title","")) for x in src_kit])
  target_negative=any(NEG.search(sent) for where,txt,sent,matched_model in found)
  if target_negative:
   rejected.append([sid,m["type"],m["brand"],m["model"],c["nid"],c["tnid"],typ,lang,title,"negative_or_contradictory"])
   status_counts["negative_or_contradictory"]+=1
   continue
  strong_hits=[]
  for where,txt,sent,matched_model in found:
   decision,kind,condition_check=accessory_candidate_status(m["type"],title,body,category_ids,sent,combined_text,source_context,option_context,True,brand_ok,where=="body",matched_model)
   if decision=="accepted_strong_text_only":
    strong_hits.append((where,txt,sent,matched_model,kind,condition_check))
  if not strong_hits:
   # Record the strongest precise failure reason for the evaluated model/product pair.
   decisions=[]
   for where,txt,sent,matched_model in found:
    decisions.append(accessory_candidate_status(m["type"],title,body,category_ids,sent,combined_text,source_context,option_context,True,brand_ok,where=="body",matched_model)[0])
   reason=next((x for x in ["negative_or_contradictory","unresolved_option_or_component_dependency","unresolved_versioned_component","no_strong_compatibility_phrase","ineligible_source_type"] if x in decisions),decisions[0] if decisions else "no_strong_compatibility_phrase")
   rejected.append([sid,m["type"],m["brand"],m["model"],c["nid"],c["tnid"],typ,lang,title,reason])
   status_counts[reason]+=1;continue
  # Prefer body evidence, then the shortest explicit sentence; save the exact untruncated quote.
  where,txt,sent,matched_model,kind,condition_check=sorted(strong_hits,key=lambda x:(0 if x[0]=="body" else 1,len(x[2])))[0]
  status="SHOW_STRONG_COMPATIBILITY_TEXT_ONLY"
  evidence=safe_csv(sent)
  confidence="high_text_evidence_unverified_manufacturer"
  matched_in=where
  body_pairs.append([sid,m["type"],lang,m["brand"],m["model"],c["nid"],c["tnid"],typ,title,c.get("brand",""),status,confidence,evidence,matched_in,matched_model,kind,condition_check])
  source_lang_cov[lang]+=1;status_counts[status]+=1;unique_acc.add(c["tnid"]);by_model[sid].add(c["tnid"])
# Deduplicate candidate products and cap at 20 per source model/language.
status_order={"SHOW_STRONG_COMPATIBILITY_TEXT_ONLY":0}
acc_groups=defaultdict(list)
for row in body_pairs:acc_groups[(row[0],row[2])].append(row)
acc_unique_counts=[len({r[6] for r in rows}) for rows in acc_groups.values()]
accessory_blocks_capped=sum(n>20 for n in acc_unique_counts)
max_accessory_before_cap=max(acc_unique_counts,default=0)
accepted_acc=[]
for key,rows in acc_groups.items():
 best={}
 for row in rows:
  k=row[6]
  if k not in best or (status_order.get(row[10],9),0 if row[13]=="title" else 1)<(status_order.get(best[k][10],9),0 if best[k][13]=="title" else 1):best[k]=row
 ordered=sorted(best.values(),key=lambda r:(status_order.get(r[10],9),0 if r[13]=="title" else 1,r[8].lower(),r[6]))[:20]
 for rank,row in enumerate(ordered,1):accepted_acc.append(row+[rank])
with (O/"accessory_recommendations.tsv").open("w",encoding="utf-8",newline="") as f:
 w=csv.writer(f,delimiter="\t");w.writerow(["source_tnid","source_type","language","source_brand","source_model","candidate_nid","candidate_tnid","candidate_type","candidate_title","candidate_brand","decision","evidence_confidence","evidence_span","matched_in","matched_model_text","accessory_class","condition_check","rank"]);w.writerows(accepted_acc)
with (O/"REJECTED_CANDIDATES.tsv").open("w",encoding="utf-8",newline="") as f:
 w=csv.writer(f,delimiter="\t");w.writerow(["source_tnid","source_type","source_brand","source_model","candidate_nid","candidate_tnid","candidate_type","language","candidate_title","reject_reason"]);w.writerows(rejected)
# Unified accepted rows preserve both separate algorithm outputs and their evidence.
combined=[]
for row in similar_rows:combined.append(["similar",row[0],row[1],row[2],row[3],row[13],row[4],row[5],row[7],row[8],"TFIDF_PRICE_RANKED","proxy_only","same_category_sample"])
for row in accepted_acc:combined.append(["accessory",row[0],row[1],row[2],row[3]+" "+row[4],row[5],row[6],row[8],row[17],"",row[10],row[11],row[12]])
with (O/"ACCEPTED_CANDIDATES.tsv").open("w",encoding="utf-8",newline="") as f:
 w=csv.writer(f,delimiter="\t");w.writerow(["algorithm","source_tnid","source_type","language","source_label","candidate_nid","candidate_tnid","candidate_title","rank","score","evidence_status","evidence_confidence","evidence"]);w.writerows(combined)
# Legacy parser, negation and accessory-class suites are unchanged and intentionally not rerun.
tests=[]
negative_tests=[]
accessory_class_tests=[]
# Exact-title hit baseline for the harvested alias-query result set.
title_exact_pairs=set();title_exact_sources=set()
for c in title_rows:
 for sid,m in model_rows.items():
  if not m.get("eligible") or c["lang"] not in sources.get(sid,{}):continue
  if find_spans(c["title"],m["pat"]):
   brandbase=m["brand"].split("(")[0].strip().lower()
   if not brandbase or brandbase in (c["title"]+" "+c.get("brand","")).lower():
    title_exact_pairs.add((sid,c["tnid"],c["lang"]));title_exact_sources.add(sid)
# Metrics
eligible=[m for m in model_rows.values() if m["eligible"]]
low=sum(min(float(m["ua_confidence"] or 0),float(m["ru_confidence"] or 0))<.55 for m in eligible)
src_groups=len(model_rows);pair_counts=Counter()
for r in src_rows:pair_counts[r["lang"]]+=1
sim_by_lang={}
for lang in ("uk","ru"):
 rows=[x for x in similar_rows if x[2]==lang]
 sources_lang=sum(1 for sid,lmap in sources.items() if lang in lmap and model_rows.get(sid,{}).get("eligible"))
 covered=len({x[0] for x in rows})
 counts=Counter(x[0] for x in rows)
 sim_by_lang[lang]={"source_blocks":sources_lang,"covered_blocks":covered,"coverage_pct":round(100*covered/max(1,sources_lang),2),"recommendation_rows":len(rows),"avg_candidates_per_source":round(sum(counts.values())/max(1,sources_lang),2),"empty_blocks":sources_lang-covered}
acc_by_lang={}
for lang in ("uk","ru"):
 sids={m["tnid"] for m in eligible if lang in sources.get(m["tnid"],{})}
 scored={m["tnid"] for m in eligible if lang in sources.get(m["tnid"],{}) and min(float(m.get("ua_confidence") or 0),float(m.get("ru_confidence") or 0))>=.55}
 matched={x[0] for x in accepted_acc if x[2]==lang}
 acc_by_lang[lang]={"eligible_source_models":len(sids),"scored_source_models":len(scored),"models_with_accepted_recommendation":len(matched),"coverage_pct_of_eligible":round(100*len(matched)/max(1,len(sids)),2),"coverage_pct_of_scored":round(100*len(matched)/max(1,len(scored)),2),"accepted_rows":sum(1 for x in accepted_acc if x[2]==lang),"raw_match_rows_before_dedupe_and_cap":sum(1 for x in body_pairs if x[2]==lang),"rejected_rows":sum(1 for x in rejected if x[7]==lang)}
body_search_rows=sum(1 for _ in (R/"body_model_matches.tsv").open(encoding="utf-8"))-1
accepted_status=Counter(x[10] for x in accepted_acc)
metrics={
 "source_selection":{"distinct_models":src_groups,"published_language_records":len(src_rows),"ua_records":pair_counts["uk"],"ru_records":pair_counts["ru"],"both_language_models":sum({"uk","ru"}<=set(v.keys()) for v in sources.values()),"eligible_main_model_sources":len(eligible),"low_confidence_excluded_from_scoring":low,"by_type":dict(Counter(m["type"] for m in model_rows.values()))},
 "inputs":{"candidate_title_match_rows":len(title_rows),"candidate_title_match_groups":len({x["tnid"] for x in title_rows}),"candidate_full_body_rows":sum(bool(c.get("body")) for c in candidate.values()),"candidate_full_body_groups":len({x["tnid"] for x in candidate.values() if x.get("body")}),"body_model_query_rows":body_search_rows,"body_search_model_families":13,"search_scope":"raw node.title and field_data_body.body_value only; no Search API/index and no manual reference fields"},
 "similar_algorithm":{"method":"same Drupal bundle/category plus deterministic functional-head, bundle/component, double-stroller, use-mode, configuration, weight and clothing-gender gates; full-text TF-IDF; price contributes 10% only after functional gates; cap 20","candidate_universe":"150 source models, within the stratified source sample","language_metrics":sim_by_lang,"recommendation_rows":len(similar_rows),"max_candidates_per_block":max(sim_counts_by_block.values(),default=0),"blocks_reaching_20_candidate_cap":sim_blocks_capped,"gate_counts":dict(pair_reason),"limitations":["No manual-link ground truth used","Within-sample candidate universe; not full-catalog recall","Wear-size/age/weight compatibility is not available as a guaranteed normalized field"]},
 "accessory_algorithm":{"method":"exact full-title/full-body brand/model-generation match; concrete accessory-class gate independent of Drupal accessory category; source-type allowlist; same-sentence strong positive required; local negative and unresolved option/version/component conditions veto; cap 20","title_match_exact_generation_pairs":len(title_exact_pairs),"title_covered_source_models":len(title_exact_sources),"body_candidate_records_with_full_text":sum(bool(c.get("body")) for c in candidate.values()),"body_covered_source_models":len(source_body_hit),"title_text_covered_source_models":len(source_title_hit),"unique_text_candidate_groups_before_cap":len(unique_acc),"raw_candidate_pairs_before_dedupe_and_cap":len(body_pairs),"accepted_candidate_pairs_after_dedupe_and_cap":len(accepted_acc),"blocks_reaching_20_candidate_cap":accessory_blocks_capped,"max_unique_candidates_before_cap":max_accessory_before_cap,"rejected_candidate_rows":len(rejected),"real_explicit_negative_rows":status_counts.get("explicit_negative_fitment",0),"real_contradictory_rows":status_counts.get("contradictory_fitment_statements",0),"accepted_status_counts":dict(accepted_status),"raw_status_counts":dict(status_counts),"language_metrics":acc_by_lang,"top20_cap":20,"physical_fitment_verified":False,"limitations":["Textual fitment statements are not manufacturer validation","Full-description body candidate search covered 13 critical model families, not all 150","Title/body name-only matches are unverified suggestions; not proof of physical fitment"]},
 "similar_functional_gate_tests":generation_guard_tests(),
 "legacy_test_suites":{"status":"NOT_RERUN_UNCHANGED_LOGIC","prior_generation_tests":"baseline_inputs/generation_tests.json (15/15)","prior_negation_tests":"baseline_inputs/negation_tests.json (7/7)","prior_accessory_classifier_tests":"baseline_inputs/accessory_classifier_tests.json (4/4)"},
 "performance":{"algorithm_runtime_seconds":round(time.perf_counter()-t0,4),"similar_runtime_seconds":round(sim_seconds,4),"accessory_runtime_seconds":round(time.perf_counter()-acc_start,4),"similar_candidate_rows_scored":sum(pair_reason.values()),"accessory_record_to_model_comparisons":len(candidate)*len(eligible),"implementation":"pure Python 3, stdlib; executed on rehearsal"}
}
(O/"QUALITY_METRICS.json").write_text(json.dumps(metrics,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
# Legacy test output files are preserved in baseline_inputs and not overwritten.\nprint(json.dumps({"source_models":src_groups,"eligible":len(eligible),"similar_rows":len(similar_rows),"similar_covered_ua":sim_by_lang["uk"]["covered_blocks"],"similar_covered_ru":sim_by_lang["ru"]["covered_blocks"],"accessory_raw_pairs":len(body_pairs),"accessory_accepted_pairs":len(accepted_acc),"accessory_status":dict(status_counts),"acc_sources_hit":len(source_body_hit),"title_candidates":len(title_rows),"full_body_rows":sum(bool(c.get("body")) for c in candidate.values()),"generation_pass":sum(x["pass"] for x in tests),"generation_total":len(tests),"negation_pass":sum(x["pass"] for x in negative_tests),"negation_total":len(negative_tests),"runtime":metrics["performance"]},ensure_ascii=False))
