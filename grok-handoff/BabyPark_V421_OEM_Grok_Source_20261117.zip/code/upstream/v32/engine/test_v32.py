#!/usr/bin/env python3
"""Targeted V3.2 dynamic-index and event tests. Synthetic nodes stay in memory."""
import copy, json, sys, time, gzip, collections, resource
from pathlib import Path
BASE=Path("/opt/bp-recommendations-full-rollout-rehearsal-20261111/v3.2")
sys.path.insert(0,str(BASE/"engine"))
import v32_pipeline as v
from canonical_models import extract, exact_mention, candidate_for
rows=v.read_catalog()
idx=v.index_from_disk()
passed=[]; failed=[]
def check(name,condition,detail=None):
    (passed if condition else failed).append({"name":name,"detail":detail})
def get_group_by_key(key):
    ids=idx["reverse_models"].get(key,[])
    return ids

# Dynamic model resolution from real bilingual public catalog entries.
check("REAL_NOBLE_REVERSE_INDEX",get_group_by_key("737:noble")==[144884],get_group_by_key("737:noble"))
check("REAL_BAYAMO_REVERSE_INDEX",145262 in get_group_by_key("43:bayamo"),get_group_by_key("43:bayamo"))
check("REAL_LILY_REVERSE_INDEX",145237 in get_group_by_key("43:lilyisize"),get_group_by_key("43:lilyisize"))
mios=get_group_by_key("150:mios")
check("MIOS_COLLISION_PRESERVES_ALL_GROUPS",set(mios)=={70691,145216},mios)
check("INDEX_IS_CATALOG_DERIVED",len(idx["source_models"])>2000 and len(idx["reverse_models"])>1000,
      {"groups":len(idx["source_models"]),"keys":len(idx["reverse_models"])})
check("NO_MANUAL_FIELDS_IN_SOURCE_SNAPSHOT",
      not any("field_similar" in r or "field_accessories" in r for r in rows.values()))
check("SUPPORTED_ACCESSORY_SOURCE_TYPES",
      set(v.ACCESSORY_SOURCE_TYPES)=={"kol","kreslo","mebel","transport"})

# Real new public NIDs in the newest snapshot: UA/RU function head conflict
# and commercial ineligibility must prevent recommendation output.
base_ru=rows[145445]; base_ua=rows[145446]
new_evt=v.plan_single_event(None,base_ru,idx,rows)
check("REAL_NEW_CYBEX_BASE_UNAVAILABLE",
      not v.basic_available(base_ru) and not v.basic_available(base_ua),
      {"ru_status":base_ru["field_status"],"ru_price":base_ru["price"],
       "ua_status":base_ua["field_status"],"ua_price":base_ua["price"]})
check("REAL_NEW_CYBEX_TRANSLATION_HEAD_MISMATCH_HELD",
      idx["invalid_translation_groups"].get("145445")=="function_head_mismatch",
      idx["invalid_translation_groups"].get("145445"))
check("REAL_NEW_CYBEX_EVENT_IS_INCREMENTAL",
      new_evt["event"]=="new_published" and new_evt["full_catalog_rescore"] is False,
      {"event":new_evt["event"],"affected":len(new_evt["affected_source_nids"])})

# New accessory event based on a real public Noble adapter record, cloned only
# in memory with a new test NID and explicit test evidence phrase.
source=rows[144885]
target=copy.deepcopy(rows[144887])
target.update(nid=99000001,tnid=99000001,lang="uk",
              title="Espiro адаптер для коляски Noble",
              body="Адаптер сумісний з коляскою Espiro Noble. Тестовий опис.",
              published=1,field_status=1,price=1200.0,
              translation_ambiguous=False)
hits=v.lookup_accessory_sources(target,idx,rows)
check("NEW_ACCESSORY_DYNAMIC_SOURCE_RESOLUTION",
      any(h["source_nid"]==144885 and h["source_tnid"]==144884 for h in hits),hits[:5])
evt=v.plan_single_event(None,target,idx,rows)
check("NEW_ACCESSORY_REFRESHES_MATCHING_UA_SOURCE",
      144885 in evt["affected_source_nids"] and 138892 not in evt["affected_source_nids"],
      {"affected_count":evt["affected_source_count"],"has_noble":144885 in evt["affected_source_nids"]})
check("NEW_ACCESSORY_EVENT_DOES_NOT_RESCAN_FULL_CATALOG",
      evt["full_catalog_rescore"] is False)

ru_target=copy.deepcopy(target)
ru_target.update(nid=99000002,tnid=99000002,lang="ru",
                 title="Espiro адаптер для коляски Noble",
                 body="Адаптер совместим с коляской Espiro Noble.")
ru_hits=v.lookup_accessory_sources(ru_target,idx,rows)
check("UA_RU_ACCESSORY_EVENTS_RESOLVE_SEPARATELY",
      any(h["source_nid"]==144885 for h in hits) and
      any(h["source_nid"]==rows[144885]["tnid"] or h["language"]=="ru" for h in ru_hits),
      {"ua":[h["source_nid"] for h in hits],"ru":[h["source_nid"] for h in ru_hits]})

# Exact version guard: event may invalidate a source, but no relation is approved.
noble=extract(source["title"],source["brand"])
pro=copy.deepcopy(target);pro["title"]="Espiro адаптер для коляски Noble Pro"
decision,_=exact_mention(pro["title"],noble.model)
check("NOBLE_PRO_NOT_APPROVED_AS_NOBLE",decision=="version_review",decision)
noble2=copy.deepcopy(target);noble2["title"]="Espiro адаптер для коляски Noble 2"
decision2,_=exact_mention(noble2["title"],noble.model)
check("NOBLE_2_NOT_APPROVED_AS_NOBLE",decision2=="version_review",decision2)
check("NOBLEPRO_NO_SUBSTRING_MATCH",
      exact_mention("Espiro adapter NoblePro",noble.model)[0]=="absent")
check("DAY5_DAY6_GENERATION_GUARD",exact_mention("Joolz адаптер Day 6","Day5")[0]=="absent")
check("DAYPLUS_NOT_COLLAPSED_TO_DAY",exact_mention("Joolz аксессуар Day+","Day")[0]=="version_review")

# Availability gates block display, while the event still invalidates its sources.
inactive=copy.deepcopy(target);inactive.update(field_status=3,price=0.0)
check("UNAVAILABLE_TARGET_BLOCKED_BY_V31_GATE",
      candidate_for(source,inactive,noble,role_is_accessory=True)=="blocked_availability",
      candidate_for(source,inactive,noble,role_is_accessory=True))
check("WRONG_BRAND_BLOCKED",
      candidate_for(source,{**target,"brand_tid":99999},noble,role_is_accessory=True)=="blocked_brand")
check("WRONG_LANGUAGE_BLOCKED",
      candidate_for(source,{**target,"lang":"ru"},noble,role_is_accessory=True)=="blocked_language_or_self")
check("KIT_BLOCKED",
      candidate_for(source,{**target,"type":"product_kit"},noble,role_is_accessory=True)=="blocked_kit_or_translation")
check("MAIN_PRODUCT_NOT_ACCESSORY_BLOCKED",
      candidate_for(source,target,noble,role_is_accessory=False)=="blocked_non_accessory")

# Price/status-only and delete/unpublish events use reverse links without
# semantic reindexing; edits that remove a phrase use old text to find sources.
reverse={str(target["nid"]):[144885]}
inactive_evt=v.plan_single_event(target,inactive,idx,rows,reverse)
check("PRICE_STATUS_EVENT_IS_COMMERCIAL_ONLY",
      v.event_type(target,inactive)=="commercial_projection_changed" and
      144885 in inactive_evt["affected_source_nids"])
deleted_evt=v.plan_single_event(target,None,idx,rows,reverse)
check("REMOVED_TARGET_INVALIDATES_REVERSE_DEPENDENCY",
      deleted_evt["event"]=="removed" and 144885 in deleted_evt["affected_source_nids"])
no_op=v.plan_single_event(target,copy.deepcopy(target),idx,rows,reverse)
check("NOOP_IMPORT_IS_NOOP",
      no_op["event"]=="metadata_only" and no_op["affected_source_nids"]==[])
negative=copy.deepcopy(target);negative["body"]="Не сумісний з коляскою Noble."
negative_evt=v.plan_single_event(target,negative,idx,rows,reverse)
check("REMOVED_COMPATIBILITY_PHRASE_STILL_REFRESHES_SOURCE",
      144885 in negative_evt["affected_source_nids"] and
      negative_evt["event"]=="semantic_content_changed")

# New main product identity is derived from its two-language facts, no NID alias.
from v32_pipeline import identity_group
ua=copy.deepcopy(source);ru=copy.deepcopy(rows[144884])
for r,nid,lang,title in ((ua,99001001,"uk","Espiro коляска Nova 77"),
                         (ru,99001002,"ru","Espiro коляска Nova 77")):
    r.update(nid=nid,tnid=99001000,lang=lang,title=title,field_status=1,price=1000.0,published=1)
status,reason,mkey,models,istatus,locales=identity_group(99001000,[ua,ru])
check("NEW_BILINGUAL_SOURCE_DERIVED_WITHOUT_NID_ALIAS",
      status=="indexed" and mkey==extract(ua["title"],ua["brand"]).key,
      {"status":status,"reason":reason,"key":mkey})
# A missing translation waits safely and is picked up when the second locale arrives.
status_single,*_=identity_group(99001000,[ua])
check("NEW_SINGLE_LANGUAGE_WAITS_FOR_TRANSLATION",
      status_single=="waiting_for_translation",status_single)

# Event timings use prebuilt persistent indices; no corpus scoring loop.
start=time.perf_counter()
for _ in range(100):
    v.plan_single_event(None,target,idx,rows)
event_100_ms=(time.perf_counter()-start)*1000
report={
 "schema":"babypark-v3.2-incremental-event-tests-v1",
 "status":"PASS" if not failed else "FAIL",
 "passed":len(passed),"failed":len(failed),"cases":passed+failed,
 "event_plan_100_iterations_ms":round(event_100_ms,3),
 "event_plan_mean_ms":round(event_100_ms/100,4),
 "peak_rss_kib":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
 "note":"All synthetic NIDs exist only in memory. Tests exercise dynamic lookup and event planning, not a 1C import or Drupal write.",
 "known_unverified":"Selected OID/kit purchasability and native Drupal page-cache freshness are not asserted by these tests."
}
out=BASE/"evidence/incremental_event_tests_v32.json"
out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8");out.chmod(0o600)
print(json.dumps({"status":report["status"],"passed":report["passed"],"failed":report["failed"],
                  "event_plan_mean_ms":report["event_plan_mean_ms"],"failures":failed,
                  "output":str(out)},ensure_ascii=False,indent=2))
if failed: raise SystemExit(1)
