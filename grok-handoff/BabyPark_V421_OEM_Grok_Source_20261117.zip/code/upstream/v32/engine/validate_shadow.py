#!/usr/bin/env python3
"""Cross-check offline candidate artifacts against fresh Drupal metadata.

Independent of ranking score calculations and manual relation fields.
This validates safety invariants, *not* human semantic relevance or fitment.
"""
import collections
import csv
import gzip
import json
import math
import re
from pathlib import Path

ROOT=Path("/opt/bp-recommendations-full-catalog-20261109")
rows={}
for line in gzip.open(ROOT/"current_catalog_records.jsonl.gz","rt",encoding="utf-8"):
    r=json.loads(line)
    assert r["nid"] not in rows
    rows[r["nid"]]=r
assert len(rows)==28011

def load(filename,kind,cap=20):
    if not (ROOT/filename).is_file():
        return {"kind":kind,"present":False},{}
    bysource=collections.defaultdict(list)
    stats=collections.Counter()
    distinctpairs=set()
    with gzip.open(ROOT/filename,"rt",encoding="utf-8",newline="") as f:
        for x in csv.DictReader(f,delimiter="\t"):
            sid=int(x["source_nid"]);cid=int(x["candidate_nid"])
            source=rows[sid];cand=rows[cid]
            assert not source.get("translation_ambiguous") and not cand.get("translation_ambiguous"),("ambiguous",sid,cid)
            assert source["tnid"]>0 and cand["tnid"]>0
            lang=x["language"]
            assert source["lang"]==lang==cand["lang"],("lang",sid,cid)
            assert source["tnid"]!=cand["tnid"],("self",sid,cid)
            assert cand["field_status"]==1 and cand["price"]>0 and cand["published"]==1
            assert source["type"]!="product_kit" and cand["type"]!="product_kit"
            assert x["candidate_tnid"]==str(cand["tnid"])
            assert x["source_tnid"]==str(source["tnid"])
            if kind=="similar":
                assert source["type"]==cand["type"]
                score=float(x["score"]);similarity=float(x["tfidf_cosine"])
                assert 0.0<score<=1.000001
                assert similarity>=.07499,(sid,cid,similarity)
                assert x["shared_category_ids"],(sid,cid)
            else:
                assert x["evidence_span"].strip()
                assert x["source_model"].strip()
                assert x["evidence_confidence"]=="high_text_evidence_unverified_manufacturer"
            key=(sid,lang);pair=(key,kind,cand["tnid"])
            assert pair not in distinctpairs,("duplicate",pair)
            distinctpairs.add(pair)
            bysource[key].append((int(x["rank"]),cid))
            stats["rows"]+=1
            stats["rows_"+lang]+=1
    for key,vals in bysource.items():
        ranks=sorted(v[0] for v in vals)
        assert ranks==list(range(1,len(vals)+1)),("rank",key)
        assert len(vals)<=cap,("cap",key)
    stats["source_locale_blocks"]=len(bysource)
    stats["source_physical_groups"]=len({rows[key[0]]["tnid"] for key in bysource})
    return {"kind":kind,"present":True,**dict(stats)}, bysource

def main():
    sim,simblocks=load("current_full_similar_preliminary.tsv.gz","similar")
    acc,accblocks=load("current_full_accessories_preliminary.tsv.gz","accessory")
    overlap=0
    for key,s in simblocks.items():
        present={x[1] for x in s}
        overlap+=sum(1 for rank,nid in accblocks.get(key,()) if nid in present)
    assert overlap==0,("cross block overlap",overlap)
    report={
        "status":"REHEARSAL_INVARIANT_VALIDATION_NOT_SEMANTIC_APPROVAL",
        "source_nids":len(rows),
        "similar":sim,"accessories":acc,
        "cross_block_overlap":overlap,
        "limitations":[
            "Rechecks static export availability, not live node status after export",
            "No selected OID/kit purchasability check in corpus",
            "Does not prove recommendation relevance or physical accessory compatibility",
            "No native Drupal rendered page, anonymous cache or first-publication event tested"
        ],
    }
    (ROOT/"CURRENT_RECOMMENDATIONS_INVARIANTS.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf8")
    print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=="__main__":main()
