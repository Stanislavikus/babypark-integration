#!/usr/bin/env python3
"""V3.2 scoped similarity reranker using a frozen, catalog-wide TF-IDF index.

Initial full ranking is done once. This module scores only explicitly supplied
source NIDs and uses cached vectors plus persisted function/category buckets.
"""
import ast,collections,csv,gzip,json,math,os,re,resource,sys,time
from pathlib import Path
BASE=Path("/opt/bp-recommendations-full-rollout-rehearsal-20261111/v3.2")
ENGINE=BASE/"engine"; SHADOW=BASE/"shadow"; INDEX=BASE/"index"
sys.path.insert(0,str(ENGINE))
from v3_rules import similar_compatibility,accessory_class,norm
import v32_pipeline as pipe
TOKEN_RE=re.compile(r"[a-zа-яёіїєґ0-9]+",re.I)

def load_rows(path=BASE/"input/current_catalog_records.jsonl.gz"):
    return pipe.read_catalog(path)

def load_static():
    src=(ENGINE/"run_v3_final.py").read_text(encoding="utf-8")
    tree=ast.parse(src);cats=None;stop=None
    for n in tree.body:
        if not isinstance(n,ast.Assign):continue
        targets={t.id for t in n.targets if isinstance(t,ast.Name)}
        if "CLASS_CATS" in targets: cats=ast.literal_eval(n.value)
        if "STOP" in targets:
            expr=ast.get_source_segment(src,n.value)
            m=re.fullmatch(r'set\("""(.*?)"""\.split\(\)\)',expr,re.S)
            if m:stop=set(m.group(1).split())
    if not cats or not stop:raise RuntimeError("V3 class or stop words unavailable")
    return cats,stop

def load_frozen():
    idf=json.loads((SHADOW/"frozen_idf_v32.json").read_text(encoding="utf-8"))
    vectors={}
    with gzip.open(SHADOW/"frozen_vector_index_v32.jsonl.gz","rt",encoding="utf-8") as f:
        for line in f:
            x=json.loads(line);vectors[int(x["nid"])]=x["vector"]
    return idf,vectors

def token_counts(row,stop):
    text=(str(row.get("title") or "")+" "+str(row.get("body") or "")).lower()
    return collections.Counter(w for w in TOKEN_RE.findall(norm(text)) if len(w)>1 and w not in stop)

def vector_for(row,idf,stop):
    lang=row["lang"]
    counts=token_counts(row,stop)
    raw={k:(1+math.log(v))*idf.get(lang,{}).get(k,0.0) for k,v in counts.items()}
    n=math.sqrt(sum(v*v for v in raw.values())) or 1.0
    return {k:v/n for k,v in raw.items()}

def cosine(a,b):
    return sum(w*b.get(token,0.0) for token,w in a.items())

def cat_ids(row,class_cats):
    return {p.split(":",1)[0] for p in (row.get("cats") or "").split("|") if ":" in p}&class_cats.get(row.get("type"),set())

def scope_rank(source_nids,rows,vectors,idf,extra_target_nids=(),bucket=None):
    class_cats,stop=load_static()
    if bucket is None:
        bucket=json.loads((INDEX/"similar_bucket_index_v32.json").read_text(encoding="utf-8"))
    similar_excluded=set(json.loads((INDEX/"similar_group_exclusions_v32.json").read_text(encoding="utf-8")))
    bynid=rows
    added=set(int(x) for x in extra_target_nids)
    result={}
    candidate_pair_count=0
    for sid in sorted(set(map(int,source_nids))):
        src=bynid.get(sid)
        if not src:raise KeyError("source NID missing "+str(sid))
        cats=cat_ids(src,class_cats)
        if src["type"]=="product_kit" or src.get("translation_ambiguous") or not cats:
            result[sid]=[];continue
        if (src.get("function_signature") or {}).get("role")=="component" or not (src.get("function_signature") or {}).get("head"):
            result[sid]=[];continue
        if accessory_class(src.get("title",""),"",cats):
            result[sid]=[];continue
        keys=[f"{src['lang']}|{src['type']}|{cat}|{src['function_signature']['head']}" for cat in cats]
        target_ids=set()
        for key in keys:target_ids.update(bucket.get(key,{}).get("targets",[]))
        target_ids.update(added)
        target_ids.discard(sid)
        target_ids={tid for tid in target_ids if tid in bynid and int(bynid[tid]["tnid"])!=int(src["tnid"])}
        # Extra event targets must satisfy the same group and availability rules.
        valid=[]
        for tid in target_ids:
            t=bynid[tid]
            if t.get("type")!=src.get("type") or t.get("type")=="product_kit":continue
            if t.get("lang")!=src.get("lang") or int(t["tnid"]) in similar_excluded:continue
            if t.get("translation_ambiguous") or not pipe.basic_available(t):continue
            if not t.get("eligible_as_similar_target_preliminary"):continue
            if not (cats & cat_ids(t,class_cats)):continue
            if (t.get("function_signature") or {}).get("head")!=(src.get("function_signature") or {}).get("head"):continue
            if accessory_class(t.get("title",""),"",cat_ids(t,class_cats)):continue
            valid.append(tid)
        source_vec=vectors.get(sid)
        if source_vec is None:source_vec=vector_for(src,idf,stop)
        suggestions=[]
        candidate_pair_count+=len(valid)
        for cid in valid:
            cand=bynid[cid]
            target_vec=vectors.get(cid)
            if target_vec is None:target_vec=vector_for(cand,idf,stop)
            sim=cosine(source_vec,target_vec)
            if sim<.075:continue
            ok,reason,_,_=similar_compatibility(src,cand)
            if not ok:continue
            p1=float(src.get("price") or 0);p2=float(cand.get("price") or 0)
            psim=1/(1+abs(math.log(max(p1,1)/max(p2,1)))) if p1>0 and p2>0 else 0
            score=.90*sim+.10*psim
            shared=sorted(cats&cat_ids(cand,class_cats))
            suggestions.append((score,sim,psim,cid,shared))
        suggestions.sort(key=lambda x:(x[0],x[1],x[2],-x[3]),reverse=True)
        result[sid]=[{"candidate_nid":c,"rank":i,"score":round(sc,5),"cosine":round(co,5),
                      "price_similarity":round(ps,5),"shared_category_ids":shared}
                     for i,(sc,co,ps,c,shared) in enumerate(suggestions[:20],1)]
    return {"sources":result,"candidate_pairs_scored":candidate_pair_count,
            "source_count":len(result),"full_corpus_pair_rescore":False}

def main():
    import argparse
    ap=argparse.ArgumentParser()
    ap.add_argument("--source-nids",required=True)
    args=ap.parse_args()
    start=time.perf_counter()
    rows=load_rows();load_rows_s=time.perf_counter()-start
    start=time.perf_counter();idf,vectors=load_frozen();index_load_s=time.perf_counter()-start
    ids=[int(x) for x in args.source_nids.split(",") if x]
    start=time.perf_counter();out=scope_rank(ids,rows,vectors,idf);rank_s=time.perf_counter()-start
    output={"schema":"babypark-v3.2-scoped-similar-rerank-v1","status":"REHEARSAL_ONLY",
            "load_catalog_seconds":round(load_rows_s,4),"load_frozen_vectors_seconds":round(index_load_s,4),
            "scoped_rank_seconds":round(rank_s,4),"peak_rss_kib":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            **out}
    path=BASE/"evidence/scoped_rerank_latest_v32.json"
    path.write_text(json.dumps(output,ensure_ascii=False,indent=2)+"\n",encoding="utf-8");path.chmod(0o600)
    print(json.dumps({"source_count":out["source_count"],"candidate_pairs_scored":out["candidate_pairs_scored"],
                      "full_corpus_pair_rescore":False,"load_catalog_seconds":output["load_catalog_seconds"],
                      "load_frozen_vectors_seconds":output["load_frozen_vectors_seconds"],
                      "scoped_rank_seconds":output["scoped_rank_seconds"],"peak_rss_kib":output["peak_rss_kib"],
                      "output":str(path)},ensure_ascii=False,indent=2))
if __name__=="__main__":main()
