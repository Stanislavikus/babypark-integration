#!/usr/bin/env python3
"""BabyPark V3.1 canonical bilingual model identity, offline/read-only helpers.

No per-NID overrides, no manual recommendation fields, no output side effects.
This is a candidate-retrieval identity only, never manufacturer fitment proof.
"""
from __future__ import annotations
import html
import re
import unicodedata
from dataclasses import dataclass

TOKEN = re.compile(r"[a-zа-яёіїєґ0-9]+(?:[-+][a-zа-яёіїєґ0-9]+)*\+?", re.I)
ROLE_PREFIX = set("""
прогулянкова прогулочная універсальна универсальная ексклюзивна эксклюзивная детская дитяча детский
коляска коляски колска коляску візок візка візка тростина трость двійнят двойнят stroller buggy pram
автокресло автокресла автокрісло автокрісла кресло крісло бустер booster
для двойни двійні двойная подвійна детское дитяче автомобильное автомобільне
дитячий детский детская з комплектом набор комплект
""".split())
# Removing Plus/Pro/Style/Lux would destroy model version identity. Never do it.
COLOR_TAIL = set("black grey gray white beige pink blue red green graphite sand".split())
TAIL_RE = re.compile(
    r"\s+(?:[зс]\s+(?:сумкою|сумкой|люлькою|люлькой|чохлом|чехлом|бампером)"
    r"|with\s+(?:bag|carrycot))\b.*$", re.I)
PACK_RE = re.compile(r"(?<!\w)[2-4]\s*(?:в|in)\s*[1-3](?!\w)", re.I)
SUFFIX = re.compile(r"^\s*(?:[/+\-]\s*)?(?P<s>pro\b|plus\b|lux\b|style\b|"
                    r"gen\s*\d+\b|generation\s*\d+\b|g\d+\b|"
                    r"\d+(?:\.\d+)?\b|i[-\s]?size\b|coya\b)",re.I)


def normal(text: str) -> str:
    s = unicodedata.normalize("NFKC", html.unescape(str(text or "")))
    s = re.sub("[\u00ad\u200b\u200e\ufeff]+", "", s)
    return re.sub(r"\s+", " ", s).strip()


def key(text: str) -> str:
    s = normal(text).casefold()
    s = re.sub(r"(?<=[a-zа-яёіїєґ0-9])\+(?![a-zа-яёіїєґ0-9])", "plus", s)
    return re.sub(r"[^a-zа-яёіїєґ0-9]+", "", s)


@dataclass(frozen=True)
class Identity:
    model: str
    key: str
    status: str
    reason: str
    brand: str


def role_word(part: str) -> bool:
    pieces = part.casefold().split("-")
    return bool(pieces) and all(p in ROLE_PREFIX for p in pieces)


def extract(title: str, brand: str) -> Identity:
    t = re.sub(r"\s*-?\d{1,2}%\s*$", "", normal(title).lstrip("#").strip())
    b = normal(brand).split("(")[0].strip()
    # Strip the *given* manufacturer from prefix only, not from model text.
    brand_parts = TOKEN.findall(b)
    brand_pattern = r"^" + r"[\s-]*".join(map(re.escape, brand_parts)) + r"(?=\W|$)" if brand_parts else ""
    brand_match = re.match(brand_pattern, t, re.I) if brand_pattern else None
    if brand_match:
        t = t[brand_match.end():].strip()
    t = PACK_RE.sub(" ", t)
    t = TAIL_RE.sub("", t)
    parts = TOKEN.findall(t)
    while parts and role_word(parts[0]):
        parts.pop(0)
    while parts and parts[-1].casefold() in COLOR_TAIL:
        parts.pop()
    # A descriptor may be between the brand and the actual model,
    # e.g. 'Maxi-Cosi автокрісло Pebble 360 Pro 2': preserve OEM prefix.
    parts = [p for p in parts if not role_word(p)]
    model = " ".join(parts).strip()
    k = key(model)
    if not k:
        return Identity("", "", "review", "empty_after_cleaning", b)
    if len(k) < 4:
        return Identity(model, k, "review", "short_or_ambiguous_model", b)
    # Product title mentions a second physical manufacturer: cannot certify
    # origin or part fit from the Drupal brand alone.
    if len(parts) > 1 and parts[0].casefold() in ("maxi-cosi", "cybex", "joolz") and parts[0].casefold() != b.casefold():
        return Identity(model, k, "review", "mixed_manufacturer_title", b)
    return Identity(model, k, "indexed", "candidate_identity_only", b)


def _aliases(model: str):
    base = normal(model)
    forms = {base}
    forms.add(re.sub(r"(?<=[A-Za-z])(?=\d)", " ", base))
    forms.add(re.sub(r"(?<=[A-Za-z])\s+(?=\d)", "", base))
    return {f for f in forms if f}


def exact_mention(text: str, model: str) -> tuple[str, str]:
    """Result: candidate / version_review / absent; no publication assertion."""
    body = normal(text)
    for alias in sorted(_aliases(model), key=len, reverse=True):
        toks = TOKEN.findall(alias)
        if not toks:
            continue
        # Do not let a model word match a longer model (NoblePro / Noble2).
        pattern = r"(?<![a-zа-яёіїєґ0-9])" + r"[\s/-]*".join(map(re.escape, toks)) + r"(?![a-zа-яёіїєґ0-9])"
        for match in re.finditer(pattern, body, re.I):
            tail = body[match.end():]
            if re.match(r"^\s*\+(?![a-zа-яёіїєґ0-9])", tail, re.I):
                return ("version_review", tail[:45].strip())
            if SUFFIX.match(tail):
                return ("version_review", tail[:45].strip())
            # A slash joined to a second model also needs human review,
            # regardless of its word being in our version suffix list.
            if re.match(r"^\s*[/+]\s*[a-zа-яёіїєґ0-9]", tail, re.I):
                return ("version_review", tail[:45].strip())
            return ("candidate", "title_match_only_not_fitment_certification")
    return ("absent", "no_exact_full_model_span")


def candidate_for(source: dict, target: dict, identity: Identity, *, role_is_accessory: bool):
    if not role_is_accessory:
        return "blocked_non_accessory"
    if source["lang"] != target["lang"] or source["tnid"] == target["tnid"]:
        return "blocked_language_or_self"
    if source["brand_tid"] != target["brand_tid"]:
        return "blocked_brand"
    if identity.status != "indexed":
        return "review_ambiguous_source"
    if not target["published"] or target["field_status"] != 1 or target["price"] <= 0:
        return "blocked_availability"
    if target["type"] == "product_kit" or target["translation_ambiguous"]:
        return "blocked_kit_or_translation"
    verdict, _ = exact_mention(target["title"], identity.model)
    return verdict
