# Checkpoint — car-seat correction 2026-11-17

Status: COMPLETE — rehearsal-only correction and full recalculation verified; no deployment or owner GO.

## Scope and safety

- Campaign: /opt/bp-v421-v36-full-category-decision-20261115/car_seat_correction_20261117/
- Production was read-only; no writes, deployment, publication, manual-field edit, or V3.6 Similar change.
- Original T2 and Fix1 outputs remain unchanged.
- Full frozen cohort: 8,129 source cards. Fresh calculation catalog: 28,769 records.
- Capture SHA-256: 30829f6bcc903b66dc26a6ace53fefbc41d3a50916dfdf8b29d42aaf5951a3e4.

## Corrected result

- Old eligible car-seat domain: 334 localized source rows.
- Primary denominator: 324 rows — 318 main seats, 4 full boosters, 2 real-seat bundles.
- Excluded from primary metric: 8 standalone Isofix bases and 2 standalone liners/accessories.
- Corrected car-seat links: 42 A_model, 0 B_functional; 282 primary rows have no proven A/B.
- C vehicle-general diagnostics: 6 localized rows, 3 physical SKUs; excluded from A/B.
- New vs T2-original: two localized Pearl Slide Pro summer-cover A rows (one physical accessory SKU); Stage1, VID, OID rows, digest, locale, and purchase-state gates passed.
- Manual display review: all 1,978 unique pairs classified; manual fallback not used.
- Strollers: exactly 1,832 unchanged pairs across original/Fix1/corrected.
- V3.6 Similar: identical for all 8,129 sources.

## Verification

- 35/35 Python unit/regression tests passed, 14.215 seconds.
- Full report and requested CSV deliverables generated in this directory.
- No A/B recommendation was published. Full GO remains NO-GO because 282/324 primary localized seat cards have no evidence-backed A/B.
- Read-only production handbook calls were attempted for mandatory context; AGENTS.md was read. Other reads remained pending at Desktop Commander, but no production write or runtime action depended on them.

## Required deliverables

- CORRECTION_REPORT.md
- SOURCE_CLASSIFICATION.csv
- T2_THREE_WAY_COMPARISON.csv
- MANUAL_CANDIDATE_REVIEW.csv
- NEW_A_B_RECOMMENDATIONS.csv
- C_VEHICLE_GENERAL.csv
- REJECTION_REASONS.csv
- REGRESSION_RESULTS.md
- CHECKPOINT.md
- SHA256SUMS.txt
