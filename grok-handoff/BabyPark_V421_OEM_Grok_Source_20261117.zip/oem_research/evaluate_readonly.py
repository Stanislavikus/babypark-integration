#!/usr/bin/env python3
"""Read-only shadow evaluation for OEM compatibility rules. Does not import or edit V4.2.1."""
import csv, gzip, hashlib, json, re, unicodedata
from collections import Counter
from pathlib import Path

BASE = Path("/opt/bp-v421-v36-full-category-decision-20261115")
TRAIN = BASE / "oem_reference_training_20261117"
SNAP = BASE / "car_seat_correction_20261117"
CATALOG = SNAP / "input/fresh_current_catalog_records.jsonl.gz"
SOURCES = SNAP / "input/fresh_v36_scope_sources.json"
MANIFEST = SNAP / "output/t2_v421_manifest.json"
STAGE1 = SNAP / "input/stage1_targets_result.json"
INPUT_MANIFEST = TRAIN / "SHA256SUMS.txt"

def read_csv(name):
    with (TRAIN / name).open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

expected_hashes = {}
for line in INPUT_MANIFEST.read_text(encoding="utf-8").splitlines():
    h, name = line.strip().split(maxsplit=1)
    expected_hashes[name.strip()] = h
for name, expected in expected_hashes.items():
    actual = sha(TRAIN / name)
    if actual != expected:
        raise SystemExit(f"Input checksum mismatch: {name} {actual} != {expected}")

seed = read_csv("OEM_VERIFIED_MISSED_PAIRS.csv")
features = read_csv("FEATURE_RULE_GROUPS.csv")
clusters = read_csv("UNVERIFIED_MANUAL_FEATURE_CLUSTERS.csv")
controls = read_csv("NEGATIVE_AND_CONDITIONAL_CONTROLS.csv")
physical_seed = {(r["group_id"], r["source_tnid"], r["source_sku"], r["target_tnid"], r["target_sku_oem_base"]) for r in seed}
if (len(seed), len(physical_seed), len(features), len(clusters), len(controls)) != (26, 13, 4, 110, 8):
    raise SystemExit("Training CSV row-count mismatch")

with gzip.open(CATALOG, "rt", encoding="utf-8") as f:
    catalog_rows = [json.loads(line) for line in f]
catalog = {str(r["nid"]): r for r in catalog_rows}
by_sku = {}
by_tnid = {}
for r in catalog_rows:
    by_sku.setdefault(str(r.get("sku", "")), []).append(r)
    by_tnid.setdefault(str(r.get("tnid", "")), []).append(r)

sources = json.loads(SOURCES.read_text(encoding="utf-8"))
current = json.loads(MANIFEST.read_text(encoding="utf-8"))["sources"]
stage1_result = json.loads(STAGE1.read_text(encoding="utf-8"))
if (len(catalog_rows), len(sources), len(current)) != (28769, 8129, 8129):
    raise SystemExit("Frozen cohort/catalog count mismatch")
if not all(sources[k]["similar"] == current[k]["similar"] for k in sources):
    raise SystemExit("V3.6 Similar lists differ in the read-only comparison")

def lang_rows(tnid):
    return sorted(by_tnid.get(str(tnid), []), key=lambda r: (r.get("lang", ""), int(r.get("nid", 0))))

def find_ru_sku(sku):
    candidates = [r for r in by_sku.get(str(sku), []) if r.get("lang") == "ru"]
    if not candidates:
        return None
    return sorted(candidates, key=lambda r: int(r["nid"]))[0]

def chassis(ids):
    vals = []
    for nid in ids:
        r = catalog.get(str(nid))
        if r:
            vals.append(f'{r["nid"]}/{r.get("tnid")}/{r.get("sku")}/{r.get("title")}/field_status={r.get("field_status")}')
    return " | ".join(vals)

BUGABOO_DRAGONFLY = "https://www.bugaboo.com/gb-en/outlet/bugaboo-dragonfly-car-seat-adapters-400003001.html"
BUGABOO_FOX = "https://www.bugaboo.com/gb-en/accessories/adapters/bugaboo-fox-kangaroo-car-seat-adapters-black-400019001.html"
BRITAX_COMFORT = "https://www.britax-roemer.com/accessories/car-seat-accessories/comfort-insert/2000030111.html"
BRITAX_RELAX = "https://www.britax-roemer.com/accessories/car-seat-accessories/relax-insert/ACCSFCC207.html"
BESAFE_MANUAL = "https://www.besafe.com/4a4457/globalassets/inriverimages/commerce-besafe/2019_01_10_instruction_manual_rain_shield_-_web-manual-601.pdf"
MAXI_ADAPTER = "https://www.maxi-cosi.co.uk/pushchairs/coral-slide-pro-carrier-adapter"

# These are benchmark probes, not runtime exceptions. Predictions use only the OEM
# product allow-list + frame scope stated in evidence URLs; no identifiers are added to V4.2.1.
probes = [
    dict(case_id="H01_PEBBLE_PRO_DRAGONFLY", split="independent_physical_model_and_accessory_sku", rule="OEM allow-list + exact 3-node interface", source_nid="137405", target_sku="400003001", chassis="Dragonfly / Dragonfly Plus", chassis_nids="138649,139191,144964,144965", expected="OEM_EXPLICIT_POSITIVE", shadow="CONDITIONAL_MATCH", evidence=BUGABOO_DRAGONFLY, note="Pebble 360 Pro appears in adapter list; catalog target and source exist, but both have field_status=3."),
    dict(case_id="H02_PEBBLE_PRO2_FOX5", split="independent_physical_model_and_accessory_sku", rule="OEM allow-list + exact 3-node interface", source_nid="139524", target_sku="400019001", chassis="Fox 5 / Fox 5 Renew", chassis_nids="137809,137937,137810,137939,144137,144138", expected="OEM_EXPLICIT_POSITIVE", shadow="CONDITIONAL_MATCH", evidence=BUGABOO_FOX, note="Pebble 360 Pro 2 appears in Fox 5 list; source and adapter field_status=1; frame products are not currently purchasable in snapshot; pair Stage1 was not run."),
    dict(case_id="H03_BESAFE_X1_FOX5_SKU_HOLDOUT", split="accessory_sku_holdout_same_source_model_as_seed", rule="OEM allow-list + punctuation-only model normalization", source_nid="133428", target_sku="400019001", chassis="Fox 5 / Fox 5 Renew", chassis_nids="137809,137937,137810,137939,144137,144138", expected="OEM_EXPLICIT_POSITIVE", shadow="CONDITIONAL_MATCH", evidence=BUGABOO_FOX, note="New physical adapter SKU; source model repeats P02 and is excluded from the independent-model score."),
    dict(case_id="H04_CORAL_SLIDE_PRO_FOX5_SKU_HOLDOUT", split="accessory_sku_holdout_same_source_model_as_seed", rule="OEM allow-list + exact 3-node interface", source_nid="144473", target_sku="400019001", chassis="Fox 5 / Fox 5 Renew", chassis_nids="137809,137937,137810,137939,144137,144138", expected="OEM_EXPLICIT_POSITIVE", shadow="CONDITIONAL_MATCH", evidence=BUGABOO_FOX, note="New physical adapter SKU and frame; source model repeats P03 and is excluded from the independent-model score."),
    dict(case_id="N01_PEBBLE_PRO2_DRAGONFLY", split="generation_boundary", rule="exact OEM list; retain Pro vs Pro 2", source_nid="139524", target_sku="400003001", chassis="Dragonfly / Dragonfly Plus", chassis_nids="138649,139191,144964,144965", expected="NOT_LISTED_UNTESTED", shadow="ABSTAIN_NO_RECOMMENDATION", evidence=BUGABOO_DRAGONFLY, note="Dragonfly list names Pebble 360 Pro but not Pro 2; omission means no inference, not a claim of physical incompatibility."),
    dict(case_id="N02_PEBBLE_PRO2_FOX2", split="chassis_generation_boundary", rule="exact chassis-specific allow-list", source_nid="139524", target_sku="400019001", chassis="Fox 2", chassis_nids="132184,133095", expected="NOT_LISTED_FOR_THIS_CHASSIS", shadow="ABSTAIN_NO_RECOMMENDATION", evidence=BUGABOO_FOX, note="Fox 5 list includes Pro 2; Fox 2 list does not. Chassis version must remain a separate interface."),
    dict(case_id="N03_CABRIOFIX_DRAGONFLY", split="explicit_negative_control", rule="OEM explicit no recommendation", source_nid="14139", target_sku="400003001", chassis="Dragonfly / Dragonfly Plus", chassis_nids="138649,139191,144964,144965", expected="OEM_SAYS_NOT_COMPATIBLE_OR_TESTED", shadow="REJECT", evidence=BUGABOO_DRAGONFLY, note="Bugaboo support states CabrioFix is not listed/tested and is not recommended for Dragonfly."),
    dict(case_id="N04_RELAX_INSERT_IDENTITY", split="identity_gate_abstention", rule="accessory OEM article identity join", source_nid="134912", target_sku="2000040775", chassis="", chassis_nids="", expected="OEM_TARGET_SKU_MAPPING_UNPROVEN", shadow="ABSTAIN_IDENTITY_UNVERIFIED", evidence=BRITAX_RELAX, note="OEM page identifies article ACCSFCC207; catalog row has seller SKU 2000040775 with no audited OEM article mapping. Name similarity is insufficient."),
]

holdout_fields = ["case_id","split","rule","source_model","source_sku","source_tnid","source_nid_ru","source_nid_uk","accessory_sku_catalog","accessory_target_nid_ru","accessory_target_nid_uk","accessory_field_status","accessory_sell_price","accessory_oid_rows","chassis_model","chassis_catalog_rows","expected_oem_state","shadow_output","counterfactual_current_t2","stage1_status","independent_model_and_sku","test_result","oem_evidence_url","oem_accessory_identity_proof","oem_compatible_models_proof","safety_predicates","false_positive_hazard","rejection_reason","human_label","conditions_and_notes"]
probe_review_details = {
    "H01_PEBBLE_PRO_DRAGONFLY":{
        "oem_accessory_identity_proof":"Bugaboo Dragonfly adapter official page: Product Code 400003001; catalogue accessory SKU is 400003001.",
        "oem_compatible_models_proof":"The same OEM page lists Maxi-Cosi Pebble 360 Pro and Dragonfly/Dragonfly Plus as compatible endpoints.",
        "safety_predicates":"Model/adapter/frame fitment only. Consumer must follow both restraint and stroller manuals; this does not certify crash safety or unrestricted in-car use.",
        "false_positive_hazard":"Do not drop Pro/Pro 2 generation token; do not treat adapter compatibility as car-installation approval.",
        "rejection_reason":"OEM relation confirmed, but source/adapter field_status=3 and new-pair Stage1 was not run.",
        "human_label":"По списку Bugaboo подходит для Dragonfly; доступность и конкретную конфигурацию проверьте перед использованием."
    },
    "H02_PEBBLE_PRO2_FOX5":{
        "oem_accessory_identity_proof":"Official Bugaboo Fox 5 Renew adapter page URL carries product identity 400019MI and states its item code 400019001; catalogue SKU is 400019001.",
        "oem_compatible_models_proof":"Fox 5 & 5 Renew allow-list names Maxi-Cosi Pebble 360 Pro 2 i Size and separately names Bugaboo Fox 5/Fox 5 Renew as compatible product frames.",
        "safety_predicates":"This is stroller travel-system fitment only. Follow the car-seat and stroller instructions; no child-specific or in-car safety claim follows from model fitment.",
        "false_positive_hazard":"Do not transfer the Fox 5 list to Fox 2, Fox 3 or other frames without that frame's own allow-list.",
        "rejection_reason":"OEM relation confirmed, but frame products are not purchasable in the frozen snapshot and pair Stage1 was not run.",
        "human_label":"Для Fox 5 / Fox 5 Renew модель указана Bugaboo; нужна проверка точной рамы и доступности."
    },
    "H03_BESAFE_X1_FOX5_SKU_HOLDOUT":{
        "oem_accessory_identity_proof":"Official Fox 5 Renew adapter page identifies the Fox/Kangaroo adapter family and item code 400019001; catalogue SKU is 400019001.",
        "oem_compatible_models_proof":"Fox 5 & 5 Renew list BeSafe iZi Go Modular X1; catalogue title spelling X-1 normalizes only hyphen/spacing while retaining X1.",
        "safety_predicates":"The stroller adapter relation says nothing about the seat's in-car installation; preserve seat manual requirements.",
        "false_positive_hazard":"Do not equate X1 with X2 or use a fuzzy family match.",
        "rejection_reason":"OEM relation confirmed for a new accessory SKU, but source model repeats P02 and is not independent-model validation.",
        "human_label":"Модель X1 указана для адаптера Fox 5; не распространяйте вывод на X2."
    },
    "H04_CORAL_SLIDE_PRO_FOX5_SKU_HOLDOUT":{
        "oem_accessory_identity_proof":"Official Fox 5 Renew adapter page identifies the Fox/Kangaroo adapter family and item code 400019001; catalogue SKU is 400019001.",
        "oem_compatible_models_proof":"Fox 5 & 5 Renew allow-list names Maxi-Cosi Coral Slide Pro and Bugaboo Fox 5/Fox 5 Renew; Maxi-Cosi's own adapter page separately limits SKU 1166057110 to its soft carrier plus Fame/Fame Cabin.",
        "safety_predicates":"Do not transfer the Maxi-Cosi Fame/Fame Cabin 3-node rule to Bugaboo hardware; use only the configuration explicitly named by each adapter's own OEM instructions.",
        "false_positive_hazard":"Same car-seat family does not establish same carrier component or adapter connector across stroller brands.",
        "rejection_reason":"OEM model-list relation observed for a new adapter SKU, but Coral Slide Pro repeats P03 source model and the exact carrying component must be checked in both manuals.",
        "human_label":"Coral Slide Pro указан в списке адаптера Fox 5; проверьте точную часть кресла и инструкции обоих производителей."
    },
    "N01_PEBBLE_PRO2_DRAGONFLY":{
        "oem_accessory_identity_proof":"Official Bugaboo Dragonfly page identifies adapter Product Code 400003001.",
        "oem_compatible_models_proof":"Current product allow-list names Pebble 360 Pro but not Pebble 360 Pro 2; Q&A says Pro 2 had not been tested at time of answer.",
        "safety_predicates":"Absence from list is not proof of physical incompatibility; only a fail-closed recommendation gate.",
        "false_positive_hazard":"Dropping the generation suffix would create a false positive.",
        "rejection_reason":"No current OEM positive proof for this exact car seat + adapter + Dragonfly combination; abstain.",
        "human_label":"Совместимость Pebble 360 Pro 2 с адаптером Dragonfly не подтверждена."
    },
    "N02_PEBBLE_PRO2_FOX2":{
        "oem_accessory_identity_proof":"Official Fox/Kangaroo adapter family page separates frame-specific lists.",
        "oem_compatible_models_proof":"Fox 5 & 5 Renew list Pebble 360 Pro 2; the Fox 2 list does not.",
        "safety_predicates":"Only the exact frame generation named in the OEM compatibility section qualifies.",
        "false_positive_hazard":"Treating one adapter SKU or adapter family as universal across Fox generations.",
        "rejection_reason":"No OEM positive proof for Pebble 360 Pro 2 + Fox 2; abstain, without asserting physical incompatibility.",
        "human_label":"Для Fox 2 совместимость этой модели не подтверждена."
    },
    "N03_CABRIOFIX_DRAGONFLY":{
        "oem_accessory_identity_proof":"Official Bugaboo Q&A identifies Dragonfly adapter item code 400003001.",
        "oem_compatible_models_proof":"Bugaboo Support states CabrioFix is not listed/tested and is not recommended with Dragonfly.",
        "safety_predicates":"Do not recommend the untested configuration.",
        "false_positive_hazard":"A retailer bundle is not OEM fitment evidence.",
        "rejection_reason":"Explicit manufacturer no-recommendation for this configuration.",
        "human_label":"Bugaboo не рекомендует использовать CabrioFix с адаптером Dragonfly."
    },
    "N04_RELAX_INSERT_IDENTITY":{
        "oem_accessory_identity_proof":"Britax official page identifies Comfort Insert SKU 2000030111; Relax Insert page identifies article ACCSFCC207.",
        "oem_compatible_models_proof":"DUALFIX allow-list on Relax Insert page cannot be joined to catalogue seller SKU 2000040775 without an audited OEM-article mapping.",
        "safety_predicates":"Even with identity confirmed, model allow-list, 61–87 cm, and no simultaneous second insert must all pass.",
        "false_positive_hazard":"Title resemblance between Comfort Insert and Relax Insert or guessed seller SKU mapping.",
        "rejection_reason":"Accessory article identity is unproven for catalogue SKU 2000040775; abstain.",
        "human_label":"Совместимость этой карточки не подтверждена: требуется связать артикул производителя."
    }
}
holdout_rows = []
for p in probes:
    source = catalog.get(p["source_nid"])
    target = find_ru_sku(p["target_sku"])
    source_tnid = str(source.get("tnid")) if source else ""
    translations = lang_rows(source_tnid) if source else []
    target_tnid = str(target.get("tnid")) if target else ""
    target_translations = lang_rows(target_tnid) if target else []
    current_has_link = bool(source and target and target["nid"] in current.get(str(source["nid"]), {}).get("accessories", []))
    t2 = "YES" if current_has_link else "NO"
    if p["expected"] == "OEM_EXPLICIT_POSITIVE":
        result = "TRUE_OEM_RELATION; NOT_A_STAGE1_APPROVED_RECOMMENDATION"
    elif p["expected"] == "OEM_SAYS_NOT_COMPATIBLE_OR_TESTED":
        result = "CORRECT_REJECTION"
    elif p["expected"] == "OEM_TARGET_SKU_MAPPING_UNPROVEN":
        result = "CORRECT_ABSTENTION"
    else:
        result = "CORRECT_ABSTENTION_NOT_A_PHYSICAL_NEGATIVE"
    frame_rows = chassis([x for x in p["chassis_nids"].split(",") if x])
    stage1_status = "NOT RUN FOR THIS NEW PAIR"
    if target and str(target["nid"]) in stage1_result:
        stage1_status = "TARGET PRESENT IN SAVED STAGE1 DATA; PAIR VALIDATION STILL NOT APPROVED"
    holdout_rows.append({
        "case_id":p["case_id"],"split":p["split"],"rule":p["rule"],
        "source_model":source.get("title","") if source else "",
        "source_sku":source.get("sku","") if source else "",
        "source_tnid":source_tnid,"source_nid_ru":next((r["nid"] for r in translations if r.get("lang")=="ru"),""),
        "source_nid_uk":next((r["nid"] for r in translations if r.get("lang")=="uk"),""),
        "accessory_sku_catalog":p["target_sku"],
        "accessory_target_nid_ru":next((r["nid"] for r in target_translations if r.get("lang")=="ru"),"") if target else "",
        "accessory_target_nid_uk":next((r["nid"] for r in target_translations if r.get("lang")=="uk"),"") if target else "",
        "accessory_field_status":target.get("field_status","") if target else "",
        "accessory_sell_price":target.get("price","") if target else "",
        "accessory_oid_rows":target.get("oid_weight_price_rows","") if target else "",
        "chassis_model":p["chassis"],"chassis_catalog_rows":frame_rows,
        "expected_oem_state":p["expected"],"shadow_output":p["shadow"],
        "counterfactual_current_t2":t2,"stage1_status":stage1_status,
        "independent_model_and_sku":"YES" if p["split"]=="independent_physical_model_and_accessory_sku" else "NO",
        "test_result":result,"oem_evidence_url":p["evidence"],
        **probe_review_details[p["case_id"]],
        "conditions_and_notes":p["note"]
    })

# Executable, intentionally conservative model-span normalization. The caller must
# first isolate the model span from brand/category text using structured brand/role fields.
# Punctuation is not a substitute for extracting the correct model span.
DASH_CHARS = {"-", "\u2010", "\u2011", "\u2012", "\u2013", "\u2014", "\u2212"}

def normalize_model_span(value):
    chars = list(unicodedata.normalize("NFKC", value).casefold())
    out = []
    for i, ch in enumerate(chars):
        if ch in DASH_CHARS and i > 0 and i + 1 < len(chars) and chars[i-1].isalnum() and chars[i+1].isalnum():
            continue
        if unicodedata.category(ch).startswith("P"):
            out.append(" ")
        else:
            out.append(ch)
    return " ".join("".join(out).split())

normalization_tests = [
    ("M01_BESAFE_X1_PUNCTUATION","iZi Go Modular X-1 iSize","iZi Go Modular X1 i-Size",True,"punctuation-only form in source title and OEM list"),
    ("M02_CASE_AND_SPACING","DUALFIX   M PLUS","dualfix m plus",True,"case and repeated whitespace only"),
    ("M03_SWIVEL_GENERATION","SWIVEL","SWIVEL 2",False,"generation digit must remain"),
    ("M04_PEBBLE_PRO_GENERATION","Pebble 360 Pro","Pebble 360 Pro 2",False,"Pro and Pro 2 remain distinct"),
    ("M05_CORAL_MODEL","Coral Slide Pro","Coral 360",False,"different named model/family remains distinct"),
    ("M06_CYRILLIC_LATIN_CONFUSABLE","iZi Go X1","iZi Go Х1",False,"Latin X and visually similar Cyrillic Х are not transliterated"),
]
for cid, left, right, expected_equal, note in normalization_tests:
    actual_equal = normalize_model_span(left) == normalize_model_span(right)
    if actual_equal != expected_equal:
        raise SystemExit(f"Model normalization mismatch {cid}: expected_equal={expected_equal}, actual={actual_equal}")
    holdout_rows.append({
        "case_id":cid,"split":"normalization_boundary","rule":"casefold + NFKC + punctuation/whitespace normalization; preserve tokens and digits",
        "source_model":left,"source_sku":"","source_tnid":"","source_nid_ru":"","source_nid_uk":"",
        "accessory_sku_catalog":"","accessory_target_nid_ru":"","accessory_target_nid_uk":"",
        "accessory_field_status":"","accessory_sell_price":"","accessory_oid_rows":"",
        "chassis_model":"","chassis_catalog_rows":"",
        "expected_oem_state":"NORMALIZES_EQUAL" if expected_equal else "NORMALIZES_DISTINCT",
        "shadow_output":"NORMALIZES_EQUAL" if actual_equal else "ABSTAIN_DISTINCT_MODEL",
        "counterfactual_current_t2":"NOT_APPLICABLE","stage1_status":"NOT_APPLICABLE_RULE_PREDICATE_TEST",
        "independent_model_and_sku":"NO","test_result":"PASS_EXECUTED_NORMALIZATION",
        "oem_evidence_url":BESAFE_MANUAL if cid=="M01_BESAFE_X1_PUNCTUATION" else (BRITAX_COMFORT if cid in ("M02_CASE_AND_SPACING","M03_SWIVEL_GENERATION") else BUGABOO_DRAGONFLY),
        "oem_accessory_identity_proof":"No accessory identity claim; this is a model-string normalization boundary test.",
        "oem_compatible_models_proof":f"{left!r} vs {right!r}; {note}.",
        "safety_predicates":"No child-use or safe-use decision is made by a name normalization test.",
        "false_positive_hazard":"Over-normalizing could merge model generations or visually confusable scripts.",
        "rejection_reason":"Normalization test only; it creates no product relation.",
        "human_label":"Совпадение названий модели само по себе не подтверждает совместимость.",
        "conditions_and_notes":json.dumps({"left":left,"right":right,"normalized_left":normalize_model_span(left),"normalized_right":normalize_model_span(right),"equal":actual_equal},ensure_ascii=False)
    })

# Executable predicates for the manufacturer restrictions. These unit-like boundary
# probes validate conditional gates only; they are not product recommendations.
RELAX_MODELS = {"DUALFIX 5Z","DUALFIX PRO","DUALFIX PRO M","DUALFIX PLUS","DUALFIX M PLUS","SWINGFIX M PLUS"}

def evaluate_condition_gate(rule, x):
    if rule == "BRITAX_R129":
        if x.get("infant_carrier") or not x.get("integrated_harness"):
            return False, "requires non-infant-carrier seat with integrated harness"
        height = x["height_cm"]
        direction = x["direction"]
        if direction == "rearward":
            return height >= 60, "R129 rearward minimum is 60 cm"
        if direction == "forward":
            return height >= 76, "R129 forward minimum is 76 cm"
        return False, "unknown installation direction"
    if rule == "BRITAX_R44":
        if x.get("infant_carrier") or not x.get("integrated_harness"):
            return False, "requires non-infant-carrier seat with integrated harness"
        return x["weight_kg"] >= 9.0, "R44 minimum is 9 kg"
    if rule == "BRITAX_RELAX_INSERT":
        if x.get("seat_model") not in RELAX_MODELS:
            return False, "seat model is not in the exact OEM allow-list"
        if not 61 <= x["height_cm"] <= 87:
            return False, "height must be within 61–87 cm"
        if x.get("other_insert_fitted"):
            return False, "must not be used with another insert simultaneously"
        return True, "all supplied Relax Insert predicates pass"
    raise ValueError(f"Unknown condition rule: {rule}")

condition_tests = [
    ("C01_BRITAX_R129_59CM_REAR","BRITAX_R129",{"standard":"R129","integrated_harness":True,"infant_carrier":False,"height_cm":59,"direction":"rearward"},False,BRITAX_COMFORT),
    ("C02_BRITAX_R129_60CM_REAR","BRITAX_R129",{"standard":"R129","integrated_harness":True,"infant_carrier":False,"height_cm":60,"direction":"rearward"},True,BRITAX_COMFORT),
    ("C03_BRITAX_R129_75CM_FORWARD","BRITAX_R129",{"standard":"R129","integrated_harness":True,"infant_carrier":False,"height_cm":75,"direction":"forward"},False,BRITAX_COMFORT),
    ("C04_BRITAX_R129_76CM_FORWARD","BRITAX_R129",{"standard":"R129","integrated_harness":True,"infant_carrier":False,"height_cm":76,"direction":"forward"},True,BRITAX_COMFORT),
    ("C05_BRITAX_R129_60CM_FORWARD","BRITAX_R129",{"standard":"R129","integrated_harness":True,"infant_carrier":False,"height_cm":60,"direction":"forward"},False,BRITAX_COMFORT),
    ("C06_BRITAX_R129_NO_HARNESS","BRITAX_R129",{"standard":"R129","integrated_harness":False,"infant_carrier":False,"height_cm":76,"direction":"forward"},False,BRITAX_COMFORT),
    ("C07_BRITAX_R44_8_9KG","BRITAX_R44",{"standard":"R44","integrated_harness":True,"infant_carrier":False,"weight_kg":8.9},False,BRITAX_COMFORT),
    ("C08_BRITAX_R44_9KG","BRITAX_R44",{"standard":"R44","integrated_harness":True,"infant_carrier":False,"weight_kg":9.0},True,BRITAX_COMFORT),
    ("C09_BRITAX_INFANT_CARRIER","BRITAX_R44",{"standard":"R44","integrated_harness":True,"infant_carrier":True,"weight_kg":10.0},False,BRITAX_COMFORT),
    ("C10_RELAX_INSERT_60CM","BRITAX_RELAX_INSERT",{"seat_model":"DUALFIX PRO","height_cm":60,"other_insert_fitted":False},False,BRITAX_RELAX),
    ("C11_RELAX_INSERT_61CM","BRITAX_RELAX_INSERT",{"seat_model":"DUALFIX PRO","height_cm":61,"other_insert_fitted":False},True,BRITAX_RELAX),
    ("C12_RELAX_INSERT_87CM","BRITAX_RELAX_INSERT",{"seat_model":"DUALFIX PRO","height_cm":87,"other_insert_fitted":False},True,BRITAX_RELAX),
    ("C13_RELAX_INSERT_88CM","BRITAX_RELAX_INSERT",{"seat_model":"DUALFIX PRO","height_cm":88,"other_insert_fitted":False},False,BRITAX_RELAX),
    ("C14_RELAX_INSERT_UNLISTED_MODEL","BRITAX_RELAX_INSERT",{"seat_model":"DUALFIX PRO 2","height_cm":70,"other_insert_fitted":False},False,BRITAX_RELAX),
    ("C15_RELAX_INSERT_DOUBLE_INSERT","BRITAX_RELAX_INSERT",{"seat_model":"DUALFIX PRO","height_cm":70,"other_insert_fitted":True},False,BRITAX_RELAX),
]
for cid, rule, inputs, expected, evidence_url in condition_tests:
    actual, reason = evaluate_condition_gate(rule, inputs)
    if actual != expected:
        raise SystemExit(f"Condition gate mismatch {cid}: expected={expected}, actual={actual}")
    holdout_rows.append({
        "case_id":cid,"split":"condition_predicate_boundary","rule":rule,
        "source_model":"Britax car seat; exact model/standard supplied in conditions",
        "source_sku":"","source_tnid":"","source_nid_ru":"","source_nid_uk":"",
        "accessory_sku_catalog":"2000030111" if rule.startswith("BRITAX_R129") or rule=="BRITAX_R44" else "OEM article ACCSFCC207; seller SKU mapping unverified",
        "accessory_target_nid_ru":"","accessory_target_nid_uk":"","accessory_field_status":"","accessory_sell_price":"",
        "accessory_oid_rows":"","chassis_model":"","chassis_catalog_rows":"",
        "expected_oem_state":"CONDITION_PASS" if expected else "CONDITION_FAIL",
        "shadow_output":"CONDITIONAL_FITMENT_ONLY" if actual else "REJECT",
        "counterfactual_current_t2":"NOT_APPLICABLE","stage1_status":"NOT_APPLICABLE_RULE_PREDICATE_TEST",
        "independent_model_and_sku":"NO","test_result":"PASS_EXECUTED_PREDICATE",
        "oem_evidence_url":evidence_url,
        "oem_accessory_identity_proof":"Official Britax article identity in OEM page/URL; catalog mapping is not assumed for Relax Insert.",
        "oem_compatible_models_proof":"Condition-gate unit vector for an exact model/standard; not a new product-pair claim.",
        "safety_predicates":"Exact standard, integral harness, infant-carrier exclusion, child height/weight threshold, direction or second-insert exclusion as applicable.",
        "false_positive_hazard":"Treating a failed/missing condition as allowed, or claiming model compatibility means unrestricted safe use.",
        "rejection_reason":"Condition predicate only; no SKU-specific recommendation was evaluated.",
        "human_label":"Совместимость по модели не отменяет ограничений по росту, весу, ремням и установке.",
        "conditions_and_notes":json.dumps({"inputs":inputs,"predicate_result":actual,"explanation":reason},ensure_ascii=False)
    })

with (TRAIN / "HOLDOUT_RESULTS.csv").open("w",encoding="utf-8-sig",newline="") as f:
    w=csv.DictWriter(f,fieldnames=holdout_fields); w.writeheader(); w.writerows(holdout_rows)

# Full 110-row candidate queue. These are unlabelled candidates, never training positives.
fp_fields=["review_id","review_source","pattern","rejection_reason","target_sku","target_title","physical_source_models_ru","candidate_source_examples","candidate_pairs","manufacturer_evidence_in_seed_csv","oem_evidence_url","oem_identity_proof","compatibility_or_interface_proof","required_conditions","human_label","expected_truth","shadow_output","false_positive_scored","decision_and_reason"]
fp_rows=[]
for i,r in enumerate(clusters,1):
    fp_rows.append({
        "review_id":f"QUEUE-{i:03d}","review_source":"UNVERIFIED_MANUAL_FEATURE_CLUSTERS.csv",
        "pattern":r["pattern"],"rejection_reason":r["rejection_reason"],"target_sku":r["target_sku"],
        "target_title":r["target_title"],"physical_source_models_ru":r["physical_source_models_ru"],
        "candidate_source_examples":r["sample_sources_ru"],"candidate_pairs":r["sample_pairs_ru"],
        "manufacturer_evidence_in_seed_csv":r["manufacturer_evidence"],
        "oem_evidence_url":"NONE — no verified OEM source supplied for this candidate.",
        "oem_identity_proof":"NONE — target SKU/OEM article identity is not established by this queue row.",
        "compatibility_or_interface_proof":"NONE — manual cluster mentions are search clues, not fitment proof.",
        "required_conditions":"Find primary OEM article and exact model/physical-interface conditions; keep unknowns closed.",
        "human_label":"Совместимость не подтверждена. Требуется проверка производителя.",
        "expected_truth":"UNLABELLED_NOT_GROUND_TRUTH",
        "shadow_output":"ABSTAIN_NO_OEM_PROOF","false_positive_scored":"NO_TRUTH_LABEL",
        "decision_and_reason":"No automatic link. Search queue only; require exact OEM article/model proof, physical role and applicable conditions."
    })
for i,r in enumerate(controls,1):
    text=(r["expected"]+" "+r["purpose"]).lower()
    if "not counted" in text or "never counted" in text:
        out="REJECT_AS_A_B_C_VEHICLE_GENERAL"
        truth="NEGATIVE_CONTROL_C_NOT_A_B"
    elif "not inferred" in text or "no generalization" in text or "not listed" in text or "not conflate" in text:
        out="ABSTAIN_OR_REJECT_EXACT_MODEL"
        truth="NEGATIVE_OR_UNLISTED_CONTROL"
    else:
        out="CONDITIONAL_MATCH_ONLY"
        truth="CONDITIONAL_POSITIVE_CONTROL"
    fp_rows.append({
        "review_id":f"CONTROL-{i:02d}","review_source":"NEGATIVE_AND_CONDITIONAL_CONTROLS.csv",
        "pattern":r["purpose"],"rejection_reason":"manufacturer condition / boundary control",
        "target_sku":r["target_sku"],"target_title":r["control"],
        "physical_source_models_ru":1,"candidate_source_examples":r["source_model"],
        "candidate_pairs":"","manufacturer_evidence_in_seed_csv":"see task row and corresponding OEM page/manual",
        "oem_evidence_url":BESAFE_MANUAL if r["target_sku"]=="11006001" else BRITAX_COMFORT if r["target_sku"]=="2000030111" else MAXI_ADAPTER if r["target_sku"]=="1166057110" else "NOT_CAPTURED_IN_OEM_SOURCE_SET",
        "oem_identity_proof":("OEM instruction/model product identifies BeSafe Rain Shield; base article 11006001 is the validated catalog join." if r["target_sku"]=="11006001" else "Official product URL/article confirms SKU 2000030111." if r["target_sku"]=="2000030111" else "Official Maxi-Cosi page identifies adapter SKU 1166057110." if r["target_sku"]=="1166057110" else "No exact OEM article identity proof in supplied sources."),
        "compatibility_or_interface_proof":r["expected"],
        "required_conditions":r["expected"],
        "human_label":"Условная совместимость: соблюдайте указанные производителем ограничения." if out=="CONDITIONAL_MATCH_ONLY" else "Совместимость не подтверждена; рекомендацию не показывать.",
        "expected_truth":truth,"shadow_output":out,"false_positive_scored":"MANUAL_REVIEW_NOT_MODEL_SCORE",
        "decision_and_reason":r["expected"]
    })
extra = [
("CONTROL-BUGABOO-DRAGONFLY-CABRIOFIX","chassis-generation/model negative","400003001","Bugaboo Dragonfly adapter","Maxi-Cosi CabrioFix","OEM says unlisted / not tested; do not recommend"),
("CONTROL-BUGABOO-DRAGONFLY-PEBBLE-PRO2","generation boundary / unlisted","400003001","Bugaboo Dragonfly adapter","Maxi-Cosi Pebble 360 Pro 2","Dragonfly list names Pro, not Pro 2; abstain, no physical incompatibility claim"),
("CONTROL-BUGABOO-FOX2-PEBBLE-PRO2","chassis-generation boundary","400019001","Bugaboo Fox/Kangaroo adapter","Maxi-Cosi Pebble 360 Pro 2 + Fox 2","Fox 2 list omits Pro 2; abstain"),
("IDENTITY-RELAX-INSERT","OEM article join missing","2000040775","Britax Relax Insert seller listing","Britax DUALFIX family","OEM article ACCSFCC207 not joined to seller SKU 2000040775; abstain"),
]
for rid,pattern,sku,title,source,reason in extra:
    fp_rows.append({"review_id":rid,"review_source":"independent OEM holdout review",
        "pattern":pattern,"rejection_reason":"strict allow-list / identity gate","target_sku":sku,
        "target_title":title,"physical_source_models_ru":1,"candidate_source_examples":source,
        "candidate_pairs":"","manufacturer_evidence_in_seed_csv":"official Bugaboo/Britax page; see evidence URL in HOLDOUT_RESULTS.csv",
        "oem_evidence_url":BUGABOO_DRAGONFLY if sku=="400003001" else BUGABOO_FOX if sku=="400019001" else BRITAX_RELAX,
        "oem_identity_proof":f"OEM page/product identifies accessory {sku}; where SKU mapping is not verified, this row abstains.",
        "compatibility_or_interface_proof":reason,
        "required_conditions":"Exact model, exact chassis generation and complete adapter interface required.",
        "human_label":"Совместимость не подтверждена для указанной пары/поколения.",
        "expected_truth":"UNLISTED_OR_IDENTITY_UNPROVEN","shadow_output":"ABSTAIN_NO_RECOMMENDATION",
        "false_positive_scored":"MANUAL_REVIEW_NOT_MODEL_SCORE","decision_and_reason":reason})
with (TRAIN / "FALSE_POSITIVE_REVIEW.csv").open("w",encoding="utf-8-sig",newline="") as f:
    w=csv.DictWriter(f,fieldnames=fp_fields); w.writeheader(); w.writerows(fp_rows)

car_seat_edges=0
stroller_edges=0
for sid,rec in current.items():
    head=catalog.get(str(sid),{}).get("function_signature",{}).get("head")
    n=len(rec.get("accessories",[]))
    if head=="car_seat": car_seat_edges += n
    elif head in ("stroller","stroller_part") or catalog.get(str(sid),{}).get("type")=="kol": stroller_edges += n
summary={
    "mode":"read-only shadow evaluation; no engine imports or changes",
    "training_files_sha256_verified":len(expected_hashes),
    "seed_locale_rows":len(seed),"seed_physical_pairs":len(physical_seed),
    "feature_groups":len(features),"negative_conditional_controls":len(controls),
    "unverified_queue_rows":len(clusters),"unverified_unique_target_skus":len({r["target_sku"] for r in clusters}),
    "frozen_catalog_rows":len(catalog_rows),"frozen_source_rows":len(sources),
    "v36_similar_identical_on_all_sources":True,
    "current_t2_accessory_edges_total":sum(len(r.get("accessories",[])) for r in current.values()),
    "current_t2_car_seat_edges":car_seat_edges,"current_t2_stroller_edges":stroller_edges,
    "independent_model_and_sku_holdout_positive_cases":2,
    "independent_model_and_sku_holdout_correct_oem_relations":2,
    "independent_model_and_sku_holdout_false_positives":0,
    "additional_accessory_sku_holdout_positive_cases":2,
    "additional_accessory_sku_holdout_correct_oem_relations":2,
    "current_t2_links_present_for_new_holdout_relations":sum(1 for r in holdout_rows if r["split"].startswith(("independent_","accessory_")) and r["counterfactual_current_t2"]=="YES"),
    "new_pair_stage1_passes":0,
    "manual_cluster_queue_rows_auto_accepted":0,
    "manual_cluster_queue_rows_with_known_truth":0,
    "holdout_rows":len(holdout_rows),
    "normalization_boundary_tests":len(normalization_tests),
    "condition_predicate_boundary_tests":len(condition_tests),
    "condition_predicate_boundary_tests_passed":sum(1 for r in holdout_rows if r["split"]=="condition_predicate_boundary" and r["test_result"]=="PASS_EXECUTED_PREDICATE"),
    "false_positive_review_rows":len(fp_rows),
    "inputs_sha256":{
        "fresh_current_catalog_records.jsonl.gz":sha(CATALOG),
        "fresh_v36_scope_sources.json":sha(SOURCES),
        "t2_v421_manifest.json":sha(SNAP/"output/t2_v421_manifest.json")
    }
}
(TRAIN/"evaluation_summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps(summary,ensure_ascii=False,indent=2))
