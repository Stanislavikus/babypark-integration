# V4.2.1 OEM compatibility — Stage1 requirements

**Status:** proposal for a separate owner-approved implementation stage. No Stage1 evaluation in this campaign approved a new relation.

## Exact identity and evidence

- Resolve the current source model and target item by SKU, TNID, locale, physical role and exact model span.
- Join the accessory's OEM article/SKU to the catalog SKU with primary manufacturer evidence. Similar titles, seller codes and language duplicates are insufficient.
- Store source URL, region/language, retrieval date, document version, content hash, exact allow-list entries and completeness/conflict state.
- Keep OEM model-fitment distinct from a child-specific safe-use decision.

## Current catalog state

- Read current source and target records; do not trust the frozen training snapshot for live eligibility.
- Validate current VID and option set, plus current OID/option rows and option_digest when variant identity matters.
- Run the existing V4.2.1 purchase Stage1 for the target against current publication, price, availability, native purchase CTA and eligible variant state.
- Require current Stage1 for the source context and target. field_status, price or an old positive row alone does not prove current purchasability.
- A missing, stale or failed Stage1 result blocks display.

## Mechanical adapter gate

A car-seat model alone does not determine an adapter when fitment depends on a stroller frame. Require all three exact nodes:

1. Source car seat or detachable carrier model/component.
2. Exact OEM adapter SKU and its matching connector.
3. Exact stroller chassis/frame model and generation.

Require OEM evidence for both seat-to-adapter and adapter-to-frame interfaces. If the stroller is not selected or known, abstain. Keep soft carrier, complete safety shell, extension adapter and direct attachment distinct.

## Conditions

Store standard R44/R129, child height/weight/age, harness requirement, installation direction, infant-carrier exclusion, soft-carrier vs shell, inside-car vs travel-system context, exact chassis and required extension separately.

If a relevant condition is unknown, do not claim the configuration is safe or unrestricted. Either show the exact OEM model-fitment as conditional with the restriction, or abstain.

## Fail closed

No recommendation when OEM identity is unverified; evidence is partial/stale/conflicting; exact model is absent; fuzzy matching is required; adapter role or either interface is unknown; current variant/availability/purchase CTA/Stage1 is missing or failed; or a necessary child/use condition is unresolved.

## Owner review evidence

For each relation include OEM URL and hash, article/SKU proof, exact model/frame strings, conditions, false-positive hazards, reject/abstain reason, counterfactual T2 state, Stage1 result and human-readable conditional wording. Preserve the exact evidence version used.

The 110 manual clusters are not ground truth. Label a candidate only after obtaining manufacturer evidence and independent physical-model/SKU review.

## Campaign result

- OEM relation matches: 2 strict independent model/SKU holdouts; 2 additional accessory-SKU matches on source models that repeat seed.
- New T2 links: 0.
- Stage1 passes: 0.
- Publishable recommendations: 0.
