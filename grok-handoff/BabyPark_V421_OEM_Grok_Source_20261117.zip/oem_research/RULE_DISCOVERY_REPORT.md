# BabyPark V4.2.1 — поиск универсальных правил совместимости по OEM-эталонам

**Дата:** 17.11.2026  
**Статус:** исследование и независимая проверка; внедрение и публикация запрещены этим этапом.  
**Решение:** GO только на подготовку отдельного rehearsal-этапа реализации с закрытыми правилами и ручной приёмкой; NO-GO на включение, production или показ рекомендаций сейчас.

## 1. Объём и границы

Проверены все входные CSV кампании: OEM_VERIFIED_MISSED_PAIRS.csv, FEATURE_RULE_GROUPS.csv, UNVERIFIED_MANUAL_FEATURE_CLUSTERS.csv и NEGATIVE_AND_CONDITIONAL_CONTROLS.csv. Скрипт сверяет все пять исходных SHA-256 из SHA256SUMS.txt. UA/RU строки считались переводами одной физической модели, а не независимыми примерами.

Frozen snapshot: 28 769 строк каталога, 8 129 источников, 1 874 текущие accessory edges (1 832 stroller и 42 car-seat A). Similar V3.6 побайтно совпадает для всех 8 129 источников с исходным снимком. Ничего из этого не менялось.

Не менялись алгоритм, production, ручные связи, V3.6 Similar и T2 manifest. Production-документация/manifest читались только для контроля границ; все новые файлы находятся только в rehearsal campaign directory.

Теневой evaluate_readonly.py использует только стандартную библиотеку Python, валидирует хеши CSV, читает frozen snapshot и создаёт две отчётные CSV. Он не импортируется в V4.2.1. Выполнены 6 исполняемых тестов нормализации и 15 исполняемых проверок условий; это проверки предлагаемого контракта, а не production-тесты.

## 2. OEM seed и условия использования

| Группа | Доказательство производителя | Ограничения, хранимые отдельно от совпадения |
|---|---|---|
| P01 Britax Comfort Insert, OEM SKU 2000030111 | Официальный список содержит 21 модель, включая 11 физических seed-моделей: DUALFIX M PLUS, DUALFIX PLUS, EVOLVAFIX, DUALFIX PRO, DUALFIX PRO M, DUALFIX 5Z, MAX-SAFE PRO, KING PRO, ADVANSAFIX PRO, SAFE-WAY M, SWIVEL 2. KIDFIX PRO и SWIVEL без “2” отсутствуют в данном списке. | R44: интегральные ремни, от 9 кг. R129/i-Size: интегральные ремни, от 60 см против хода или от 76 см по ходу. Не заменяет вкладыш для новорождённого; не использовать в infant carrier. |
| P02 BeSafe Rain Shield, каталог 11006001par / OEM base 11006001 | Региональная страница BeSafe показывает SKU 11006001; официальный PDF указывает “for BeSafe iZi Go Modular/X1”. X-1 → X1 допускается лишь пунктуационной нормализацией. X2 не добавляется. | Только вне автомобиля; в manual прямой запрет использовать дождевик на кресле внутри машины. Маркировка manual: 0–12 месяцев; regional product page: регулируемая длина для ребёнка до 75 см. |
| P03 Maxi-Cosi Coral Slide Pro Carrier Adapter, OEM SKU 1166057110 | Официальная спецификация называет SKU и комбинацию Coral Slide Pro soft carrier + Fame/Fame Cabin. | Нужно вынуть soft carrier из safety shell. Fame Cabin принимает адаптер напрямую; для Fame нужен комплектный extension adapter. Это не любой seat shell и не любая коляска. |

Официальные источники:

- [Britax Comfort Insert 2000030111](https://www.britax-roemer.com/accessories/car-seat-accessories/comfort-insert/2000030111.html)
- [Britax Relax Insert, article ACCSFCC207](https://www.britax-roemer.com/accessories/car-seat-accessories/relax-insert/ACCSFCC207.html)
- [BeSafe Rain Shield — официальный manual](https://www.besafe.com/4a4457/globalassets/inriverimages/commerce-besafe/2019_01_10_instruction_manual_rain_shield_-_web-manual-601.pdf)
- [BeSafe regional product page with SKU 11006001](https://besafe.hr/proizvod/besafe-kisna-zastita/)
- [Maxi-Cosi Coral Slide Pro Carrier adapter 1166057110](https://www.maxi-cosi.co.uk/pushchairs/coral-slide-pro-carrier-adapter)

Britax список в текущей выдаче производителя содержит 21 модель; некоторые product-list/detail варианты отдают неполный набор. Реализация должна сохранять URL, регион, язык, дату, хеш и статус полноты списка. Разные региональные/устаревшие варианты нельзя автоматически объединять.

## 3. Независимые OEM holdout-примеры

| Case | Новая модель / SKU | OEM evidence и результат |
|---|---|---|
| H01 | Maxi-Cosi Pebble 360 Pro → Bugaboo adapter 400003001 → Dragonfly / Dragonfly Plus | Bugaboo указывает product code 400003001, модель кресла и обе рамы. Точная модельная связь найдена. Stage1 не запускался; source и accessory field_status=3. |
| H02 | Maxi-Cosi Pebble 360 Pro 2 → Bugaboo adapter 400019001 → Fox 5 / Fox 5 Renew | Frame-specific Fox 5 list содержит Pebble 360 Pro 2; Fox 2 имеет отдельный старый список. Точная модельная связь найдена. Stage1 не запускался; frame rows имеют field_status=3/2. |
| H03 | BeSafe iZi Go Modular X-1 → adapter 400019001 → Fox 5 | Fox 5 list называет iZi Go Modular X1; X-1/X1 совпадают после удаления дефиса без удаления цифры. SKU адаптера новый, но модель источника повторяет seed P02. |
| H04 | Maxi-Cosi Coral Slide Pro → adapter 400019001 → Fox 5 | Fox 5 list называет Coral Slide Pro. Точная часть/режим установки для этой пары требует сверки руководств; Maxi-Cosi adapter 1166057110 отдельно относится только к soft carrier + Fame/Fame Cabin. SKU адаптера новый, но модель источника повторяет seed P03. Не публиковать. |

Источники: [Bugaboo Dragonfly adapter 400003001](https://www.bugaboo.com/gb-en/outlet/bugaboo-dragonfly-car-seat-adapters-400003001.html), [Bugaboo Fox adapter 400019001](https://www.bugaboo.com/gb-en/accessories/adapters/bugaboo-fox-kangaroo-car-seat-adapters-black-400019001.html).

**Строгая независимая выборка:** 2/2 положительных отношения на двух новых физических моделях и новых adapter SKU совпали с OEM-списками; наблюдаемых ложных положительных среди этих двух нет. Дополнительно 2/2 совпадения найдены на новом adapter SKU, но исходные модели повторяют обучение; у H04 остаётся вопрос точной части кресла. Это не оценка популяционной precision: n=2 слишком мало для вывода о массовых ложных совпадениях.

Официальный Bugaboo Q&A сообщает, что CabrioFix с Dragonfly не был проверен/указан и не рекомендуется; Pebble 360 Pro 2 на момент ответа не был протестирован. Актуальный Dragonfly allow-list содержит Pro, но не Pro 2. Поэтому Pro/Pro 2 не сливаются; для Pro 2 + Dragonfly — abstain, а не заявление о физической несовместимости.

## 4. Результаты трёх механизмов

### 4.1 Извлечение OEM-моделей и ограничений

Обоснован общий evidence-контракт: явный exact OEM article/SKU, exact список модели, роль аксессуара, интерфейсы, ограничения, URL/регион/язык/дата/версия/hash и полнота страницы. Только явное OEM-подтверждение создаёт положительную fitment-связь. Неоднозначный SKU, частичный список, конфликт страниц или неизвестная часть товара дают abstain.

Это обосновывает reusable evidence parser, но не универсальный scraper для любых сайтов. На страницах производителя встречаются региональные и пагинированные варианты списков; при расхождении нужна ручная проверка.

### 4.2 Нормализация без потери поколения

Все 6 исполняемых проверок прошли:

- совпадают: iZi Go Modular X-1 iSize / iZi Go Modular X1 i-Size; регистр и повторные пробелы;
- остаются различны: SWIVEL / SWIVEL 2; Pebble 360 Pro / Pro 2; Coral Slide Pro / Coral 360; Latin X / визуально похожая кириллическая Х.

Допустимо: NFKC, регистр, пробелы и удаление дефисного знака между буквами/цифрами при сохранении слов и цифр. Сначала выделить exact model span по структурированным brand/role полям. Запрещены fuzzy, substring/LIKE, embeddings как единственное доказательство, перевод, транслитерация и удаление suffix/generation.

### 4.3 Механика как граф интерфейсов

Форма связи: exact seat или detachable carrier → exact OEM adapter SKU → exact chassis/frame model. Требуются оба интерфейса и подтверждённая роль каждого узла. “Car seat adapter” не значит “подходит к любой коляске”.

P03 показывает различие soft carrier и safety shell, Fame и Fame Cabin, а также прямого крепления и extension adapter. Bugaboo подтверждает, что список зависит от поколения шасси. Если рама неизвестна, рекомендация одного адаптера только по модели автокресла должна abstain.

## 5. Условия и ложные совпадения

Все 15 машинно-исполняемых предикатов прошли: R129 59/60 см rear-facing, 75/76 см forward-facing, направление, интегральные ремни, infant-carrier исключение; R44 8.9/9 кг; Relax Insert 60/61/87/88 см, точная модель, отсутствие второго вкладыша.

В отдельные поля записываются стандарт R44/R129, рост/вес/возраст, интегральные ремни, направление установки, infant-carrier/soft-carrier/shell, внутри автомобиля или outdoor travel system, шасси и extension adapter. Если условие применимо, а значение неизвестно, нельзя писать “безопасно”, “подходит ребёнку” или “можно использовать” без оговорки. Можно сообщить только условную OEM-модельную связь с точным ограничением; иначе abstain.

Пограничные проверки:

- KIDFIX PRO отсутствует в Comfort Insert allow-list.
- SWIVEL не равен SWIVEL 2; X1 не превращается в X2.
- Coral Slide Pro не расширяется на Coral 360.
- Pebble 360 Pro не расширяется на Pro 2; Fox 5 list не переносится на Fox 2.
- CabrioFix + Dragonfly не рекомендовать по ответу Bugaboo.
- Relax Insert page доказывает article ACCSFCC207, но join к seller SKU 2000040775 не проверен — abstain.
- Автомобильный органайзер — категория C с креплением к спинке автомобильного сиденья, не A/B.

Эти ограничения снижают риск массовых совпадений структурно: allow-list closed-world, exact SKU, физические роли, точные поколения, обязательные интерфейсы, отсутствует fuzzy fallback, неизвестное → abstain. Но выборка не позволяет статистически гарантировать точность по широкому каталогу.

## 6. Очередь из 110 кластеров

Все 110 кластеров использованы только как очередь поиска доказательств, не как метки. Это 82 уникальных target SKU; упоминания источников/пар перекрываются. В FALSE_POSITIVE_REVIEW.csv все 110 имеют UNLABELLED_NOT_GROUND_TRUTH, NO_TRUTH_LABEL и ABSTAIN_NO_OEM_PROOF.

Группы: 53 — нужна классификация роли; 33 — C/автомобильные универсальные товары; 11 — модельные покрытия; 5 — подстаканники; 4 — comfort-insert кандидаты; 3 — adapter P03; 1 — rain-shield. Первичные причины блокировки: неверная роль/категория 41, неопределённая source model 34, нет fitment proof 19, сомнение в identity 15, неизвестная механика 1.

FALSE_POSITIVE_REVIEW.csv содержит 122 строки: 110 unlabelled очередей, 8 исходных negative/conditional controls и 4 независимых OEM boundary/identity контроля. Control rows помечены MANUAL_REVIEW_NOT_MODEL_SCORE; они не изображают работу production-ранжировщика. Для 110 кластеров метрика ошибок не определена, потому что ground truth отсутствует.

## 7. Решение владельцу

**Обосновано вынести в отдельный V4.2.1 rehearsal implementation proposal:**

1. Provenance record для OEM article/SKU, versioned source, моделей, интерфейсов и ограничений.
2. Closed-world OEM allow-list parser.
3. Пунктуационная нормализация, сохраняющая слова, цифры и поколения.
4. Типизированный граф seat/carrier + adapter + chassis с обоими обязательными endpoints.
5. Разделение “OEM model fitment” и “safe-use eligibility”; неизвестное условие закрывает безусловную рекомендацию.

**Дополнительные данные нужны до автоматической выдачи:** независимые примеры для inserts и rain shields, физические модели других производителей, региональные страницы, подтверждённые SKU joins, точная компонентная схема Coral Slide Pro + Bugaboo adapter, контекст выбранной рамы и данные ограничений ребёнка. Строгая положительная выборка сейчас только n=2.

**Запрещено внедрять:** NID/SKU exception tables; fuzzy/подстрочное сравнение; удаление поколений/цифр; перенос списка между рамами; C товары в A/B; вывод о безопасности из совпавшей модели; рекомендацию при неизвестной детали адаптера, неразрешённом OEM conflict, неизвестном SKU или непройденном Stage1.

**Stage1 не пройден:** 0 новых пар прошли Stage1, 0 новых links в текущем T2, 0 рекомендаций опубликовано. H01/H02 — только OEM relation matches, не готовые к показу товары.

Предложение следующего этапа: ограниченный rehearsal-прототип evidence parser/normalizer и графового shadow matcher с ручной приёмкой и расширением holdout. Не включать выдачу, пока по каждому механизму не накоплена независимая физическая выборка. Оценка минимального прототипа — 4–8 часов плюс отдельное время на сбор OEM-доказательств; риск средний из-за региональных вариантов страниц и скрытых физических интерфейсов. Scope должен быть принят отдельно владельцем.

## 8. Воспроизводимость

- HOLDOUT_RESULTS.csv: 29 строк — 2 строгих independent positives, 2 SKU holdouts на повторных source-моделях, 6 normalization boundaries, 15 condition gates, 4 additional negative/identity cases.
- FALSE_POSITIVE_REVIEW.csv: 122 строки со всеми 110 unlabelled clusters.
- PROPOSED_FEATURE_CONTRACT.json: машинно-читаемое предложение без runtime exceptions.
- STAGE1_REQUIREMENTS.md: gating checklist.
- evaluate_readonly.py и evaluation_summary.json: воспроизводимый read-only расчёт.
- Входные CSV не менялись; исходные hashes в SHA256SUMS.txt. Similar V3.6 и T2 snapshot не менялись.
- Источники производителя проверены 17.11.2026; страницы и списки могут обновляться.
