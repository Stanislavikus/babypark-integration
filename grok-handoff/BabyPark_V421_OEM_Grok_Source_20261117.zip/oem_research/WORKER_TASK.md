# BabyPark — OEM verified seed / feature-rule discovery, no implementation approval
Scope: rehearsal only. Read OEM_VERIFIED_MISSED_PAIRS.csv, FEATURE_RULE_GROUPS.csv, UNVERIFIED_MANUAL_FEATURE_CLUSTERS.csv and NEGATIVE_AND_CONDITIONAL_CONTROLS.csv.
Independent seed: 13 physical source-product→accessory pairs, 26 UA/RU locale rows. The OEM model compatibility is confirmed, but child/use conditions and Stage1 for these new pairs are NOT yet approved; therefore auto-publish=NO.
Requirements:
1. Treat sources as independently OEM-confirmed positives, NOT as IDs to hardcode. Discover reusable rules extracting manufacturer accessory SKU identity, positive compatibility/model enumeration, alias-normalization, role, usage context and required external interfaces.
2. P01 Britax Comfort Insert OEM SKU 2000030111: 11 previously missed physical model pairs. Parse OEM model list; enforce R44/R129, integrated harness, 60cm rearward/76cm forward, not for infant carriers; catalogue title 'для новорожденных' must NOT drive recommendations.
3. P02 BeSafe Rain Shield 11006001 (catalog 11006001par): manufacturer manual for iZi Go Modular/X1. Normalize X-1/X1, and forbid use in cars. Do not extrapolate to X2.
4. P03 Maxi-Cosi 1166057110 adapter: use Coral Slide Pro SOFT CARRIER only with Fame or Fame Cabin; model+adapter+stroller interface (not universal pairing).
5. C vehicle-general goods: never inflate A/B with a car organiser. Review manual clusters only as unverified candidates; no manual fallback.
6. Train/evaluate on physical SKU/TNID groups, not language duplicates. Include negative controls; leave-one-model/series-out tests. Never conflate OEM model compatible with unrestricted safe use.
7. For EACH candidate list provenance, OEM URL, OEM product/model SKU proof, compatibility facts, safety predicates, false-positive hazards, rejection reason and counterfactual T2, with human-readable conditional label.
8. Prepare reproducible read-only evaluation against frozen 8129-source/28769-catalog snapshot; measure precision as well as added coverage; preserve 1832 stroller pairs and all V3.6 Similar. Do not mutate engine or production, do not publish.
Deliver RULE_DISCOVERY_REPORT.md, PROPOSED_FEATURE_CONTRACT.json, HOLDOUT_RESULTS.csv, FALSE_POSITIVE_REVIEW.csv, STAGE1_REQUIREMENTS.md and GO/NO-GO for *implementation proposal* (not production). Stop for owner decision before merge.
